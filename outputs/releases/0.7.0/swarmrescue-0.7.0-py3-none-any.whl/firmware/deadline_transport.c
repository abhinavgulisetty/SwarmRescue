/* Research candidate: transport a compact certificate along an executed prefix.
 * The frozen CMR source is reused, never modified. See docs/transport-routing-research.md.
 */
#include "deadline_retention.c"
#include "deadline_dynamic.c"

typedef struct {
  Engine *h;
  uint32_t mode, cursor, start, deadline, capacity, finite;
  uint32_t *rank, *node_index, *edge_index, *heap, *position;
  int64_t *cost, *minimum, *lazy;
  int64_t shift, suffix_cost;
  uint64_t suffix_time, prefix_time, patches, moves, transports, tree_updates;
  size_t extra;
} Transport;

static int64_t decrease(Transport *x,uint32_t e) {
  int64_t d=x->h->base[e]-x->cost[e];return d>0 ? d : 0;
}
static void incoming_swap(Transport *x,uint32_t i,uint32_t j) {
  uint32_t a=x->heap[i],b=x->heap[j];x->heap[i]=b;x->heap[j]=a;
  x->position[a]=j;x->position[b]=i;
}
static void incoming_fix(Transport *x,uint32_t e) {
  Engine *h=x->h;uint32_t v=h->to[e],begin=h->reverse_rows[v],end=h->reverse_rows[v+1];
  uint32_t i=x->position[e];
  while (i>begin) {
    uint32_t parent=begin+(i-begin-1)/2;
    if (decrease(x,x->heap[parent])>=decrease(x,x->heap[i])) break;
    incoming_swap(x,i,parent);i=parent;
  }
  for (;;) {
    uint32_t j=begin+2*(i-begin)+1;if (j>=end) break;
    if (j+1<end && decrease(x,x->heap[j+1])>decrease(x,x->heap[j])) j++;
    if (decrease(x,x->heap[i])>=decrease(x,x->heap[j])) break;
    incoming_swap(x,i,j);i=j;
  }
}
static int64_t incoming_max(Transport *x,uint32_t v) {
  Engine *h=x->h;
  return h->reverse_rows[v]==h->reverse_rows[v+1] ? 0 :
    decrease(x,x->heap[h->reverse_rows[v]]);
}
static void tree_build(Transport *x,uint32_t p,uint32_t lo,uint32_t hi) {
  x->lazy[p]=0;
  if (hi-lo==1) {
    int64_t g=x->h->gap[x->h->order[lo]],f=x->h->alternative_floor;
    x->minimum[p]=g>f ? g : f;return;
  }
  uint32_t mid=lo+(hi-lo)/2;
  tree_build(x,2*p,lo,mid);tree_build(x,2*p+1,mid,hi);
  x->minimum[p]=x->minimum[2*p]<x->minimum[2*p+1] ?
    x->minimum[2*p] : x->minimum[2*p+1];
}
static void tree_suffix(Transport *x,uint32_t p,uint32_t lo,uint32_t hi,
                        uint32_t begin,int64_t delta) {
  if (hi<=begin) return;
  if (begin<=lo) { x->minimum[p]+=delta;x->lazy[p]+=delta;return; }
  uint32_t mid=lo+(hi-lo)/2;
  tree_suffix(x,2*p,lo,mid,begin,delta);tree_suffix(x,2*p+1,mid,hi,begin,delta);
  int64_t best=x->minimum[2*p]<x->minimum[2*p+1] ?
    x->minimum[2*p] : x->minimum[2*p+1];
  x->minimum[p]=x->lazy[p]+best;
}
static void compile_transport(Transport *x) {
  Engine *h=x->h;x->cursor=0;x->shift=0;x->suffix_cost=h->optimum;x->suffix_time=0;
  x->finite=0;x->prefix_time=0;
  for (uint32_t v=0;v<h->n;v++) { x->node_index[v]=NONE;x->rank[v]=NONE; }
  for (uint32_t e=0;e<h->m;e++) { x->edge_index[e]=NONE;
    x->heap[e]=h->reverse_edges[e];x->position[x->heap[e]]=e; }
  for (uint32_t j=0;j<h->length;j++) {
    x->node_index[h->route[j]]=j;
    if (j+1<h->length) {
      uint32_t e=h->route_edges[j];x->edge_index[e]=j;x->suffix_time+=h->time[e];
    }
  }
  for (uint32_t i=0;i<h->n && h->gap[h->order[i]]!=INF;i++) {
    x->rank[h->order[i]]=i;x->finite++;
  }
  if (x->finite && h->alternative_floor!=INF) tree_build(x,1,0,x->finite);
}
static int rebuild_transport(Transport *x,uint32_t start,uint32_t deadline) {
  Engine *h=x->h;h->start=start;h->deadline=deadline;h->states=(size_t)h->n*(deadline+1);
  if (!build(h,x->cost)) return 0;
  compile_transport(x);return 1;
}
void ember_transport_destroy(Transport *x) {
  if (!x) return;
  ember_retention_destroy(x->h);free(x->rank);free(x->node_index);free(x->edge_index);
  free(x->heap);free(x->position);free(x->cost);free(x->minimum);free(x->lazy);free(x);
}
Transport *ember_transport_create(uint32_t n,uint32_t m,const uint32_t *rows,
 const uint32_t *to,const uint32_t *time,const uint32_t *from,
 const uint32_t *reverse_rows,const uint32_t *reverse_edges,const uint8_t *goals,
 uint32_t start,uint32_t deadline,const int64_t *cost,uint32_t mode,size_t budget) {
  if (mode>4) return NULL;
  Transport *x=calloc(1,sizeof(*x));if (!x) return NULL;
  x->mode=mode;x->start=start;x->deadline=x->capacity=deadline;
  /* Ablations share identical allocation accounting and patch interfaces. */
  x->extra=sizeof(*x)+72ull*n+20ull*m;
  if (x->extra>=budget) { free(x);return NULL; }
  x->h=ember_retention_create(n,m,rows,to,time,from,reverse_rows,reverse_edges,
    goals,start,deadline,cost,mode==3 ? 2 : mode==4 ? 3 : 0,budget-x->extra);
  if (!x->h) { free(x);return NULL; }
  x->rank=malloc(4ull*n);x->node_index=malloc(4ull*n);
  x->edge_index=malloc(m ? 4ull*m : 1);x->heap=malloc(m ? 4ull*m : 1);
  x->position=malloc(m ? 4ull*m : 1);x->cost=malloc(m ? 8ull*m : 1);
  x->minimum=malloc(32ull*n);x->lazy=malloc(32ull*n);
  if (!x->rank || !x->node_index || !x->edge_index || !x->heap || !x->position ||
      !x->cost || !x->minimum || !x->lazy) { ember_transport_destroy(x);return NULL; }
  memcpy(x->cost,cost,8ull*m);if (mode<3) compile_transport(x);
  return x;
}
static int scan_safe(Transport *x) {
  Engine *h=x->h;memset(h->deficit,0,8ull*h->n);
  for (uint32_t e=0;e<h->m;e++) {
    int64_t d=decrease(x,e);if (d>h->deficit[h->to[e]]) h->deficit[h->to[e]]=d;
  }
  int64_t sum=0;
  for (uint32_t i=0;i<x->finite;i++) {
    uint32_t v=h->order[i];sum+=h->deficit[v];
    int64_t margin=h->gap[v]>h->alternative_floor ? h->gap[v] : h->alternative_floor;
    if (x->shift>margin-sum) return 0;
  }
  return 1;
}
/* Atomic validation before changing the state. Positive int32 costs bound all
 * sums by N*INT32_MAX, below int64 limits for uint32-sized graphs. */
int ember_transport_update(Transport *x,uint32_t start,uint32_t deadline,
 uint32_t count,const uint32_t *edges,const int64_t *costs) {
  if (!x || start>=x->h->n || deadline>x->capacity) return -1;
  Engine *h=x->h;
  for (uint32_t i=0;i<count;i++)
    if (edges[i]>=h->m || costs[i]<=0 || costs[i]>=INT32_MAX) return -1;
  for (uint32_t i=0;i<count;i++) {
    uint32_t e=edges[i],v=h->to[e];int64_t old=x->cost[e];
    if (x->mode<3 && h->optimum!=INF && x->edge_index[e]!=NONE &&
        x->edge_index[e]>=x->cursor) x->shift+=costs[i]-old;
    int64_t before=x->mode==0 ? incoming_max(x,v) : 0;
    x->cost[e]=costs[i];
    if (x->mode==0) {
      incoming_fix(x,e);int64_t after=incoming_max(x,v);
      if (before!=after && x->rank[v]!=NONE && h->alternative_floor!=INF) {
        tree_suffix(x,1,0,x->finite,x->rank[v],before-after);x->tree_updates++;
      }
    }
  }
  x->patches+=count;
  uint32_t previous_deadline=x->deadline;
  int changed_query=start!=x->start || deadline!=x->deadline;
  x->start=start;x->deadline=deadline;
  if (x->mode>=3) {
    h->start=start;h->deadline=deadline;h->states=(size_t)h->n*(deadline+1);
    if (x->mode==3 && deadline<=previous_deadline)
      return repair(h,x->cost) ? 3 : -1;
    return build(h,x->cost) ? 3 : -1;
  }
  if ((x->mode==2 && changed_query) || h->optimum==INF)
    return rebuild_transport(x,start,deadline) ? 2 : -1;
  uint32_t next=x->node_index[start];
  if (next==NONE || next<x->cursor)
    return rebuild_transport(x,start,deadline) ? 2 : -1;
  uint64_t elapsed=0;
  for (uint32_t j=x->cursor;j<next;j++) elapsed+=h->time[h->route_edges[j]];
  /* Elapsed anchor clock before the new position must leave enough budget for
   * every feasible new suffix to lift to an anchor-query walk. */
  if (x->prefix_time+elapsed+deadline>h->deadline ||
      x->suffix_time-elapsed>deadline)
    return rebuild_transport(x,start,deadline) ? 2 : -1;
  for (uint32_t j=x->cursor;j<next;j++) {
    uint32_t e=h->route_edges[j];x->shift-=x->cost[e]-h->base[e];
    x->suffix_cost-=h->base[e];x->suffix_time-=h->time[e];x->moves++;
  }
  x->cursor=next;x->prefix_time+=elapsed;
  int safe=x->shift<=h->alternative_floor &&
    (h->alternative_floor==INF || (x->mode==0 ?
      (!x->finite || x->shift<=x->minimum[1]) : scan_safe(x)));
  if (safe) { h->optimum=x->suffix_cost+x->shift;h->accepts++;
    if (changed_query) x->transports++;
    return 1; }
  return rebuild_transport(x,start,deadline) ? 2 : -1;
}
int64_t ember_transport_result(Transport *x,uint32_t *route,uint32_t *length) {
  Engine *h=x->h;
  if (x->mode>=3) return ember_retention_result(h,route,length);
  *length=h->length-x->cursor;memcpy(route,h->route+x->cursor,4ull*(*length));
  return h->optimum;
}
void ember_transport_stats(Transport *x,uint64_t *s) {
  ember_retention_stats(x->h,s);s[0]+=x->extra;s[1]+=x->extra;
  s[6]=x->patches;s[7]=x->moves;s[8]=x->transports;s[9]=x->tree_updates;
}
