/* Research-only residual-clock DP. Reuses unchanged legacy certificates. */
#define ember_deadline_exact ember_deadline_legacy
#include "deadline_exact.c"
#undef ember_deadline_exact

static void order_down(uint32_t *order, uint32_t count, uint32_t i,
                       const int64_t *b) {
  for (;;) {
    uint32_t j = i*2+1;
    if (j >= count) return;
    if (j+1 < count && b[order[j+1]] > b[order[j]]) j++;
    if (b[order[i]] >= b[order[j]]) return;
    uint32_t v = order[i]; order[i] = order[j]; order[j] = v; i = j;
  }
}
static void order_up(uint32_t *order, uint32_t count, const int64_t *b) {
  for (uint32_t i = count/2; i; i--) order_down(order, count, i-1, b);
  for (uint32_t end = count; end > 1; end--) {
    uint32_t v = order[0]; order[0] = order[end-1]; order[end-1] = v;
    order_down(order, end-1, 0, b);
  }
}
static int slack_fast(Pool *p, uint32_t n, const uint32_t *rows,
                      const uint32_t *to, const uint32_t *duration,
                      const int64_t *weight, const uint8_t *goals, Table *t) {
  for (uint32_t e = 0; e < rows[n]; e++)
    if (duration[e] != 1)
      return table(p, n, rows, to, duration, weight, goals, -1, 1, -1, t);
  t->a = alloc(p, 8ull*n, 8); t->b = alloc(p, 8ull*n, 8);
  t->next = alloc(p, 4ull*n, 4);
  if (!t->a || !t->b || !t->next) return 0;
  size_t mark = p->used;
  uint32_t *queue = alloc(p, 4ull*n, 4);
  if (!queue) return 0;
  uint32_t head = 0, tail = 0;
  for (uint32_t u = 0; u < n; u++) {
    t->a[u] = t->b[u] = INF; t->next[u] = NONE;
    if (goals[u]) { t->a[u] = t->b[u] = 0; queue[tail++] = u; }
  }
  while (head < tail) {
    uint32_t u = queue[head++];
    for (uint32_t e = rows[u]; e < rows[u+1]; e++) {
      uint32_t v = to[e];
      if (t->b[u] > INF-weight[e]) continue;
      int64_t cost = t->b[u]+weight[e];
      if (t->a[v] == INF) {
        t->a[v] = t->a[u]+1; t->b[v] = cost;
        t->next[v] = u; queue[tail++] = v;
      } else if (t->a[v] == t->a[u]+1 && cost < t->b[v]) {
        t->b[v] = cost; t->next[v] = u;
      }
    }
  }
  p->used = mark; return 1;
}

int ember_deadline_slack(uint32_t n, const uint32_t *rows, const uint32_t *to,
                         const uint32_t *duration, const int64_t *weight,
                         const uint32_t *rr, const uint32_t *rt,
                         const uint32_t *rd, const int64_t *rw,
                         const uint8_t *goals, uint32_t start,
                         uint32_t deadline, uint32_t label_limit, uint32_t mode,
                         uint8_t *arena, size_t capacity, size_t offset,
                         uint32_t *route, ember_deadline_stats *s) {
  (void)label_limit;
  memset(s, 0, sizeof(*s));
  if (!n || start >= n || offset > capacity || mode > 1 || deadline >= INT32_MAX)
    return -1;
  Pool p = {arena, offset, capacity, offset};
  Table fast;
  if (!slack_fast(&p, n, rr, rt, rd, rw, goals, &fast)) goto quota;
  s->runs = 1;
  if (fast.a[start] == INF || fast.a[start] > deadline) {
    s->optimal = 1; goto done;
  }
  s->feasible = 1;
  s->cost = fast.b[start]; s->travel = fast.a[start];
  s->route_length = witness(n, start, goals, fast.next, route);
  if (!s->route_length) return -1;
  if (s->travel == deadline || goals[start]) {
    s->optimal = 1; goto done;
  }
  /* The fastest witness is already in route; retain only its time field. */
  p.used = ((offset + 7) & ~(size_t)7) + 8ull*n;
  Table cheap;
  if (!table(&p, n, rr, rt, rd, rw, goals, -1, 0, (int32_t)start, &cheap)) goto quota;
  s->runs++;
  s->lower_bound = cheap.a[start];
  if (cheap.b[start] <= deadline) {
    s->cost = cheap.a[start]; s->travel = cheap.b[start];
    s->route_length = witness(n, start, goals, cheap.next, route);
    if (!s->route_length) return -1;
    s->optimal = 1; goto done;
  }
  /* Preserve only the exact time potential, reclaim the other fields. */
  p.used = ((offset + 7) & ~(size_t)7) + 8ull*n;
  uint32_t *order = alloc(&p, 4ull*n, 4);
  if (!order) goto quota;
  uint32_t count = 0;
  for (uint32_t u = 0; u < n; u++)
    if (fast.a[u] != INF) order[count++] = u;
  order_up(order, count, fast.a);
  /* Restrict slack states to prefixes reachable from this query's start. */
  Table from;
  if (!table(&p, n, rows, to, duration, weight, goals, (int32_t)start, 1, -1, &from))
    goto quota;
  s->runs++;
  int64_t *width = from.a;
  for (uint32_t v = 0; v < n; v++)
    width[v] = width[v] == INF || fast.a[v] == INF ? -1 :
               (int64_t)deadline-width[v]-fast.a[v];
  p.used = (size_t)((uint8_t *)(width+n)-arena);
  uint32_t slack = deadline - (uint32_t)fast.a[start], maxdelta = 0;
  for (uint32_t i = 0; i < count; i++) {
    uint32_t u = order[i];
    for (uint32_t e = rows[u]; e < rows[u+1]; e++) {
      if (fast.a[to[e]] == INF) continue;
      int64_t d = (int64_t)duration[e] + fast.a[to[e]] - fast.a[u];
      if (d < 0) return -1;
      if (d <= slack && d > maxdelta) maxdelta = (uint32_t)d;
    }
  }
  size_t layers = (size_t)maxdelta + 1;
  int64_t *values = alloc(&p, layers*8ull*n, 8);
  if (!values) goto quota;
  size_t policy_layers = (capacity - p.used)/(4ull*n);
  if (!policy_layers) goto quota;
  if (policy_layers > (size_t)slack + 1) policy_layers = (size_t)slack + 1;
  if (mode == 1) policy_layers = 1; /* recomputation ablation */
  uint32_t *policy = alloc(&p, policy_layers*4ull*n, 4);
  if (!policy) goto quota;
  uint32_t u = start, remaining = slack, length = 0;
  int64_t total = 0, travel = 0, expected = INF;
  /* Retain a bounded suffix of policy layers; recompute older layers on demand. */
  for (;;) {
    for (size_t j = 0; j < layers*n; j++) values[j] = INF;
    for (uint32_t k = 0; k <= remaining; k++) {
      int64_t *row = values + (k % layers)*n;
      uint32_t *choice = policy + (k % policy_layers)*n;
      for (uint32_t v = 0; v < n; v++) { row[v] = INF; choice[v] = NONE; }
      for (uint32_t i = 0; i < count; i++) {
        uint32_t v = order[i];
        if (width[v] < k) continue;
        if (goals[v]) { row[v] = 0; continue; }
        for (uint32_t e = rows[v]; e < rows[v+1]; e++) {
          uint32_t w = to[e];
          if (fast.a[w] == INF) continue;
          int64_t d = (int64_t)duration[e] + fast.a[w] - fast.a[v];
          if (d > k) continue;
          int64_t child = values[((k-(uint32_t)d) % layers)*n+w];
          if (child != INF && child <= INF-weight[e] && child+weight[e] < row[v]) {
            row[v] = child+weight[e]; choice[v] = e;
          }
        }
      }
      if (s->states <= UINT32_MAX-count) s->states += count;
    }
    s->runs++;
    int64_t best = values[(remaining % layers)*n+u];
    if (best == INF || (expected != INF && best != expected)) return -1;
    if (!length) s->cost = best;
    uint32_t low = remaining >= policy_layers ? remaining-(uint32_t)policy_layers+1 : 0;
    for (;;) {
      if (length >= n) return -1;
      route[length++] = u;
      if (goals[u]) {
        if (total != s->cost || travel > deadline) return -1;
        s->route_length = length; s->travel = travel; s->optimal = 1; goto done;
      }
      uint32_t e = policy[(remaining % policy_layers)*n+u];
      if (e == NONE) return -1;
      uint32_t v = to[e];
      uint32_t d = (uint32_t)((int64_t)duration[e]+fast.a[v]-fast.a[u]);
      remaining -= d; total += weight[e]; travel += duration[e];
      expected = s->cost-total; u = v;
      if (remaining < low) break;
    }
  }
quota:
  s->peak = p.peak; return -2;
done:
  if (s->optimal && s->feasible) s->lower_bound = s->cost;
  s->peak = p.peak; return 1;
}
