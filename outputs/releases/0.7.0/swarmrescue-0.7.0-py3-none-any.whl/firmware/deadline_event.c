/* Research-only residual-clock DP. Reuses unchanged legacy certificates. */
#define ember_deadline_exact ember_deadline_legacy
#include "deadline_exact.c"
#undef ember_deadline_exact

static void order_down(uint32_t *order, uint32_t count, uint32_t i,
                       const int64_t *b) {
  for (;;) {
    uint32_t j = i*2+1;
    if (j >= count) return;
    if (j+1 < count && b[order[j+1]] > b[order[j]]) j++;
    if (b[order[i]] >= b[order[j]]) return;
    uint32_t v = order[i]; order[i] = order[j]; order[j] = v; i = j;
  }
}
static void order_up(uint32_t *order, uint32_t count, const int64_t *b) {
  for (uint32_t i = count/2; i; i--) order_down(order, count, i-1, b);
  for (uint32_t end = count; end > 1; end--) {
    uint32_t v = order[0]; order[0] = order[end-1]; order[end-1] = v;
    order_down(order, end-1, 0, b);
  }
}
static int slack_fast(Pool *p, uint32_t n, const uint32_t *rows,
                      const uint32_t *to, const uint32_t *duration,
                      const int64_t *weight, const uint8_t *goals, Table *t) {
  for (uint32_t e = 0; e < rows[n]; e++)
    if (duration[e] != 1)
      return table(p, n, rows, to, duration, weight, goals, -1, 1, -1, t);
  t->a = alloc(p, 8ull*n, 8); t->b = alloc(p, 8ull*n, 8);
  t->next = alloc(p, 4ull*n, 4);
  if (!t->a || !t->b || !t->next) return 0;
  size_t mark = p->used;
  uint32_t *queue = alloc(p, 4ull*n, 4);
  if (!queue) return 0;
  uint32_t head = 0, tail = 0;
  for (uint32_t u = 0; u < n; u++) {
    t->a[u] = t->b[u] = INF; t->next[u] = NONE;
    if (goals[u]) { t->a[u] = t->b[u] = 0; queue[tail++] = u; }
  }
  while (head < tail) {
    uint32_t u = queue[head++];
    for (uint32_t e = rows[u]; e < rows[u+1]; e++) {
      uint32_t v = to[e];
      if (t->b[u] > INF-weight[e]) continue;
      int64_t cost = t->b[u]+weight[e];
      if (t->a[v] == INF) {
        t->a[v] = t->a[u]+1; t->b[v] = cost;
        t->next[v] = u; queue[tail++] = v;
      } else if (t->a[v] == t->a[u]+1 && cost < t->b[v]) {
        t->b[v] = cost; t->next[v] = u;
      }
    }
  }
  p->used = mark; return 1;
}

/* Unit-clock distances are integer layers below N. An indexed bucket frontier
   respects the zero-resource topological order without comparison-heap work. */
static void event_push(Heap *h, uint32_t v, int buckets, uint32_t n,
                       uint32_t *minimum) {
  if (!buckets) { push(h, v); return; }
  if (h->pos[v] != NONE) return;
  uint32_t layer = (uint32_t)h->a[v];
  if (layer >= n) return;
  h->pos[v] = h->nodes[layer]; h->nodes[layer] = v; h->count++;
  if (layer < *minimum) *minimum = layer;
}
static uint32_t event_pop(Heap *h, int buckets, uint32_t n, uint32_t *minimum) {
  if (!buckets) return pop(h);
  while (*minimum < n && h->nodes[*minimum] == n) (*minimum)++;
  if (*minimum == n) return NONE;
  uint32_t v = h->nodes[*minimum];
  h->nodes[*minimum] = h->pos[v]; h->pos[v] = NONE; h->count--;
  return v;
}
static int prefix_times(Pool *p, uint32_t n, const uint32_t *rows,
                        const uint32_t *to, uint32_t start, int64_t **distance) {
  *distance = alloc(p, 8ull*n, 8);
  if (!*distance) return 0;
  size_t mark = p->used;
  uint32_t *queue = alloc(p, 4ull*n, 4);
  if (!queue) return 0;
  for (uint32_t v = 0; v < n; v++) (*distance)[v] = INF;
  (*distance)[start] = 0; queue[0] = start;
  uint32_t head = 0, tail = 1;
  while (head < tail) {
    uint32_t u = queue[head++];
    for (uint32_t e = rows[u]; e < rows[u+1]; e++)
      if ((*distance)[to[e]] == INF) {
        (*distance)[to[e]] = (*distance)[u]+1; queue[tail++] = to[e];
      }
  }
  p->used = mark; return 1;
}

int ember_deadline_event(uint32_t n, const uint32_t *rows, const uint32_t *to,
                         const uint32_t *duration, const int64_t *weight,
                         const uint32_t *rr, const uint32_t *rt,
                         const uint32_t *rd, const int64_t *rw,
                         const uint8_t *goals, uint32_t start,
                         uint32_t deadline, uint32_t label_limit, uint32_t mode,
                         uint8_t *arena, size_t capacity, size_t offset,
                         uint32_t *route, ember_deadline_stats *s) {
  (void)label_limit;
  memset(s, 0, sizeof(*s));
  if (!n || start >= n || offset > capacity || mode > 4 || deadline >= INT32_MAX)
    return -1;
  Pool p = {arena, offset, capacity, offset};
  Table fast;
  if (!slack_fast(&p, n, rr, rt, rd, rw, goals, &fast)) goto quota;
  s->runs = 1;
  if (fast.a[start] == INF || fast.a[start] > deadline) {
    s->optimal = 1; goto done;
  }
  s->feasible = 1;
  s->cost = fast.b[start]; s->travel = fast.a[start];
  s->route_length = witness(n, start, goals, fast.next, route);
  if (!s->route_length) return -1;
  if (s->travel == deadline || goals[start]) {
    s->optimal = 1; goto done;
  }
  /* The fastest witness is already in route; retain only its time field. */
  p.used = ((offset + 7) & ~(size_t)7) + 8ull*n;
  Table cheap;
  if (!table(&p, n, rr, rt, rd, rw, goals, -1, 0, (int32_t)start, &cheap)) goto quota;
  s->runs++;
  s->lower_bound = cheap.a[start];
  if (cheap.b[start] <= deadline) {
    s->cost = cheap.a[start]; s->travel = cheap.b[start];
    s->route_length = witness(n, start, goals, cheap.next, route);
    if (!s->route_length) return -1;
    s->optimal = 1; goto done;
  }
  /* Labels are a fast exact front end; an exhausted frontier hands off to
     the bounded event recurrence. No search quota is silently increased. */
  if (mode != 4 && search(&p, n, rows, to, duration, weight, goals, start,
                         deadline, label_limit, 1, fast, cheap, route, s)) {
    s->optimal = 1; goto done;
  }
  /* Preserve only the exact time potential, reclaim the other fields. */
  p.used = ((offset + 7) & ~(size_t)7) + 8ull*n;
  uint32_t *order = alloc(&p, 4ull*n, 4);
  if (!order) goto quota;
  uint32_t count = 0;
  for (uint32_t u = 0; u < n; u++)
    if (fast.a[u] != INF) order[count++] = u;
  order_up(order, count, fast.a);
  /* Restrict slack states to prefixes reachable from this query's start. */
  int uniform = 1;
  for (uint32_t e = 0; e < rows[n]; e++)
    if (duration[e] != 1) { uniform = 0; break; }
  int64_t *width;
  if (uniform) {
    if (!prefix_times(&p, n, rows, to, start, &width)) goto quota;
  } else {
    Table from;
    if (!table(&p, n, rows, to, duration, weight, goals, (int32_t)start, 1, -1, &from))
      goto quota;
    width = from.a;
  }
  s->runs++;
  for (uint32_t v = 0; v < n; v++)
    width[v] = width[v] == INF || fast.a[v] == INF ? -1 :
               (int64_t)deadline-width[v]-fast.a[v];
  p.used = (size_t)((uint8_t *)(width+n)-arena);
  uint32_t slack = deadline - (uint32_t)fast.a[start], maxdelta = 0;
  for (uint32_t i = 0; i < count; i++) {
    uint32_t u = order[i];
    for (uint32_t e = rows[u]; e < rows[u+1]; e++) {
      if (fast.a[to[e]] == INF) continue;
      int64_t d = (int64_t)duration[e] + fast.a[to[e]] - fast.a[u];
      if (d < 0) return -1;
      if (d <= slack && d > maxdelta) maxdelta = (uint32_t)d;
    }
  }
  /* Exact quotient by the gcd of reachable reduced durations. */
  uint32_t divisor = 0;
  if (mode != 1) {
    for (uint32_t i = 0; i < count; i++) {
      uint32_t v = order[i];
      for (uint32_t e = rows[v]; e < rows[v+1]; e++) {
        if (fast.a[to[e]] == INF) continue;
        int64_t delta = (int64_t)duration[e]+fast.a[to[e]]-fast.a[v];
        if (delta > slack || delta == 0) continue;
        uint32_t x = (uint32_t)delta, y = divisor;
        while (y) { uint32_t rem = x % y; x = y; y = rem; }
        divisor = x;
      }
    }
  }
  if (!divisor) divisor = 1;
  slack /= divisor; maxdelta /= divisor;
  for (uint32_t v = 0; v < n; v++)
    if (width[v] >= 0) width[v] /= divisor;
  size_t layers = maxdelta ? maxdelta : 1;
  int64_t *field = alloc(&p, 8ull*n, 8);
  int64_t *events = alloc(&p, layers*8ull*n, 8);
  uint32_t *event_policy = alloc(&p, layers*4ull*n, 4);
  uint32_t *heap_nodes = alloc(&p, 4ull*n, 4);
  uint32_t *heap_pos = alloc(&p, 4ull*n, 4);
  if (!field || !events || !event_policy || !heap_nodes || !heap_pos) goto quota;
  size_t policy_layers = (capacity-p.used)/(4ull*n);
  if (!policy_layers) goto quota;
  if (policy_layers > (size_t)slack+1) policy_layers = (size_t)slack+1;
  uint32_t *policy = alloc(&p, policy_layers*4ull*n, 4);
  if (!policy) goto quota;
  uint32_t u = start, remaining = slack, length = 0;
  int64_t total = 0, travel = 0, expected = INF;
  for (;;) {
    for (size_t j = 0; j < layers*n; j++) {
      events[j] = INF; event_policy[j] = NONE;
    }
    uint32_t *choice = policy;
    uint64_t pending = 0;
    for (uint32_t v = 0; v < n; v++) {
      field[v] = INF; choice[v] = NONE; heap_pos[v] = NONE;
      if (uniform) heap_nodes[v] = n;
    }
    /* Zero-resource DAG closure gives the exact k=0 suffix field. */
    for (uint32_t i = 0; i < count; i++) {
      uint32_t v = order[i];
      if (width[v] < 0) continue;
      if (goals[v]) { field[v] = 0; continue; }
      for (uint32_t e = rows[v]; e < rows[v+1]; e++) {
        uint32_t w = to[e];
        if (fast.a[w] == INF || field[w] == INF) continue;
        int64_t d = (int64_t)duration[e]+fast.a[w]-fast.a[v];
        if (d != 0 || field[w] > INF-weight[e]) continue;
        if (field[w]+weight[e] < field[v]) {
          field[v] = field[w]+weight[e]; choice[v] = e;
        }
      }
    }
    /* The event and synchronous ablation share all preprocessing and storage. */
    for (uint32_t k = 0; k <= remaining; k++) {
      uint32_t *previous = choice;
      choice = policy + (k % policy_layers)*n;
      if (k && previous != choice) memcpy(choice, previous, 4ull*n);
      Heap active = {heap_nodes, heap_pos, 0, fast.a, fast.a};
      uint32_t minimum = n;
      size_t slot = (k % layers)*n;
      if (k) {
        for (uint32_t v = 0; v < n; v++) {
          if (events[slot+v] != INF) pending--;
          if (events[slot+v] < field[v]) {
            field[v] = events[slot+v]; choice[v] = event_policy[slot+v];
            event_push(&active, v, uniform, n, &minimum);
          }
          events[slot+v] = INF; event_policy[slot+v] = NONE;
        }
      } else {
        for (uint32_t i = 0; i < count; i++)
          if (field[order[i]] != INF) event_push(&active, order[i], uniform, n, &minimum);
      }
      if (mode == 2 && k) {
        /* Dense scheduling ablation: all nodes, same recurrence and lattice. */
        for (uint32_t i = 0; i < count; i++)
          if (field[order[i]] != INF) event_push(&active, order[i], uniform, n, &minimum);
      }
      while (active.count) {
        uint32_t w = event_pop(&active, uniform, n, &minimum);
        if (w == NONE) return -1;
        if (s->expanded != UINT32_MAX) s->expanded++;
        for (uint32_t re = rr[w]; re < rr[w+1]; re++) {
          uint32_t v = rt[re];
          if (fast.a[v] == INF || goals[v] || field[w] > INF-rw[re]) continue;
          int64_t raw = (int64_t)rd[re]+fast.a[w]-fast.a[v];
          if (raw > (int64_t)remaining*divisor) continue;
          uint32_t d = (uint32_t)(raw/divisor);
          if (d > remaining-k || width[v] < (int64_t)k+d) continue;
          int64_t candidate = field[w]+rw[re];
          if (candidate >= field[v]) continue;
          /* Map the reverse incidence to an actual forward witness arc. */
          uint32_t e = rows[v];
          while (e < rows[v+1] &&
                 (to[e] != w || duration[e] != rd[re] || weight[e] != rw[re])) e++;
          if (e == rows[v+1]) return -1;
          if (!d) {
            field[v] = candidate; choice[v] = e; event_push(&active, v, uniform, n, &minimum);
          } else {
            size_t next = ((k+d) % layers)*n+v;
            if (candidate < events[next]) {
              if (events[next] == INF) pending++;
              events[next] = candidate; event_policy[next] = e;
            }
          }
        }
      }
      if (s->states <= UINT32_MAX-count) s->states += count;
      if (!pending && mode != 3 && k < remaining) {
        /* No future strict improvement can be created without a pending cause.
           Preserve historical layers; only fill the future retained window. */
        uint32_t first = remaining >= policy_layers ?
                         remaining-(uint32_t)policy_layers+1 : 0;
        if (first <= k) first = k+1;
        /* Save the current policy before any circular slot can overwrite it. */
        memcpy(event_policy, choice, 4ull*n);
        for (uint32_t j = first; j <= remaining; j++)
          memcpy(policy+(j % policy_layers)*n, event_policy, 4ull*n);
        break;
      }
    }
    s->runs++;
    int64_t best = field[u];
    if (best == INF || (expected != INF && best != expected)) return -1;
    if (!length) s->cost = best;
    uint32_t low = remaining >= policy_layers ? remaining-(uint32_t)policy_layers+1 : 0;
    for (;;) {
      if (length >= n) return -1;
      route[length++] = u;
      if (goals[u]) {
        if (total != s->cost || travel > deadline) return -1;
        s->route_length = length; s->travel = travel; s->optimal = 1; goto done;
      }
      uint32_t e = policy[(remaining % policy_layers)*n+u];
      if (e == NONE) return -1;
      uint32_t v = to[e];
      uint32_t d = (uint32_t)(((int64_t)duration[e]+fast.a[v]-fast.a[u])/divisor);
      if (d > remaining) return -1;
      remaining -= d; total += weight[e]; travel += duration[e];
      expected = s->cost-total; u = v;
      if (remaining < low) break;
    }
  }

quota:
  s->peak = p.peak; return -2;
done:
  if (s->optimal && s->feasible) s->lower_bound = s->cost;
  s->peak = p.peak; return 1;
}
