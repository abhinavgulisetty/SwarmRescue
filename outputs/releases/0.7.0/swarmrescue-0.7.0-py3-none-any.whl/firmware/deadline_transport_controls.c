/* Post-hoc fairness control: ingest only changed arcs for incremental DP.
 * Primary frozen sources are unchanged. */
#include "deadline_transport.c"
int ember_sparse_dp_update(Transport *x,uint32_t start,uint32_t deadline,
 uint32_t count,const uint32_t *edges,const int64_t *costs) {
  if (!x || start>=x->h->n || deadline>x->capacity || x->mode!=3) return -1;
  Engine *h=x->h;
  for (uint32_t i=0;i<count;i++)
    if (edges[i]>=h->m || costs[i]<=0 || costs[i]>=INT32_MAX) return -1;
  uint32_t old_deadline=x->deadline;
  x->start=h->start=start;x->deadline=h->deadline=deadline;
  h->states=(size_t)h->n*(deadline+1);x->patches+=count;
  for (uint32_t i=0;i<count;i++) {
    uint32_t e=edges[i];
    if (x->cost[e]!=costs[i] && h->time[e]<=deadline)
      for (uint32_t t=h->time[e];t<=deadline;t++) mark(h,t,h->from[e]);
    x->cost[e]=costs[i];
  }
  if (deadline>old_deadline) {
    /* No outstanding flags may survive an all-values reconstruction. */
    memset(h->dirty,0,8*h->words*(x->capacity+1));
    memset(h->counts,0,4ull*(x->capacity+1));
    return build(h,x->cost) ? 3 : -1;
  }
  for (uint32_t t=0;t<=deadline;t++) {
    if (!h->counts[t]) continue;
    for (size_t word=0;word<h->words;word++) {
      uint64_t bits=h->dirty[(size_t)t*h->words+word];
      h->dirty[(size_t)t*h->words+word]=0;
      while (bits) {
        uint32_t v=(uint32_t)(64*word+__builtin_ctzll(bits));bits&=bits-1;
        h->counts[t]--;h->recomputed++;
        int64_t best=INF;
        for (uint32_t e=h->rows[v];e<h->rows[v+1];e++) if (h->time[e]<=t) {
          int64_t value=add(x->cost[e],h->values[(size_t)(t-h->time[e])*h->n+h->to[e]]);
          if (value<best) best=value;
        }
        size_t index=(size_t)t*h->n+v;
        if (best!=h->values[index]) {
          h->values[index]=best;
          for (uint32_t j=h->reverse_rows[v];j<h->reverse_rows[v+1];j++) {
            uint32_t e=h->reverse_edges[j];
            if (h->time[e]<=deadline-t) mark(h,t+h->time[e],h->from[e]);
          }
        }
      }
    }
  }
  h->optimum=h->values[(size_t)deadline*h->n+start];
  return make_route(h,x->cost,h->values) ? 3 : -1;
}
