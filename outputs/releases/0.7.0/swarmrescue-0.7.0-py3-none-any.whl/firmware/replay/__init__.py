"""Freestanding conformance replay assets."""
