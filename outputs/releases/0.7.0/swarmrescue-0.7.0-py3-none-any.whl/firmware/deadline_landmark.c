/* Source-aware monotone clock cuts for a transported certificate. */
#include "deadline_transport.c"
typedef struct {
  Transport *x;
  uint32_t k,*order,*full_rank,*disabled,*cut;
  int64_t *potential,*score;
  size_t extra,peak;
} Landmark;
static int64_t threshold(Landmark *l,uint32_t cut,uint32_t start,uint32_t deadline) {
  return add(l->potential[(size_t)cut*l->x->h->n+start],deadline);
}
static void landmark_sync(Landmark *l) {
  Transport *x=l->x;Engine *h=x->h;
  for (uint32_t v=0;v<h->n;v++) {
    l->full_rank[v]=x->rank[v];if (l->disabled[v]) x->rank[v]=NONE;
  }
}
void ember_landmark_destroy(Landmark *l) {
  if (!l) return;
  ember_transport_destroy(l->x);free(l->order);free(l->full_rank);free(l->disabled);
  free(l->cut);free(l->potential);free(l->score);free(l);
}
Landmark *ember_landmark_create(uint32_t n,uint32_t m,const uint32_t *rows,
 const uint32_t *to,const uint32_t *time,const uint32_t *from,
 const uint32_t *rr,const uint32_t *re,const uint8_t *goals,
 uint32_t start,uint32_t deadline,const int64_t *cost,uint32_t mode,size_t budget) {
  (void)mode;
  Landmark *l=calloc(1,sizeof(*l));if (!l) return NULL;
  l->k=1+(n<4 ? n : 4);
  l->extra=sizeof(*l)+20ull*l->k*n+8ull*n+4ull*l->k;
  if (l->extra>=budget) { free(l);return NULL; }
  l->x=ember_transport_create(n,m,rows,to,time,from,rr,re,goals,start,deadline,cost,0,budget-l->extra);
  if (!l->x) { free(l);return NULL; }
  l->order=malloc(4ull*l->k*n);l->potential=calloc((size_t)l->k*n,8);
  l->score=malloc(8ull*l->k*n);l->full_rank=malloc(4ull*n);
  l->disabled=calloc(n,4);l->cut=malloc(4ull*l->k);
  size_t scratch=8ull*m+33ull*n;
  size_t retained=l->x->h->retained+l->x->extra+l->extra;
  if (!l->order || !l->potential || !l->score || !l->full_rank || !l->disabled || !l->cut ||
      scratch>budget-retained) { ember_landmark_destroy(l);return NULL; }
  void *temporary=malloc(scratch ? scratch : 1);
  if (!temporary) { ember_landmark_destroy(l);return NULL; }
  int64_t *tc=temporary,*witness=tc+m,*nearest=witness+n,*back=nearest+n;
  uint32_t *heap=(uint32_t *)(back+n),*position=heap+n;
  uint8_t *zero_goals=(uint8_t *)(position+n);memset(zero_goals,0,n);
  for (uint32_t e=0;e<m;e++) tc[e]=time[e];
  Queue q={heap,position,0,back,witness};shortest(l->x->h,tc,1,&q);
  for (uint32_t v=0;v<n;v++) { l->score[v]=back[v];nearest[v]=INF; }
  Engine *h=l->x->h;uint32_t landmark=start;
  for (uint32_t j=1;j<l->k;j++) {
    h->start=landmark;h->goals=zero_goals;
    q.distance=l->potential+(size_t)j*n;shortest(h,tc,0,&q);
    h->start=start;h->goals=goals;
    for (uint32_t v=0;v<n;v++) {
      int64_t distance=l->potential[(size_t)j*n+v];
      l->score[(size_t)j*n+v]=add(distance,back[v]);
      if (distance<nearest[v]) nearest[v]=distance;
    }
    landmark=0;
    for (uint32_t v=1;v<n;v++) if (nearest[v]>nearest[landmark]) landmark=v;
  }
  for (uint32_t j=0;j<l->k;j++) {
    Engine ordering={0};ordering.n=n;ordering.order=l->order+(size_t)j*n;
    ordering.gap=l->score+(size_t)j*n;gap_order(&ordering);
    int64_t bound=threshold(l,j,start,deadline);l->cut[j]=0;
    while (l->cut[j]<n && l->score[(size_t)j*n+l->order[(size_t)j*n+l->cut[j]]]<=bound) l->cut[j]++;
    for (uint32_t i=l->cut[j];i<n;i++) l->disabled[l->order[(size_t)j*n+i]]++;
  }
  free(temporary);landmark_sync(l);l->peak=retained+scratch;
  return l;
}
int ember_landmark_update(Landmark *l,uint32_t start,uint32_t deadline,
 uint32_t count,const uint32_t *edges,const int64_t *costs) {
  if (!l || start>=l->x->h->n || deadline>l->x->capacity) return -1;
  Transport *x=l->x;Engine *h=x->h;
  for (uint32_t i=0;i<count;i++)
    if (edges[i]>=h->m || costs[i]<=0 || costs[i]>=INT32_MAX) return -1;
  for (uint32_t j=0;j<l->k;j++) {
    int64_t bound=threshold(l,j,start,deadline);
    while (l->cut[j] && l->score[(size_t)j*h->n+l->order[(size_t)j*h->n+l->cut[j]-1]]>bound) {
      uint32_t v=l->order[(size_t)j*h->n+--l->cut[j]];
      if (l->disabled[v]++==0) {
        uint32_t rank=x->rank[v];
        if (rank!=NONE && h->alternative_floor!=INF) {
          int64_t d=incoming_max(x,v);if (d) tree_suffix(x,1,0,x->finite,rank,d);
        }
        x->rank[v]=NONE;
      }
    }
    while (l->cut[j]<h->n && l->score[(size_t)j*h->n+l->order[(size_t)j*h->n+l->cut[j]]]<=bound) {
      uint32_t v=l->order[(size_t)j*h->n+l->cut[j]++];
      if (--l->disabled[v]==0) {
        uint32_t rank=l->full_rank[v];x->rank[v]=rank;
        if (rank!=NONE && h->alternative_floor!=INF) {
          int64_t d=incoming_max(x,v);if (d) tree_suffix(x,1,0,x->finite,rank,-d);
        }
      }
    }
  }
  int status=ember_transport_update(x,start,deadline,count,edges,costs);
  if (status==2) landmark_sync(l);
  return status;
}
int64_t ember_landmark_result(Landmark *l,uint32_t *route,uint32_t *length) {
  return ember_transport_result(l->x,route,length);
}
void ember_landmark_stats(Landmark *l,uint64_t *s) {
  ember_transport_stats(l->x,s);s[0]+=l->extra;s[1]+=l->extra;
  if (l->peak>s[1]) s[1]=l->peak;
}
