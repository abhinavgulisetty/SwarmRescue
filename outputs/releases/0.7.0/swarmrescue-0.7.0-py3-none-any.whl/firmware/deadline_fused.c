/* Fair software interface control: update and route output in one native call.
 * TARGET_UPDATE / TARGET_RESULT select an unchanged exact solver implementation.
 */
#include <stdint.h>
extern int TARGET_UPDATE(void *,uint32_t,uint32_t,uint32_t,const uint32_t *,const int64_t *);
extern int64_t TARGET_RESULT(void *,uint32_t *,uint32_t *);
int ember_fused_update(void *h,uint32_t start,uint32_t deadline,uint32_t count,
 const uint32_t *edges,const int64_t *costs,uint32_t *route,uint32_t *length,int64_t *value) {
  int status=TARGET_UPDATE(h,start,deadline,count,edges,costs);
  if (status>=0) *value=TARGET_RESULT(h,route,length);
  return status;
}
