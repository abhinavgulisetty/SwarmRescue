/* Research: coupled node-gap certificates and exact incremental Bellman repair.
   Fixed topology/clock/query; positive int32 arc costs. Host allocations counted. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#define INF INT64_MAX
#define NONE UINT32_MAX

typedef struct {
  uint32_t n, m, deadline, start, mode, length, dual_active;
  const uint32_t *rows, *to, *time, *from, *reverse_rows, *reverse_edges;
  const uint8_t *goals;
  int64_t *base, *gap, *deficit, *values;
  uint32_t *route, *route_edges, *order, *counts;
  uint64_t *dirty;
  int64_t optimum, anchor_optimum;
  int64_t alternative_floor;
  size_t states, words, retained, peak, builds, accepts, recomputed, budget, fast_builds;
} Engine;

static int64_t add(int64_t a, int64_t b) {
  return a == INF || b == INF || a > INF-b ? INF : a+b;
}
static int make_route(Engine *h, const int64_t *cost, const int64_t *b) {
  h->length = 0;
  if (h->optimum == INF) return 1;
  uint32_t u = h->start, remaining = h->deadline;
  while (h->length < h->n) {
    h->route[h->length++] = u;
    if (h->goals[u]) return 1;
    uint32_t chosen = NONE;
    int64_t current = b[(size_t)remaining*h->n+u];
    for (uint32_t e = h->rows[u]; e < h->rows[u+1]; e++)
      if (h->time[e] <= remaining &&
          add(cost[e], b[(size_t)(remaining-h->time[e])*h->n+h->to[e]]) == current) {
        chosen = e; break;
      }
    if (chosen == NONE) return 0;
    h->route_edges[h->length-1] = chosen;
    remaining -= h->time[chosen]; u = h->to[chosen];
  }
  return 0;
}
static void full_values(Engine *h, const int64_t *cost, int64_t *b) {
  for (uint32_t t = 0; t <= h->deadline; t++)
    for (uint32_t u = 0; u < h->n; u++) {
      int64_t best = h->goals[u] ? 0 : INF;
      if (!h->goals[u])
        for (uint32_t e = h->rows[u]; e < h->rows[u+1]; e++)
          if (h->time[e] <= t) {
            int64_t v = add(cost[e], b[(size_t)(t-h->time[e])*h->n+h->to[e]]);
            if (v < best) best = v;
          }
      b[(size_t)t*h->n+u] = best;
    }
}
static void gap_down(uint32_t *order, uint32_t count, uint32_t i, const int64_t *gap) {
  for (;;) {
    uint32_t j=2*i+1;
    if (j>=count) return;
    if (j+1<count && gap[order[j+1]]>gap[order[j]]) j++;
    if (gap[order[i]]>=gap[order[j]]) return;
    uint32_t v=order[i];order[i]=order[j];order[j]=v;i=j;
  }
}
static void gap_order(Engine *h) {
  for (uint32_t v=0;v<h->n;v++) h->order[v]=v;
  for (uint32_t i=h->n/2;i;i--) gap_down(h->order,h->n,i-1,h->gap);
  for (uint32_t end=h->n;end>1;end--) {
    uint32_t v=h->order[0];h->order[0]=h->order[end-1];h->order[end-1]=v;
    gap_down(h->order,end-1,0,h->gap);
  }
}
typedef struct {
  uint32_t *heap, *position, length;
  int64_t *distance, *clock;
} Queue;
static int before(Queue *q,uint32_t u,uint32_t v) {
  return q->distance[u]<q->distance[v] ||
    (q->distance[u]==q->distance[v] && q->clock[u]<q->clock[v]);
}
static void exchange(Queue *q,uint32_t i,uint32_t j) {
  uint32_t u=q->heap[i],v=q->heap[j];q->heap[i]=v;q->heap[j]=u;
  q->position[u]=j;q->position[v]=i;
}
static void push(Queue *q,uint32_t v) {
  uint32_t i=q->position[v];
  if (i==NONE) { i=q->length++;q->heap[i]=v;q->position[v]=i; }
  while (i && before(q,q->heap[i],q->heap[(i-1)/2])) {
    exchange(q,i,(i-1)/2);i=(i-1)/2;
  }
}
static uint32_t pop(Queue *q) {
  uint32_t v=q->heap[0];exchange(q,0,--q->length);q->position[v]=NONE;
  for (uint32_t i=0;;) {
    uint32_t j=2*i+1;if (j>=q->length) break;
    if (j+1<q->length && before(q,q->heap[j+1],q->heap[j])) j++;
    if (!before(q,q->heap[j],q->heap[i])) break;
    exchange(q,i,j);i=j;
  }
  return v;
}
static void shortest(Engine *h,const int64_t *cost,int reverse,Queue *q) {
  for (uint32_t v=0;v<h->n;v++) {
    q->distance[v]=INF;q->clock[v]=INF;q->position[v]=NONE;
  }
  q->length=0;
  if (reverse) {
    for (uint32_t v=0;v<h->n;v++) if (h->goals[v]) {
      q->distance[v]=q->clock[v]=0;push(q,v);
    }
  } else { q->distance[h->start]=q->clock[h->start]=0;push(q,h->start); }
  while (q->length) {
    uint32_t u=pop(q);
    if (!reverse && h->goals[u]) continue;
    uint32_t begin=reverse ? h->reverse_rows[u] : h->rows[u];
    uint32_t end=reverse ? h->reverse_rows[u+1] : h->rows[u+1];
    for (uint32_t j=begin;j<end;j++) {
      uint32_t e=reverse ? h->reverse_edges[j] : j;
      uint32_t v=reverse ? h->from[e] : h->to[e];
      int64_t d=add(q->distance[u],cost[e]),t=add(q->clock[u],h->time[e]);
      if (d<q->distance[v] || (d==q->distance[v] && t<q->clock[v])) {
        q->distance[v]=d;q->clock[v]=t;push(q,v);
      }
    }
  }
}
/* When a cheapest unconstrained route meets the deadline, two Dijkstra passes
   give sound node/alternative margins without time expansion. */
static int fast_build(Engine *h,const int64_t *cost) {
  size_t bytes=32ull*h->n;
  if (bytes>h->budget-h->retained) return 0;
  void *scratch=malloc(bytes);if (!scratch) return 0;
  if (h->retained+bytes>h->peak) h->peak=h->retained+bytes;
  int64_t *a=scratch,*b=a+h->n,*clock=b+h->n;
  uint32_t *heap=(uint32_t *)(clock+h->n),*position=heap+h->n;
  Queue q={heap,position,0,b,clock};
  shortest(h,cost,1,&q);
  if (b[h->start]==INF || clock[h->start]>h->deadline) { free(scratch);return 0; }
  h->optimum=b[h->start];h->length=0;
  uint32_t u=h->start;
  while (h->length<h->n) {
    h->route[h->length++]=u;if (h->goals[u]) break;
    uint32_t chosen=NONE;
    for (uint32_t e=h->rows[u];e<h->rows[u+1];e++)
      if (add(cost[e],b[h->to[e]])==b[u] &&
          add(h->time[e],clock[h->to[e]])==clock[u]) { chosen=e;break; }
    if (chosen==NONE) { free(scratch);return -1; }
    h->route_edges[h->length-1]=chosen;u=h->to[chosen];
  }
  if (h->mode==4) {
    memcpy(h->values,b,8ull*h->n);memcpy(h->base,cost,8ull*h->m);
    h->anchor_optimum=h->optimum;h->dual_active=1;
    if (h->retained+bytes>h->peak) h->peak=h->retained+bytes;
    h->builds++;h->fast_builds++;free(scratch);return 1;
  }
  q.distance=a;shortest(h,cost,0,&q);
  for (uint32_t v=0;v<h->n;v++) {
    int64_t via=add(a[v],b[v]);h->gap[v]=via==INF ? INF : via-h->optimum;
    h->deficit[v]=NONE;
  }
  for (uint32_t j=0;j+1<h->length;j++) h->deficit[h->route[j]]=h->route_edges[j];
  h->alternative_floor=INF;
  for (uint32_t e=0;e<h->m;e++)
    if (!h->goals[h->from[e]] && (int64_t)e!=h->deficit[h->from[e]]) {
      int64_t via=add(add(a[h->from[e]],cost[e]),b[h->to[e]]);
      if (via!=INF && via-h->optimum<h->alternative_floor)
        h->alternative_floor=via-h->optimum;
    }
  gap_order(h);memcpy(h->base,cost,8ull*h->m);
  if (h->retained+bytes>h->peak) h->peak=h->retained+bytes;
  h->anchor_optimum=h->optimum;h->builds++;h->fast_builds++;free(scratch);return 1;
}
static int build(Engine *h, const int64_t *cost) {
  if (h->mode<2 || h->mode==4) {
    int status=fast_build(h,cost);if (status) return status>0;
    h->dual_active=0;
  }
  size_t bytes = 8*h->states;
  int64_t *b = h->mode==4 ? NULL : h->values;
  if (!b) {
    if (bytes > h->budget-h->retained) return 0;
    b = malloc(bytes);
    if (!b) return 0;
  }
  full_values(h, cost, b);
  h->optimum = b[(size_t)h->deadline*h->n+h->start];
  if (!make_route(h, cost, b)) { if (b!=h->values) free(b); return 0; }
  size_t working = h->retained+(b==h->values ? 0 : bytes);
  if (h->mode < 2) {
    if (bytes > h->budget-working) { free(b); return 0; }
    int64_t *a = malloc(bytes);
    if (!a) { free(b); return 0; }
    for (size_t i = 0; i < h->states; i++) a[i] = INF;
    a[h->start] = 0;
    for (uint32_t t = 0; t <= h->deadline; t++)
      for (uint32_t u = 0; u < h->n; u++) {
        int64_t prefix = a[(size_t)t*h->n+u];
        if (prefix == INF || h->goals[u]) continue;
        for (uint32_t e = h->rows[u]; e < h->rows[u+1]; e++)
          if (h->time[e] <= h->deadline-t) {
            size_t index = (size_t)(t+h->time[e])*h->n+h->to[e];
            int64_t v = add(prefix, cost[e]);
            if (v < a[index]) a[index] = v;
          }
      }
    for (uint32_t v = 0; v < h->n; v++) {
      int64_t via = INF;
      for (uint32_t t = 0; t <= h->deadline; t++) {
        int64_t total = add(a[(size_t)t*h->n+v], b[(size_t)(h->deadline-t)*h->n+v]);
        if (total < via) via = total;
      }
      h->gap[v] = via == INF || h->optimum == INF ? INF : via-h->optimum;
      if (h->gap[v] < 0) { free(a); free(b); return 0; }
      h->deficit[v]=NONE;
    }
    for (uint32_t j=0;j+1<h->length;j++) h->deficit[h->route[j]]=h->route_edges[j];
    h->alternative_floor=INF;
    for (uint32_t t=0;t<=h->deadline;t++)
      for (uint32_t u=0;u<h->n;u++) {
        if (h->goals[u]) continue;
        for (uint32_t e=h->rows[u];e<h->rows[u+1];e++)
          if (h->time[e]<=h->deadline-t && (int64_t)e!=h->deficit[u]) {
            int64_t via=add(add(a[(size_t)t*h->n+u],cost[e]),
              b[(size_t)(h->deadline-t-h->time[e])*h->n+h->to[e]]);
            if (via!=INF && h->optimum!=INF && via-h->optimum<h->alternative_floor)
              h->alternative_floor=via-h->optimum;
          }
      }
    gap_order(h);
    working += bytes;
    free(a);
  }
  if (working > h->peak) h->peak = working;
  if (b!=h->values) free(b);
  memcpy(h->base, cost, 8ull*h->m);
  h->anchor_optimum=h->optimum;
  h->builds++;
  return 1;
}
void ember_retention_destroy(Engine *h) {
  if (!h) return;
  free(h->base); free(h->gap); free(h->deficit); free(h->values);
  free(h->route); free(h->route_edges); free(h->order);
  free(h->counts); free(h->dirty); free(h);
}
Engine *ember_retention_create(uint32_t n, uint32_t m, const uint32_t *rows,
 const uint32_t *to, const uint32_t *time, const uint32_t *from,
 const uint32_t *reverse_rows, const uint32_t *reverse_edges, const uint8_t *goals,
 uint32_t start, uint32_t deadline, const int64_t *cost, uint32_t mode, size_t budget) {
  if (!n || start >= n || mode > 4 || deadline >= INT32_MAX) return NULL;
  if ((size_t)n > SIZE_MAX/((size_t)deadline+1)/8) return NULL;
  Engine *h = calloc(1, sizeof(*h));
  if (!h) return NULL;
  h->n=n; h->m=m; h->rows=rows; h->to=to; h->time=time; h->from=from;
  h->reverse_rows=reverse_rows; h->reverse_edges=reverse_edges; h->goals=goals;
  h->start=start; h->deadline=deadline; h->mode=mode; h->budget=budget;
  h->states=(size_t)n*(deadline+1); h->words=((size_t)n+63)/64;
  if (mode<2 && h->states>SIZE_MAX/16) { ember_retention_destroy(h);return NULL; }
  h->retained=sizeof(*h)+(m ? 8ull*m : 1)+8ull*n;
  if (mode < 2) h->retained += 20ull*n;
  else h->retained += mode==4 ? 8ull*n : 8*h->states;
  if (mode == 2) h->retained += 8*h->words*(deadline+1)+4ull*(deadline+1);
  if (h->retained > budget || (mode < 2 && 16*h->states > budget-h->retained)) {
    ember_retention_destroy(h); return NULL;
  }
  h->base=malloc(m ? 8ull*m : 1); h->route=malloc(4ull*n); h->route_edges=malloc(4ull*n);
  if (mode < 2) {
    h->gap=malloc(8ull*n); h->deficit=malloc(8ull*n); h->order=malloc(4ull*n);
    if (!h->gap || !h->deficit || !h->order) { ember_retention_destroy(h); return NULL; }
  } else {
    h->values=malloc(mode==4 ? 8ull*n : 8*h->states);
    if (!h->values) { ember_retention_destroy(h); return NULL; }
  }
  if (mode == 2) {
    h->dirty=calloc(h->words*(deadline+1),8); h->counts=calloc(deadline+1,4);
    if (!h->dirty || !h->counts) { ember_retention_destroy(h); return NULL; }
  }
  if (!h->base || !h->route || !h->route_edges) { ember_retention_destroy(h); return NULL; }
  for (uint32_t e=0;e<m;e++)
    if (to[e]>=n || from[e]>=n || !time[e] || cost[e]<=0 || cost[e]>=INT32_MAX) {
      ember_retention_destroy(h); return NULL;
    }
  h->peak=h->retained;
  if (!build(h,cost)) { ember_retention_destroy(h); return NULL; }
  return h;
}
static void mark(Engine *h, uint32_t t, uint32_t v) {
  if (h->goals[v]) return;
  size_t i=(size_t)t*h->words+v/64;
  uint64_t bit=1ull<<(v%64);
  if (!(h->dirty[i]&bit)) { h->dirty[i]|=bit; h->counts[t]++; }
}
static int repair(Engine *h, const int64_t *cost) {
  for (uint32_t e=0;e<h->m;e++)
    if (cost[e]!=h->base[e] && h->time[e]<=h->deadline)
      for (uint32_t t=h->time[e];t<=h->deadline;t++) mark(h,t,h->from[e]);
  for (uint32_t t=0;t<=h->deadline;t++) {
    if (!h->counts[t]) continue;
    for (size_t word=0;word<h->words;word++) {
      uint64_t bits=h->dirty[(size_t)t*h->words+word];
      h->dirty[(size_t)t*h->words+word]=0;
      while (bits) {
        uint32_t v=(uint32_t)(64*word+__builtin_ctzll(bits)); bits&=bits-1;
        h->counts[t]--; h->recomputed++;
        int64_t best=INF;
        for (uint32_t e=h->rows[v];e<h->rows[v+1];e++)
          if (h->time[e]<=t) {
            int64_t value=add(cost[e],h->values[(size_t)(t-h->time[e])*h->n+h->to[e]]);
            if (value<best) best=value;
          }
        size_t index=(size_t)t*h->n+v;
        if (best!=h->values[index]) {
          h->values[index]=best;
          for (uint32_t j=h->reverse_rows[v];j<h->reverse_rows[v+1];j++) {
            uint32_t e=h->reverse_edges[j];
            if (h->time[e]<=h->deadline-t) mark(h,t+h->time[e],h->from[e]);
          }
        }
      }
    }
  }
  memcpy(h->base,cost,8ull*h->m);
  h->optimum=h->values[(size_t)h->deadline*h->n+h->start];
  return make_route(h,cost,h->values);
}
/* Return 1: certified retention; 2: refreshed certificate; 3: repaired/full DP;
   -1 invalid input or a failed internal witness. */
int ember_retention_update(Engine *h, const int64_t *cost) {
  if (!h) return -1;
  for (uint32_t e=0;e<h->m;e++) if (cost[e]<=0 || cost[e]>=INT32_MAX) return -1;
  if (h->mode==2) return repair(h,cost) ? 3 : -1;
  if (h->mode==3) return build(h,cost) ? 3 : -1;
  if (h->mode==4) {
    int safe=h->dual_active;
    for (uint32_t e=0;e<h->m && safe;e++)
      if (!h->goals[h->from[e]] &&
          add(cost[e],h->values[h->to[e]])<h->values[h->from[e]]) safe=0;
    int64_t current=0;
    for (uint32_t j=0;j+1<h->length;j++) current=add(current,cost[h->route_edges[j]]);
    if (safe && current==h->anchor_optimum) { h->accepts++;return 1; }
    return build(h,cost) ? 2 : -1;
  }
  if (h->optimum==INF) { h->accepts++; return 1; }
  int64_t route_cost=0;
  for (uint32_t j=0;j+1<h->length;j++) route_cost=add(route_cost,cost[h->route_edges[j]]);
  int64_t shift=route_cost-h->anchor_optimum;
  if (shift>h->alternative_floor) return build(h,cost) ? 2 : -1;
  memset(h->deficit,0,8ull*h->n);
  for (uint32_t e=0;e<h->m;e++)
    if (h->base[e]>cost[e] && h->base[e]-cost[e]>h->deficit[h->to[e]])
      h->deficit[h->to[e]]=h->base[e]-cost[e];
  int safe=1;
  if (h->mode==1) {
    int64_t total=0, minimum=INF;
    for (uint32_t v=0;v<h->n;v++)
      if (h->deficit[v]>0 && h->gap[v]!=INF) {
        total=add(total,h->deficit[v]);
        if (h->gap[v]<minimum) minimum=h->gap[v];
      }
    if (minimum<h->alternative_floor) minimum=h->alternative_floor;
    safe=shift>=0 ? add(total,shift)<=minimum : total<=add(minimum,-shift);
  } else {
    int64_t sum=0;
    /* Gap order is compiled at certificate creation, not sorted per update. */
    for (uint32_t i=0;i<h->n;i++) {
      uint32_t v=h->order[i];
      if (h->gap[v]==INF) break;
      if (!h->deficit[v]) continue;
      sum=add(sum,h->deficit[v]);
      int64_t margin=h->gap[v]>h->alternative_floor ? h->gap[v] : h->alternative_floor;
      if (shift>=0 ? add(sum,shift)>margin : sum>add(margin,-shift)) { safe=0;break; }
    }
  }
  if (safe) { h->optimum=route_cost;h->accepts++;return 1; }
  return build(h,cost) ? 2 : -1;
}
int64_t ember_retention_result(Engine *h, uint32_t *route, uint32_t *length) {
  *length=h->length;memcpy(route,h->route,4ull*h->length);return h->optimum;
}
void ember_retention_stats(Engine *h, uint64_t *stats) {
  stats[0]=h->retained;stats[1]=h->peak;stats[2]=h->builds;
  stats[3]=h->accepts;stats[4]=h->recomputed;
  stats[5]=h->fast_builds;
}
int64_t ember_retention_floor(Engine *h) { return h->alternative_floor; }
void ember_retention_gaps(Engine *h, int64_t *gaps) {
  if (h->gap) memcpy(gaps,h->gap,8ull*h->n);
}
