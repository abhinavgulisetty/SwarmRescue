/* Research extension: budget-contracted transported certificates.
 * Frozen transport and CMR sources are unchanged. */
#include "deadline_transport.c"
typedef struct {
  Transport *x;
  int64_t *clock;
  uint32_t *clock_order,*full_rank,cut;
  size_t extra,peak;
  uint64_t removed;
} Contract;
static void contract_sync(Contract *c) {
  Transport *x=c->x;Engine *h=x->h;
  for (uint32_t v=0;v<h->n;v++) c->full_rank[v]=x->rank[v];
  c->cut=0;
  while (c->cut<h->n && c->clock[c->clock_order[c->cut]]<=x->deadline) c->cut++;
  /* A rebuilt certificate has no cumulative reductions, so excluding its
   * infeasible nodes needs no range update. */
  for (uint32_t i=c->cut;i<h->n;i++) x->rank[c->clock_order[i]]=NONE;
}
void ember_contract_destroy(Contract *c) {
  if (!c) return;
  ember_transport_destroy(c->x);free(c->clock);free(c->clock_order);free(c->full_rank);free(c);
}
Contract *ember_contract_create(uint32_t n,uint32_t m,const uint32_t *rows,
 const uint32_t *to,const uint32_t *time,const uint32_t *from,
 const uint32_t *rr,const uint32_t *re,const uint8_t *goals,
 uint32_t start,uint32_t deadline,const int64_t *cost,uint32_t mode,size_t budget) {
  (void)mode;
  Contract *c=calloc(1,sizeof(*c));if (!c) return NULL;
  c->extra=sizeof(*c)+16ull*n;
  if (c->extra>=budget) { free(c);return NULL; }
  c->x=ember_transport_create(n,m,rows,to,time,from,rr,re,goals,start,deadline,cost,0,budget-c->extra);
  if (!c->x) { free(c);return NULL; }
  c->clock=malloc(8ull*n);c->clock_order=malloc(4ull*n);c->full_rank=malloc(4ull*n);
  size_t scratch=8ull*m+16ull*n;
  size_t retained=c->x->h->retained+c->x->extra+c->extra;
  if (!c->clock || !c->clock_order || !c->full_rank || scratch>budget-retained) {
    ember_contract_destroy(c);return NULL;
  }
  int64_t *temporary=malloc(scratch ? scratch : 1);
  if (!temporary) { ember_contract_destroy(c);return NULL; }
  int64_t *clock_cost=temporary,*witness_clock=clock_cost+m;
  uint32_t *heap=(uint32_t *)(witness_clock+n),*position=heap+n;
  for (uint32_t e=0;e<m;e++) clock_cost[e]=time[e];
  Queue q={heap,position,0,c->clock,witness_clock};
  shortest(c->x->h,clock_cost,1,&q);
  Engine order={0};order.n=n;order.order=c->clock_order;order.gap=c->clock;gap_order(&order);
  free(temporary);contract_sync(c);
  c->peak=retained+scratch;
  return c;
}
int ember_contract_update(Contract *c,uint32_t start,uint32_t deadline,
 uint32_t count,const uint32_t *edges,const int64_t *costs) {
  if (!c || start>=c->x->h->n || deadline>c->x->capacity) return -1;
  Transport *x=c->x;Engine *h=x->h;
  for (uint32_t i=0;i<count;i++)
    if (edges[i]>=h->m || costs[i]<=0 || costs[i]>=INT32_MAX) return -1;
  while (c->cut && c->clock[c->clock_order[c->cut-1]]>deadline) {
    uint32_t v=c->clock_order[--c->cut],rank=x->rank[v];
    if (rank!=NONE && h->alternative_floor!=INF) {
      int64_t d=incoming_max(x,v);
      if (d) tree_suffix(x,1,0,x->finite,rank,d);
    }
    x->rank[v]=NONE;c->removed++;
  }
  while (c->cut<h->n && c->clock[c->clock_order[c->cut]]<=deadline) {
    uint32_t v=c->clock_order[c->cut++],rank=c->full_rank[v];
    x->rank[v]=rank;
    if (rank!=NONE && h->alternative_floor!=INF) {
      int64_t d=incoming_max(x,v);
      if (d) tree_suffix(x,1,0,x->finite,rank,-d);
    }
  }
  int status=ember_transport_update(x,start,deadline,count,edges,costs);
  if (status==2) contract_sync(c);
  return status;
}
int64_t ember_contract_result(Contract *c,uint32_t *route,uint32_t *length) {
  return ember_transport_result(c->x,route,length);
}
void ember_contract_stats(Contract *c,uint64_t *s) {
  ember_transport_stats(c->x,s);s[0]+=c->extra;s[1]+=c->extra;
  if (c->peak>s[1]) s[1]=c->peak;
}
