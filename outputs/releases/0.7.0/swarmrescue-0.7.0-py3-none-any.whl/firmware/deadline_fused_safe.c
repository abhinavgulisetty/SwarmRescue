/* Include target definitions so their parameter types remain exact. */
#include TARGET_SOURCE
int ember_fused_update(void *h,uint32_t start,uint32_t deadline,uint32_t count,
 const uint32_t *edges,const int64_t *costs,uint32_t *route,uint32_t *length,int64_t *value) {
  int status=TARGET_UPDATE(h,start,deadline,count,edges,costs);
  if (status>=0) *value=TARGET_RESULT(h,route,length);
  return status;
}
