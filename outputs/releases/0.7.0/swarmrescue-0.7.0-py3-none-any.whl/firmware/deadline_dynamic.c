/* D* Lite with h=0 on the explicit (vertex, remaining clock) DAG.
 * Research baseline, our implementation of Koenig & Likhachev (2002).
 * Both priority-key components are min(g,rhs), hence one scalar is sufficient.
 * This file is included after deadline_retention.c by deadline_transport.c.
 */
typedef struct {
  uint32_t n,m,capacity,deadline,start,length,queued,route_length;
  size_t states,bytes;
  const uint32_t *rows,*to,*time,*from,*rr,*re;
  const uint8_t *goals;
  int64_t *cost,*g,*rhs;
  uint32_t *heap,*position,*route;
  uint64_t expanded,patches,queries,queue_changes;
} Dynamic;
static int64_t dynamic_key(Dynamic *d,uint32_t s) {
  return d->g[s]<d->rhs[s] ? d->g[s] : d->rhs[s];
}
static void dynamic_swap(Dynamic *d,uint32_t i,uint32_t j) {
  uint32_t a=d->heap[i],b=d->heap[j];d->heap[i]=b;d->heap[j]=a;
  d->position[a]=j;d->position[b]=i;
}
static void dynamic_fix(Dynamic *d,uint32_t i) {
  while (i && dynamic_key(d,d->heap[i])<dynamic_key(d,d->heap[(i-1)/2])) {
    dynamic_swap(d,i,(i-1)/2);i=(i-1)/2;
  }
  for (;;) {
    uint32_t j=2*i+1;if (j>=d->queued) break;
    if (j+1<d->queued && dynamic_key(d,d->heap[j+1])<dynamic_key(d,d->heap[j])) j++;
    if (dynamic_key(d,d->heap[i])<=dynamic_key(d,d->heap[j])) break;
    dynamic_swap(d,i,j);i=j;
  }
}
static void dynamic_remove(Dynamic *d,uint32_t s) {
  uint32_t i=d->position[s];if (i==NONE) return;
  dynamic_swap(d,i,--d->queued);d->position[s]=NONE;
  if (i<d->queued) dynamic_fix(d,i);
}
static void dynamic_vertex(Dynamic *d,uint32_t s) {
  uint32_t t=s/d->n,u=s%d->n;
  int64_t best=d->goals[u] ? 0 : INF;
  if (!d->goals[u]) for (uint32_t e=d->rows[u];e<d->rows[u+1];e++)
    if (d->time[e]<=t) {
      int64_t value=add(d->cost[e],d->g[(size_t)(t-d->time[e])*d->n+d->to[e]]);
      if (value<best) best=value;
    }
  d->rhs[s]=best;
  if (best==d->g[s]) dynamic_remove(d,s);
  else if (d->position[s]==NONE) {
    uint32_t i=d->queued++;d->heap[i]=s;d->position[s]=i;dynamic_fix(d,i);
  } else dynamic_fix(d,d->position[s]);
  d->queue_changes++;
}
static void dynamic_predecessors(Dynamic *d,uint32_t s) {
  uint32_t t=s/d->n,v=s%d->n;
  for (uint32_t j=d->rr[v];j<d->rr[v+1];j++) {
    uint32_t e=d->re[j];
    if (d->time[e]<=d->deadline-t && !d->goals[d->from[e]])
      dynamic_vertex(d,(t+d->time[e])*d->n+d->from[e]);
  }
}
static int dynamic_solve(Dynamic *d) {
  uint32_t target=d->deadline*d->n+d->start;
  while (d->queued && (dynamic_key(d,d->heap[0])<dynamic_key(d,target) ||
                       d->rhs[target]!=d->g[target])) {
    uint32_t s=d->heap[0];dynamic_remove(d,s);
    if (s/d->n>d->deadline) continue;
    d->expanded++;
    if (d->g[s]>d->rhs[s]) { d->g[s]=d->rhs[s];dynamic_predecessors(d,s); }
    else { d->g[s]=INF;dynamic_vertex(d,s);dynamic_predecessors(d,s); }
  }
  d->route_length=0;
  if (d->g[target]==INF) return 1;
  uint32_t u=d->start,t=d->deadline;
  while (d->route_length<d->n) {
    d->route[d->route_length++]=u;if (d->goals[u]) return 1;
    uint32_t chosen=NONE;
    for (uint32_t e=d->rows[u];e<d->rows[u+1];e++)
      if (d->time[e]<=t && add(d->cost[e],d->g[(t-d->time[e])*d->n+d->to[e]])==
                              d->g[t*d->n+u]) { chosen=e;break; }
    if (chosen==NONE) return 0;
    t-=d->time[chosen];u=d->to[chosen];
  }
  return 0;
}
static void dynamic_initialize(Dynamic *d) {
  d->queued=0;
  for (size_t s=0;s<d->states;s++) { d->g[s]=d->rhs[s]=INF;d->position[s]=NONE; }
  for (uint32_t t=0;t<=d->deadline;t++)
    for (uint32_t v=0;v<d->n;v++) if (d->goals[v]) dynamic_vertex(d,t*d->n+v);
}
void ember_dynamic_destroy(Dynamic *d) {
  if (!d) return;
  free(d->cost);free(d->g);free(d->rhs);free(d->heap);free(d->position);free(d->route);free(d);
}
Dynamic *ember_dynamic_create(uint32_t n,uint32_t m,const uint32_t *rows,
 const uint32_t *to,const uint32_t *time,const uint32_t *from,
 const uint32_t *rr,const uint32_t *re,const uint8_t *goals,
 uint32_t start,uint32_t deadline,const int64_t *cost,uint32_t mode,size_t budget) {
  (void)mode;
  if (!n || start>=n || deadline>=INT32_MAX ||
      (uint64_t)n*(deadline+1)>=UINT32_MAX) return NULL;
  Dynamic *d=calloc(1,sizeof(*d));if (!d) return NULL;
  d->n=n;d->m=m;d->capacity=d->deadline=deadline;d->start=start;
  d->states=(size_t)n*(deadline+1);d->bytes=sizeof(*d)+24*d->states+8ull*m+4ull*n;
  if (d->bytes>budget) { free(d);return NULL; }
  d->rows=rows;d->to=to;d->time=time;d->from=from;d->rr=rr;d->re=re;d->goals=goals;
  d->cost=malloc(m ? 8ull*m : 1);d->g=malloc(8*d->states);d->rhs=malloc(8*d->states);
  d->heap=malloc(4*d->states);d->position=malloc(4*d->states);d->route=malloc(4ull*n);
  if (!d->cost || !d->g || !d->rhs || !d->heap || !d->position || !d->route) {
    ember_dynamic_destroy(d);return NULL;
  }
  for (uint32_t e=0;e<m;e++) if (cost[e]<=0 || cost[e]>=INT32_MAX) {
    ember_dynamic_destroy(d);return NULL;
  }
  memcpy(d->cost,cost,8ull*m);dynamic_initialize(d);
  if (!dynamic_solve(d)) { ember_dynamic_destroy(d);return NULL; }
  return d;
}
int ember_dynamic_update(Dynamic *d,uint32_t start,uint32_t deadline,uint32_t count,
 const uint32_t *edges,const int64_t *costs) {
  if (!d || start>=d->n || deadline>d->capacity) return -1;
  for (uint32_t i=0;i<count;i++)
    if (edges[i]>=d->m || costs[i]<=0 || costs[i]>=INT32_MAX) return -1;
  uint32_t previous=d->deadline;d->start=start;d->deadline=deadline;
  for (uint32_t i=0;i<count;i++) d->cost[edges[i]]=costs[i];
  if (deadline>previous) dynamic_initialize(d);
  else for (uint32_t i=0;i<count;i++) {
    uint32_t e=edges[i];
    for (uint32_t t=d->time[e];t<=deadline;t++)
      dynamic_vertex(d,t*d->n+d->from[e]);
  }
  d->patches+=count;d->queries++;
  return dynamic_solve(d) ? 3 : -1;
}
int64_t ember_dynamic_result(Dynamic *d,uint32_t *route,uint32_t *length) {
  *length=d->route_length;memcpy(route,d->route,4ull*(*length));
  return d->g[d->deadline*d->n+d->start];
}
void ember_dynamic_stats(Dynamic *d,uint64_t *s) {
  s[0]=s[1]=d->bytes;s[2]=1;s[3]=0;s[4]=d->expanded;s[5]=0;
  s[6]=d->patches;s[7]=0;s[8]=0;s[9]=d->queue_changes;
}
