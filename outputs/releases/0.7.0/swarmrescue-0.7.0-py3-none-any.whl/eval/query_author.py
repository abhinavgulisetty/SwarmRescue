"""In-process adapted-author NWRCA* baseline; full initialization on every query.

No upstream source is bundled. See build receipt for every mechanical adaptation.
The recommended hybrid queue is constructed with its known range; route output is enabled.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import numpy as np
from mcu.retention import FixedModel,INF

ROOT=Path(__file__).resolve().parents[1]
DEFAULT=ROOT/'outputs/algorithm-research/reference-query-inprocess-v6'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def build(source,output):
    if output.exists():
        raise FileExistsError('refusing to overwrite author build')
    shutil.copytree(source/'src',output/'src',
        ignore=shutil.ignore_patterns('*.o','*.d','bin','lib'))
    changes=[]
    def replace(path,old,new):
        file=output/'src'/path
        value=file.read_text()
        if value.count(old)!=1:
            raise ValueError(f'unexpected author source: {path}: {old}')
        file.write_text(value.replace(old,new))
        changes.append(dict(path=path,before=old,after=new))
    replace('sys/constants.h','typedef int32_t cost_t;','typedef int64_t cost_t;')
    replace('sys/constants.h','static const cost_t COST_MAX = INT32_MAX;',
            'static const cost_t COST_MAX = INT64_MAX;')
    replace('sys/constants.h','static const cost_t COST_MIN = INT32_MIN;',
            'static const cost_t COST_MIN = INT64_MIN;')
    replace('search/NWRCA.hpp','Q Open = Opens[0];','Q &Open = Opens[0];')
    replace('search/NWRCA.hpp','label_pool<LABEL> lbl_pool = LABEL_Pools[0];',
            'label_pool<LABEL> &lbl_pool = LABEL_Pools[0];')
    replace('search/NWRCA.hpp','    Open_search = new Q[1];','    Open_search = nullptr;')
    replace('search/NWRCA.hpp','    Open_search[0].range_update(h_f[start_vertex][0], max_delta_f[0]);',
            '    Open_search = new Q[1] {{1,h_f[start_vertex][0],max_delta_f[0]+1}};')
    replace('search/NWRCA.hpp','    delete [] upper_bound;',
            '    for(sn_id_t id=0;id<num_vertices;++id) delete [] upper_bound[id];\n    delete [] upper_bound;')
    replace('search/NWRCA.hpp',
        '{global_ub[obj_index] = std::floor(MOA<LABEL, Q, H>::exp_base.constraint*(upper_bound[start_vertex][obj_index] - h_f[start_vertex][obj_index])/100) + h_f[start_vertex][obj_index];}',
        '{global_ub[obj_index] = COST_MAX;} // Exact caller budget is assigned by adapter before search.')
    replace('search/NWRCA.hpp',
        '    if (const char *budget = std::getenv("EMBER_REFERENCE_DEADLINE")) {\n'
        '        long value = std::strtol(budget, NULL, 10);\n'
        '        if (value < 0 || value >= INT32_MAX)\n'
        '            throw std::runtime_error("invalid explicit deadline");\n'
        '        global_ub[1] = (cost_t)value;\n    }',
        '    // Explicit budget supplied by the in-process adapter, independent of environment.')
    src=output/'src'
    lib=output/'author.so'
    cmd=['g++','-std=c++11','-O3','-DNDEBUG','-DPATH','-shared','-fPIC','-pthread','-fopenmp',
         '-Wall','-Wextra','-Wno-unused-parameter',str(ROOT/'eval/query_author_bridge.cpp'),
         str(src/'util/pqueue.cpp'),'-o',str(lib)]
    cmd += ['-I'+str(src/p) for p in ('','sys','search','domains','util','heuristics')]
    result=subprocess.run(cmd,capture_output=True,text=True)
    (output/'build.log').write_text(result.stdout+result.stderr)
    result.check_returncode()
    receipt=dict(parent=json.loads((source/'ember-build.json').read_text()),changes=changes,
        adapter_sha256=digest(ROOT/'eval/query_author_bridge.cpp'),binary_sha256=digest(lib),
        command=cmd,compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
        author_sources={str(p.relative_to(src)):digest(p) for p in sorted(src.rglob('*')) if p.is_file()},
        scope='positive cost; int64 objective; recommended author hybrid queue constructed with known range; PATH; explicit integer budget; direct route extraction; no logging or file IO in timed calls')
    (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(binary=str(lib),sha256=digest(lib),changes=len(changes))),flush=True)

_libraries={}
def library(path=None):
    path=Path(path) if path is not None else DEFAULT/'author.so'
    if str(path) not in _libraries:
        lib=ctypes.CDLL(str(path))
        lib.query_author_create.argtypes=[ctypes.c_uint32]*2+[ctypes.c_void_p]*5
        lib.query_author_create.restype=ctypes.c_void_p
        lib.query_author_update.argtypes=[ctypes.c_void_p]+[ctypes.c_uint32]*3+[ctypes.c_void_p]*5
        lib.query_author_update.restype=ctypes.c_int
        lib.query_author_destroy.argtypes=[ctypes.c_void_p]
        _libraries[str(path)]=lib
    return _libraries[str(path)]

class AuthorSolver:
    def __init__(self,model,*,library_path=None,**_):
        self.handle=None
        self.model=model if isinstance(model,FixedModel) else FixedModel(model)
        self.lib=library(library_path);m=self.model
        self.output=np.empty(m.n,np.uint32)
        self.length=ctypes.c_uint32();self.value=ctypes.c_int64(INF)
        self.tail=(self.output.ctypes.data,ctypes.byref(self.length),ctypes.byref(self.value))
        self.handle=self.lib.query_author_create(m.n,m.m,m.rows.ctypes.data,m.to.ctypes.data,
            m.duration.ctypes.data,m.goals.ctypes.data,m.initial_cost.ctypes.data)
        if not self.handle:raise MemoryError('author graph construction failed')
        self.calls=0
        self.update(m.start,m.deadline,np.empty(0,np.uint32),np.empty(0,np.int64))
    def update(self,start,deadline,edges,cost):
        if not self.handle:raise RuntimeError('solver closed')
        edges,cost=np.asarray(edges),np.asarray(cost)
        if (edges.dtype!=np.uint32 or cost.dtype!=np.int64 or edges.ndim!=1 or cost.shape!=edges.shape
            or not edges.flags.c_contiguous or not cost.flags.c_contiguous
            or not 0<=start<self.model.n or not 0<=deadline<=self.model.deadline):
            raise ValueError('invalid query or contiguous uint32/int64 patches')
        status=self.lib.query_author_update(self.handle,start,deadline,len(edges),
            edges.ctypes.data,cost.ctypes.data,*self.tail)
        if status<0:raise ValueError(f'author solve failure: {status}')
        self.calls+=1
        return status
    def result(self):
        value=int(self.value.value)
        return dict(route=self.output[:self.length.value].astype(int).tolist(),
            feasible=value!=INF,optimal=True,cost_q16=value if value!=INF else None,
            lower_bound_q16=value if value!=INF else None)
    def stats(self):return dict(full_solves=self.calls)
    def close(self):
        if self.handle:self.lib.query_author_destroy(self.handle);self.handle=None
    def __del__(self):self.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--output',type=Path,default=DEFAULT)
    args=ap.parse_args();build(args.source,args.output)
