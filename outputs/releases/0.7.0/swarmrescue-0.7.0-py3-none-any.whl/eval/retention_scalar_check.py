"""Post-hoc matched check removing unused sorting from the scalar comparator."""

from __future__ import annotations

import ctypes
import hashlib
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import numpy as np

from eval.retention_audit import stream_estimate
from eval.routing_certificates import read_json, require, write_json
from mcu import retention


def main():
    folder = Path("docs/paper/retention")
    source = Path("firmware/deadline_retention.c").read_text()
    require(source.count("gap_order(h);") == 2, "unexpected construction source")
    variant = source.replace("gap_order(h);", "if (h->mode != 1) { gap_order(h); }")
    variant_path = folder / "scalar-no-sort.c"
    variant_path.write_text(variant)
    original = retention.library()
    with tempfile.TemporaryDirectory(prefix="cmr-scalar-") as temp:
        output = Path(temp) / "variant.so"
        subprocess.run(
            [
                shutil.which("cc"),
                "-std=c99",
                "-O3",
                "-Wall",
                "-Wextra",
                "-Werror",
                "-shared",
                "-fPIC",
                str(variant_path),
                "-o",
                str(output),
            ],
            check=True,
            capture_output=True,
        )
        lib = ctypes.CDLL(str(output))
    for symbol in ("create", "destroy", "update", "result", "stats", "gaps", "floor"):
        old = getattr(original, f"ember_retention_{symbol}")
        new = getattr(lib, f"ember_retention_{symbol}")
        new.argtypes, new.restype = old.argtypes, old.restype
    retention.library = lambda: lib
    methods = ("prefix_certificate", "scalar_certificate")
    warm = retention.FixedModel(
        dict(adjacent=[[[1, 1, 4]], []], start=0, goals=[1], deadline=3)
    )
    for method in methods:
        solver = retention.RetentionSolver(warm, method)
        solver.close()
    report_path = Path("outputs/retention/session0.json.gz")
    report = read_json(report_path)
    rows, pairs = [], []
    verified = 0
    for index, row in enumerate(report["rows"]):
        if row["optima_q16"][0] is None:
            continue
        fixed = retention.FixedModel(row["initial_model"])
        snapshots, cost = [], fixed.initial_cost.copy()
        for changes in row["changes"]:
            for e, value in changes:
                cost[e] = value
            snapshots.append(cost.copy())
        results = {m: [] for m in methods}
        rng = np.random.default_rng(731910 + index)

        def check(result, expected):
            for key in ("route", "feasible", "optimal", "cost_q16", "lower_bound_q16"):
                require(result[key] == expected[key], "variant changed exact output")

        for _ in range(3):
            order = list(methods)
            rng.shuffle(order)
            for method in order:
                expected = row["results"][method]["repeats"][0]
                begun = time.perf_counter_ns()
                solver = retention.RetentionSolver(fixed, method)
                setup = (time.perf_counter_ns() - begun) / 1e6
                check(solver.result(), expected["initial_result"])
                verified += 1
                samples = []
                for frame, cost in enumerate(snapshots):
                    cost_pointer = retention.pointer(cost)
                    begun = time.perf_counter_ns()
                    status = lib.ember_retention_update(solver.handle, cost_pointer)
                    elapsed = (time.perf_counter_ns() - begun) / 1e6
                    require(
                        status == expected["frames"][frame]["status"],
                        "variant changed retention decision",
                    )
                    check(solver.result(), expected["frames"][frame])
                    verified += 1
                    samples.append(elapsed)
                solver.close()
                results[method].append(
                    dict(
                        setup_ms=setup,
                        updates_ms=samples,
                        total_ms=setup + sum(samples),
                    )
                )
        medians = {
            m: float(np.median([r["total_ms"] for r in results[m]])) for m in methods
        }
        key = row["seed"], row["family"], row["stream_kind"]
        pairs.append(
            (key, [{m: medians[m] / medians["prefix_certificate"] for m in methods}])
        )
        rows.append(
            dict(seed=key[0], family=key[1], stream_kind=key[2], results=results)
        )
    estimate = stream_estimate(pairs, "scalar_certificate", comparisons=1)
    write_json(
        folder / "scalar-no-sort.json.gz",
        dict(
            posthoc=True,
            sessions=1,
            repeats=3,
            verified_output_matches=verified,
            variant_sha256=hashlib.sha256(variant.encode()).hexdigest(),
            reference_report_sha256=hashlib.sha256(
                report_path.read_bytes()
            ).hexdigest(),
            description=(
                "Only scalar-mode gap sorting is skipped. Allocation layout "
                "unchanged. Both methods use the same variant library and ABI. "
                "Each status and exact output must match the frozen report."
            ),
            estimate=estimate,
            rows=rows,
        ),
    )
    print(estimate)


if __name__ == "__main__":
    main()
