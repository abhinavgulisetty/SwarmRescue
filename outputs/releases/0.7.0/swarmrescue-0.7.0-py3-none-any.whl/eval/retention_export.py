"""Package completed local CMR evidence and produce a reviewer-facing report."""

from __future__ import annotations

import csv
import hashlib
import shutil
import subprocess
import tarfile
from pathlib import Path

from eval.retention_research import hashes
from eval.routing_certificates import read_json, require

ROOT = Path("docs/paper/retention")
LABELS = {
    "scalar_certificate": "Matched scalar guard",
    "incremental_dp": "Incremental Bellman DP",
    "full_dp": "Full Bellman DP",
    "dual_check": "Unconstrained dual check + DP",
    "native_recompute": "Existing compiled hybrid",
    "event_recompute": "Existing event solver",
}


def main():
    summary = read_json(ROOT / "summary.json")
    require(summary["audited"], "independent audit incomplete")
    protocol = read_json("eval/retention_protocol.json")
    require(protocol["source_sha256"] == hashes(), "source lock changed")
    public = read_json(ROOT / "public-geometry.json.gz")
    reference = read_json(ROOT / "published-reference.json.gz")
    optimized = read_json(ROOT / "scalar-no-sort.json.gz")
    optimized_speed = optimized["estimate"]["candidate_geomean_speedup"]
    optimized_low, optimized_high = optimized["estimate"][
        "process_and_seed_bootstrap_95ci"
    ]
    rows = []
    for scope, estimates in summary["estimates"].items():
        for method, result in estimates.items():
            low, high = result["bonferroni_simultaneous_95ci"]
            rows.append(
                dict(
                    scope=scope,
                    method=method,
                    speed_ratio=result["candidate_geomean_speedup"],
                    simultaneous_low=low,
                    simultaneous_high=high,
                    streams=result["exact_pairs"],
                    seed_blocks=result["informative_seed_blocks"],
                )
            )
    with (ROOT / "table.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    table = []
    for method, label in LABELS.items():
        result = summary["estimates"]["all_feasible"][method]
        low, high = result["bonferroni_simultaneous_95ci"]
        table.append(
            f"| {label} | {result['candidate_geomean_speedup']:.3f}x "
            f"| [{low:.3f}, {high:.3f}] |"
        )
    breakdown = []
    for kind in protocol["stream_kinds"]:
        values = summary["estimates"][kind]
        hybrid = values["native_recompute"]["candidate_geomean_speedup"]
        event = values["event_recompute"]["candidate_geomean_speedup"]
        breakdown.append(f"| {kind} | {hybrid:.3f}x | {event:.3f}x |")
    memory = summary["memory_and_retention_first_session"]
    p, s = memory["prefix_certificate"], memory["scalar_certificate"]
    frames = summary["feasible_streams"] * protocol["frames"]
    status = "passes" if summary["primary_pass"] else "does not pass"
    body = f"""# Coupled Margin Retention: proof and fresh evidence

CMR's locally frozen speed criterion **{status}**. Its coupled update guard
has a proved strictly larger sufficient stability region than the matched
scalar guard. Historical priority for the specific algorithm remains a
contribution hypothesis, with close set-tolerance work cited explicitly.

[Algorithm, proofs and literature audit](../../retention-routing-research.md),
[working manuscript](manuscript.md), [allowed claims](claims.md).

## What is new in this candidate

An exact solved deadline query is compiled into node gap bounds, an alternative
route gap floor and a sorted margin order. A linear scan proves optimality after
several costs change together, including changes to the incumbent's own cost.
The time-expanded construction tables are discarded. Rejected certificates
cause an exact rebuild; accepted certificates retain a mathematically proved
optimum, rather than an unverified cached route.

The prefix scan is equivalent to all conservative subset constraints based on
these bounds and strictly dominates a scalar guard using identical margins.
A [saved five-node example](strict-dominance-example.json) demonstrates the
strict improvement. Dijkstra, Bellman DP and sensitivity analysis are established
ingredients; the paper claim concerns the compact coupled deadline certificate.
It is not a claim to the full exact stability region or to first-ever priority.

## Fresh confirmation

Confirmation and independent audit completed 14 October 2026.

24 fresh seeds x four families x two update processes give
{summary["total_streams"]} streams on 96 maps. {summary["feasible_streams"]}
streams on 80 maps are initially feasible; the other
{summary["excluded_infeasible_streams"]} streams remain saved and checked but
are excluded from primary speed ratios. Each stream has 64 cost revisions.
All seven methods return correct exact results in every saved repeat.
The primary ratios contain 20 informative seed blocks; the other four blocks
are clock-infeasible across the declared families.

The primary endpoint includes initial construction and all C updates, with
three repeats in each of three sequential process sessions. Ratios divide
comparator time by CMR time. Intervals resample whole process sessions and
whole seed blocks, with six-comparison simultaneous correction.

| Comparator | CMR speed ratio | Simultaneous 95% interval |
| --- | ---: | --- |
{chr(10).join(table)}

![Speed evidence and strict certificate-region inclusion](speed-and-region.svg)

These are host kernel-stream timings on fixed CSR inputs. Shared encoding,
output copying, compiler warmup and independent checks are excluded equally.
ABI argument counts differ. They are not full routing API, MCU or robot mission
latencies. Exact optimal cost is preserved; no method can beat an already exact
optimum under this same objective.

## Attribution and regimes

The scalar comparator uses the same construction and alternative floor.
CMR retains {p["retentions"]:,}/{frames:,} feasible updates
({100 * p["retentions"] / frames:.2f}%), compared with
{s["retentions"]:,}/{frames:,} ({100 * s["retentions"] / frames:.2f}%) for the scalar
guard in one representative repeat. CMR builds {p["builds"]:,} certificates
including initial setup, versus {s["builds"]:,}. The new rule explains the
strict region advantage and this matched-ablation difference.
The scalar ablation keeps the same construction/order allocation; a specialized
scalar-only implementation could omit its unused sorting cost.
A separate [post-hoc matched check](scalar-no-sort.json.gz) removes that scalar
sorting cost: CMR still runs **{optimized_speed:.3f}x** faster, with a one-session
seed-block 95% interval **[{optimized_low:.3f}, {optimized_high:.3f}]**.
All {optimized["verified_output_matches"]:,} resulting outputs and retention
statuses match the independently audited original records. Allocation layout
remains unchanged. This diagnostic is separate from the frozen primary test.

| Update process | Versus existing hybrid | Versus existing event solver |
| --- | ---: | ---: |
{chr(10).join(breakdown)}

Large mixed revisions can make CMR slower than recomputation. All eight
family-by-process cells, including losses, are retained in [the CSV](table.csv).
The family/process slices are secondary; their intervals correct comparisons
within each slice and do not replace the primary all-feasible endpoint.
[Timing-prefix diagnostics](horizons.json) report setup-inclusive break-even
for 1-64 updates. These prefixes are post-hoc diagnostics, not separately
measured short streams. A moving robot changes its query: a new source,
deadline, goal, clock or topology requires a new certificate. The experiment
does not assume that 64 sensing updates occur between every robot move.

## Memory and correctness

The largest retained CMR payload is {p["retained_max_bytes"]:,} bytes, compared
with {memory["incremental_dp"]["retained_max_bytes"]:,} for incremental DP.
CMR construction peaks at {p["peak_max_bytes"]:,} bytes, versus
{memory["incremental_dp"]["peak_max_bytes"]:,} for incremental DP. The higher
construction peak is a material tradeoff. All methods share a 64 MiB host
numeric allocation ceiling. Borrowed input arrays, host-object overhead,
allocator metadata, output copies and stack are excluded.
Native recomputation reports used scratch separately from its reserved arena
capacity. These counts are not whole-process or complete-device RAM.

The audit checks **{summary["verified_outputs"]:,} output records**,
**{summary["retained_certificate_checks"]:,} feasible retained decisions** and
**{summary["bellman_equalities"]:,} Bellman equalities** on unique stream
snapshots. Saved node and alternative margins are independently recomputed.
[Exhaustive simple-path enumeration](exhaustive-checks.json) checks another
46,875 updates over three declared small graphs. ASan/UBSan stress checks
25,600 updates without a finding. These are finite checks and abstract proofs,
not formal verification of every possible C execution.

## External checks

The authors' NWRCA* binary matches **{reference["matched"]}/{reference["total"]}**
initial/middle/final snapshots. It has unrestricted memory and a different
initialization/search timer. This check confirms the same integer objective;
it does not establish a speed win over that author's implementation.
[Raw author checks](published-reference.json.gz).
[Author build metadata](author-build.json) records the reused external build.

The public MovingAI geometry adaptation has {public["total_streams"]} streams,
of which {public["feasible_streams"]} are feasible. Its ratios and every output
are in [the supplementary public study](public-geometry.json.gz). It uses
authored hazards, four-neighbor movement and endpoints rather than the original
benchmark tasks. It is post-hoc, with one session and no registered interval.

## Reproduction

Use parent checkout `4e0a1196654f86e15562a0567d82ee9288ba7ade`, overlay
[the source bundle](research-source.tar.gz), and install the project's declared
Python dependencies with a C compiler. Then run:

```bash
.venv/bin/pytest -q tests/test_retention.py
for session in 0 1 2; do
  .venv/bin/python -m eval.retention_research \\
    --seeds 142000:142023 --frames 64 --repeats 3 --session "$session" \\
    --protocol eval/retention_protocol.json \\
    --output "outputs/retention/session$session.json.gz"
done
.venv/bin/python -m eval.retention_audit \\
  outputs/retention/session0.json.gz outputs/retention/session1.json.gz \\
  outputs/retention/session2.json.gz --protocol eval/retention_protocol.json \\
  --output outputs/retention/summary.json
.venv/bin/python -m eval.retention_exhaustive
```

The recommended auditor is `eval.retention_audit`: it adapts the frozen
analyzer's stream schema to its older bootstrap helper. The adapter was added
after source locking and before fresh timing inspection, with no change to
the estimator or resampling rules. Its digest is saved in [the summary](summary.json).
The lock is local and is not publicly timestamped preregistration.

The three `fresh-session*.json.gz` files preserve every raw repeat, initial
model, integer cost revision, optimum and rebuilt margin summary.
[Validation receipt](validation-receipt.json), [host metadata](host-metadata.json),
[source lock](../../../eval/retention_protocol.json), [references](references.bib),
and `SHA256SUMS` bind the evidence. Existing frozen studies remain unchanged.
"""
    (ROOT / "README.md").write_text(body)
    manuscript_path = ROOT / "manuscript.md"
    manuscript = manuscript_path.read_text()
    marker = "## 6. Limits of the claim"
    if "### 5.1. Confirmed results" not in manuscript:
        evidence = (
            "### 5.1. Confirmed results\n\n"
            f"The audit verified {summary['verified_outputs']:,} output records, "
            f"{summary['retained_certificate_checks']:,} feasible retained decisions, "
            f"and {summary['bellman_equalities']:,} Bellman equalities. The primary "
            "criterion passes in all six comparisons over 160 feasible streams "
            "and 20 informative seed blocks.\n\n"
            "| Comparator | CMR speed ratio | Simultaneous 95% interval |\n"
            "| --- | ---: | --- |\n" + "\n".join(table) + "\n\n"
            "Background updates give a 2.163x ratio against the event solver; "
            "mixed updates give 0.787x, favoring recomputation. The recorded "
            "timing prefixes approach overall break-even at 16 updates. "
            "The supported claim is therefore regime-specific.\n\n"
            f"Removing unused scalar sorting in a post-hoc matched check yields "
            f"a {optimized_speed:.3f}x CMR advantage with a one-session seed-block "
            f"95% interval [{optimized_low:.3f}, {optimized_high:.3f}]. The "
            "authors' NWRCA* binary matches all 288 selected snapshot optima; "
            "its timing is not a matched primary comparison.\n\n"
        )
        manuscript_path.write_text(manuscript.replace(marker, evidence + marker))
    for session in range(3):
        shutil.copyfile(
            f"outputs/retention/session{session}.json.gz",
            ROOT / f"fresh-session{session}.json.gz",
        )
    extra = [
        "eval/retention_protocol.json",
        "eval/retention_audit.py",
        "eval/retention_horizons.py",
        "eval/retention_exhaustive.py",
        "eval/retention_reference.py",
        "eval/retention_public.py",
        "eval/retention_export.py",
        "eval/retention_scalar_check.py",
        "eval/event_public.py",
        "docs/paper/retention/sanitizer_harness.c",
        "docs/paper/retention/render_figure.py",
    ]
    map_folder = Path("docs/paper/event/public-maps")
    extra.extend(str(p) for p in sorted(map_folder.iterdir()) if p.is_file())
    with tarfile.open(ROOT / "research-source.tar.gz", "w:gz") as archive:
        for path in [*protocol["source_sha256"], *extra]:
            archive.add(path, arcname=path)
    subprocess.run([".venv/bin/python", str(ROOT / "render_figure.py")], check=True)
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
    (ROOT / "SHA256SUMS").write_text(
        "".join(
            f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n"
            for p in paths
        )
    )
    print(f"Packaged {len(paths)} evidence artifacts; primary criterion {status}.")


if __name__ == "__main__":
    main()
