"""Post-timing independent replay of every distinct moving query."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from eval.routing_certificates import bellman_table, verify_result, verify_table
from eval.transport_analysis import load
from eval.transport_research import hashes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs",nargs="+",type=Path)
    ap.add_argument("--output",required=True,type=Path)
    args = ap.parse_args()
    studies = [load(p) for p in args.inputs]
    design = studies[0]["design"]
    if any(s["design"] != design for s in studies) or design["sources"] != hashes():
        raise ValueError("source/protocol mismatch")
    if len({s["session"] for s in studies}) != design["sessions"]:
        raise ValueError("missing or duplicate process session")
    for s in studies:
        if len(s["rows"]) != len(studies[0]["rows"]):
            raise ValueError("incomplete study")
    optima, verified_results = {},set()
    records = equalities = retained = transports = 0
    checked_models = 0
    for row_index,row in enumerate(studies[0]["rows"]):
        for s in studies:
            other = s["rows"][row_index]
            for key in ("seed","family","kind","rate","model","initial","frames"):
                if other[key] != row[key]:
                    raise ValueError("unpaired query traces")
        model = json.loads(json.dumps(row["model"]))
        positions = [(u,j) for u,arcs in enumerate(model["adjacent"]) for j in range(len(arcs))]
        for frame_index in range(len(row["frames"])+1):
            if frame_index:
                f = row["frames"][frame_index-1]
                for edge,cost in zip(f["edges"],f["values"],strict=True):
                    u,j = positions[edge];model["adjacent"][u][j][2] = cost
                model.update(start=f["start"],deadline=f["deadline"])
                recorded = f["optimum"]
            else:
                recorded = row["initial"]["cost_q16"]
            digest = hashlib.sha256(json.dumps(model,sort_keys=True,separators=(",",":")).encode()).digest()
            if digest not in optima:
                table = bellman_table(model)
                optima[digest] = verify_table(model,table)
                equalities += (model["deadline"]+1)*len(model["adjacent"])
                checked_models += 1
            optimum = optima[digest]
            if optimum != recorded:
                raise AssertionError("independent optimum mismatch")
            for s in studies:
                for run in s["rows"][row_index]["runs"]:
                    for method in design["methods"]:
                        result = run[method]["results"][frame_index]
                        signature = (digest,tuple(result["route"]),result["cost_q16"],
                                     result["feasible"],result["optimal"],result["lower_bound_q16"])
                        if signature not in verified_results:
                            verify_result(model,result,optimum)
                            verified_results.add(signature)
                        records += 1
                        if frame_index and method=="transport_sparse" and run[method]["statuses"][frame_index-1]==1:
                            retained += 1
            if frame_index:
                previous_start = row["model"]["start"] if frame_index==1 else row["frames"][frame_index-2]["start"]
                if model["start"] != previous_start:
                    transports += 1
        print(json.dumps(dict(audited_row=row_index+1,unique_queries=checked_models)),flush=True)
    receipt = dict(output_records=records,unique_queries=checked_models,
        distinct_route_results=len(verified_results),bellman_equalities=equalities,
        accepted_candidate_records=retained,moving_query_events=transports,
        sources_match=True,protocol_sha256=hashlib.sha256(json.dumps(design,sort_keys=True).encode()).hexdigest(),
        inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in args.inputs},
        audit_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt),flush=True)


if __name__ == "__main__":
    main()
