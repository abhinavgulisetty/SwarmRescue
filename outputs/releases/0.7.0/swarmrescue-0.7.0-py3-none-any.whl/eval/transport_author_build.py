"""Isolated positive-cost adaptation of the existing pinned author checkout.

The author preprocessing can flag a negative cycle on positive moving-source
queries using a combined forward/reverse depth test. Positive input costs
exclude negative cycles mathematically, so omit that test for this control.
No original checkout or binary is modified. No upstream source is bundled.
"""
import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source",required=True,type=Path)
    ap.add_argument("--out",required=True,type=Path)
    args=ap.parse_args()
    if args.out.exists():
        raise FileExistsError("destination must be new")
    shutil.copytree(args.source/"src",args.out/"src",
                    ignore=shutil.ignore_patterns("*.o","*.d","bin","lib"))
    core=args.out/"src/search/core_algs.h"
    text=core.read_text()
    needle="if (depth[current_vertex] + depth_op[current_vertex] >=  max_depth) return true;"
    if text.count(needle)!=1:
        raise ValueError("unexpected upstream detector")
    # Keep the expression syntactically referenced to avoid unused-variable
    # diagnostics while disabling it for this strictly positive-cost build.
    replacement="if (false && depth[current_vertex] + depth_op[current_vertex] >= max_depth) return true;"
    core.write_text(text.replace(needle,replacement))
    subprocess.run(["make","-B","path"],cwd=args.out/"src",check=True,
                   stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    binary=args.out/"src/bin/roadhog"
    old=json.loads((args.source/"ember-build.json").read_text())
    receipt=dict(upstream=old["upstream"],revision=old["revision"],
        prior_binary_sha256=old["binary_sha256"],
        binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
        positive_cost_only=True,change_before=needle,change_after=replacement,
        core_sha256=hashlib.sha256(core.read_bytes()).hexdigest(),
        reason="negative cycles impossible for strictly positive arc costs; saved original failure retained")
    (args.out/"ember-build.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt),flush=True)


if __name__=="__main__":
    main()
