"""Independent all-query audit of the separate public-geometry replay."""
import eval.query_confirmation_audit as wrapper
from eval.query_public_verification import hashes

if __name__=='__main__':
    wrapper.frozen_hashes=hashes
    wrapper.main()
