"""Supplementary published-author binary checks; no matched timing claim."""
import argparse
import hashlib
import json
from pathlib import Path

from eval.retention_reference import call
from eval.transport_analysis import load
from eval.transport_research import write


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("report",type=Path)
    ap.add_argument("--binary",required=True,type=Path)
    ap.add_argument("--output",required=True,type=Path)
    ap.add_argument("--positive-cost-adaptation",action="store_true")
    args = ap.parse_args()
    report = load(args.report)
    checked,seen = [],set()
    for row in report["rows"]:
        model = json.loads(json.dumps(row["model"]))
        locations = [(u,j) for u,arcs in enumerate(model["adjacent"]) for j in range(len(arcs))]
        selected = {0,len(row["frames"])//2,len(row["frames"])}
        for i in range(len(row["frames"])+1):
            if i:
                frame = row["frames"][i-1]
                for e,cost in zip(frame["edges"],frame["values"],strict=True):
                    u,j = locations[e]
                    model["adjacent"][u][j][2] = cost
                model.update(start=frame["start"],deadline=frame["deadline"])
                optimum = frame["optimum"]
            else:
                optimum = row["initial"]["cost_q16"]
            if i not in selected:
                continue
            digest = hashlib.sha256(json.dumps(model,sort_keys=True).encode()).hexdigest()
            if digest in seen:
                continue
            seen.add(digest)
            if args.positive_cost_adaptation and any(c<=0 for row_arcs in model["adjacent"] for _,_,c in row_arcs):
                raise ValueError("positive-cost adaptation requires strictly positive costs")
            result = call(args.binary.absolute(),model)
            if result["feasible"] != (optimum is not None) or result["cost_q16"] != optimum:
                write(Path(str(args.output)+".failure.json"),dict(model=model,optimum=optimum,
                    result=result,row={k:row[k] for k in ("seed","family","kind","rate")},
                    frame=i,passed_before_failure=len(checked)))
                raise AssertionError("published solver disagrees")
            checked.append(dict(seed=row["seed"],family=row["family"],kind=row["kind"],
                rate=row["rate"],frame=i,model_sha256=digest,optimum=optimum,result=result))
        print(f"Author check {row['seed']}/{row['family']}/{row['kind']}/{row['rate']}",flush=True)
    write(args.output,dict(matched=len(checked),total=len(checked),checks=checked,
        report_sha256=hashlib.sha256(args.report.read_bytes()).hexdigest(),
        binary_sha256=hashlib.sha256(args.binary.read_bytes()).hexdigest(),
        positive_cost_adaptation=args.positive_cost_adaptation,
        scope="initial/middle/final unique snapshots; author core timers not comparable to full-call primary timing"))


if __name__ == "__main__":
    main()
