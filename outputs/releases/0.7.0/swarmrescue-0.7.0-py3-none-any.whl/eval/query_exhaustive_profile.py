"""Check non-vacuity and deliberate guard omissions on the frozen finite domain."""
import hashlib
import inspect
from itertools import combinations_with_replacement,product
import json
from pathlib import Path
import eval.query_exhaustive as original

def main():
    source=inspect.getsource(original.mathematical_domain)
    old="                            counts['transport_guards']+=1"
    extra="""                            counts['transport_guards']+=1
                            exact_here=min(p[1]+sum(delta[e] for e in p[3]) for p in competitors)
                            unsafe_here=exact_here!=old_cost+shift
                            counts['unsafe_incumbents']+=unsafe_here
                            counts['non_goal_moving_guards']+=cursor>0 and x not in goals
                            counts['goal_queries']+=x in goals
                            counts['unsafe_if_shift_omitted']+=unsafe_here and prefix(gaps,red,0,floor)
                            counts['unsafe_if_decreases_omitted']+=unsafe_here and prefix(gaps,[0]*3,shift,floor)
                            if unsafe_here and not witnesses:
                                witnesses.append(dict(adjacent=adjacent,goals=sorted(goals),anchor_deadline=deadline,
                                    anchor_route=list(route),new_start=x,new_budget=budget,
                                    changes=[[u,i,change] for (u,i),change in delta.items()],
                                    incumbent_cost=old_cost+shift,exact_cost=exact_here))"""
    assert source.count(old)==1;source=source.replace(old,extra)
    old_current='                                current=min(p[1]+sum(delta[e] for e in p[3]) for p in competitors)'
    assert source.count(old_current)==1;source=source.replace(old_current,'                                current=exact_here')
    old_accept="                                counts['accepted_transport_guards']+=1"
    source=source.replace(old_accept,old_accept+"\n                                counts['accepted_with_distinct_competitors']+=len(competitors)>1 and x not in goals")
    namespace=dict(vars(original));witnesses=[];namespace['witnesses']=witnesses
    exec(compile(source,'<instrumented frozen finite-domain function>','exec'),namespace)
    counts=namespace['mathematical_domain']()
    root=Path(__file__).resolve().parents[1]
    frozen=json.loads((root/'outputs/query-verification/exhaustive-tradeoff.json').read_text())
    for key,value in frozen['mathematics'].items():assert counts[key]==value
    assert counts['unsafe_incumbents']>0 and counts['unsafe_if_shift_omitted']>0
    assert counts['unsafe_if_decreases_omitted']>0 and counts['accepted_with_distinct_competitors']>0
    tied=0
    for n in range(5):
        for gaps in combinations_with_replacement(range(4),n):
            for reductions,floor,shift in product(product(range(3),repeat=n),range(4),range(-3,4)):
                brute=all(shift+sum(reductions[i] for i in range(n) if mask>>i&1)
                    <=max([floor]+[gaps[i] for i in range(n) if mask>>i&1]) for mask in range(1<<n))
                assert original.prefix(gaps,reductions,shift,floor)==brute
                tied+=1
    report=dict(counts=counts,tied_gap_subset_cases=tied,unsafe_witness=witnesses[0],
        frozen_function_sha256=hashlib.sha256(inspect.getsource(original.mathematical_domain).encode()).hexdigest(),
        instrumented_function_sha256=hashlib.sha256(source.encode()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Same frozen mathematical domain; extra exact-optimum calculations and deliberately weakened guard diagnostics; no speed inference')
    path=root/'outputs/query-verification/exhaustive-profile.json'
    path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

if __name__=='__main__':main()
