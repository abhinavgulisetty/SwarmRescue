"""Final confirmation: transported certificates with matched fused interfaces.

The default (no extra clock cuts) was selected on already opened pilot data.
Goal-clock and landmark cuts remain explicit ablations; no test-time selection.
"""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.landmark_research import frozen_hashes as previous_hashes,solver
from eval.transport_research import analyze as stream_analysis

METHODS=("transport_sparse","contracted_certificate","landmark_certificate",
         "sparse_incremental_dp","expanded_dstar_lite","sparse_event","sparse_hybrid")


def frozen_hashes():
    root=Path(__file__).resolve().parents[1]
    files=("eval/query_research.py",)
    return dict(previous_hashes(),**{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files})


def main():
    experiment.METHODS=METHODS;experiment.TransportSolver=solver
    experiment.hashes=frozen_hashes;experiment.analyze=stream_analysis;experiment.main()


if __name__=="__main__":
    main()
