"""Independent witnesses delimiting transport versus whole-anchor checking."""
import json
from pathlib import Path
import numpy as np
from eval.query_safe_research import solver
from eval.retention_certificates import certificate_summary,prefix_rule,route_cost
from eval.retention_exhaustive import enumerated_optimum
from mcu.retention import FixedModel

def check(model,source,budget,edges,values,expect_static,expect_transport):
    fixed=FixedModel(model);s=solver(fixed);anchor=s.result()['route']
    gaps,floor=certificate_summary(model,anchor)
    cost=fixed.initial_cost.copy();cost[edges]=values
    current=fixed.updated_model(cost)
    reductions=[0]*fixed.n
    for e in range(fixed.m):
        v=int(fixed.to[e]);reductions[v]=max(reductions[v],int(fixed.initial_cost[e]-cost[e]))
    shift=route_cost(current,anchor)-route_cost(model,anchor)
    static=prefix_rule(gaps,reductions,shift,floor)
    assert static==expect_static
    status=s.update(source,budget,np.array(edges,np.uint32),np.array(values,np.int64))
    suffix_model=dict(current,start=source,deadline=budget)
    result=s.result();exact=enumerated_optimum(suffix_model)
    assert result['cost_q16']==exact
    assert (status==1)==expect_transport
    out=dict(anchor=model,current_costs=cost.tolist(),current_source=source,current_deadline=budget,
        anchor_route=anchor,current_anchor_route_cost=route_cost(current,anchor),
        current_anchor_query_optimum=enumerated_optimum(current),whole_anchor_guard_accepts=static,
        transport_accepts=status==1,transport_builds=s.stats()['builds'],
        suffix_result=result,suffix_exact_cost=exact)
    s.close();return out

def main():
    first=check(dict(adjacent=[[[1,2,5],[3,3,40]],[[2,2,6]],[[3,2,7]],[]],
        start=0,goals=[3],deadline=8),1,6,[0],[50],False,True)
    assert first['current_anchor_route_cost']==63 and first['current_anchor_query_optimum']==40
    assert first['transport_builds']==1 and first['suffix_exact_cost']==13
    second=check(dict(adjacent=[[[1,1,50],[2,2,57]],[[2,1,5]],[]],
        start=0,goals=[2],deadline=2),1,1,[0,2],[1,6],True,False)
    assert second['suffix_exact_cost']==6
    result=dict(past_increase_witness=first,past_decrease_counterexample=second,
        conclusion='Transport can certify after full-anchor optimality is lost; acceptance sets do not dominate each other for arbitrary past-prefix repricing. Historical novelty is unresolved.')
    path=Path('outputs/query-verification/transport-witness.json')
    path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':main()
