"""Count native operations in an instrumented COPY; never alter frozen kernels.

This is a mechanism check on a declared always-accepted graph family, not
an empirical proof of a worst-case theorem or a primary latency benchmark.
"""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import numpy as np
import mcu.transport as native
from mcu.retention import FixedModel

ROOT=Path(__file__).resolve().parents[1]

def model(n,deadline):
    # Unique direct optimum 1; every detour initially costs 200. Two sparse
    # unit decreases cannot invalidate it. Incoming degree at the goal is n-1.
    return FixedModel(dict(adjacent=[[[n-1,1,1]]+[[v,1,100] for v in range(1,n-1)]]+
        [[[n-1,1,100]] for _ in range(1,n-1)]+[[]],start=0,goals=[n-1],deadline=deadline))

def main():
    source=ROOT/'firmware/deadline_transport.c';before=source.read_bytes()
    value=before.decode()
    changes=[('static int64_t decrease(Transport *x,uint32_t e) {',
              'static int64_t decrease(Transport *x,uint32_t e) { verification_decreases++;'),
             ('uint32_t begin,int64_t delta) {',
              'uint32_t begin,int64_t delta) { verification_tree_visits++;')]
    for old,new in changes:
        assert value.count(old)==1;value=value.replace(old,new)
    value='#include <stdint.h>\nuint64_t verification_decreases,verification_tree_visits;\n'+value
    value+='\nvoid verification_reset(void){verification_decreases=verification_tree_visits=0;}\n'
    value+='void verification_read(uint64_t *out){out[0]=verification_decreases;out[1]=verification_tree_visits;}\n'
    baseline=native.library();records=[]
    with tempfile.TemporaryDirectory(prefix='query-count-') as folder:
        copy=Path(folder)/'transport.c';copy.write_text(value)
        out=Path(folder)/'transport.so'
        command=['cc','-std=c99','-O3','-shared','-fPIC','-Wall','-Wextra','-Werror',
                 '-I'+str(ROOT/'firmware'),str(copy),'-o',str(out)]
        subprocess.run(command,check=True,capture_output=True)
        lib=ctypes.CDLL(str(out))
        for name in ('ember_transport_create','ember_transport_update','ember_transport_destroy',
                     'ember_transport_result','ember_transport_stats'):
            function=getattr(lib,name);old=getattr(baseline,name)
            function.argtypes=old.argtypes;function.restype=old.restype
        lib.verification_read.argtypes=[ctypes.c_void_p]
        original=native.library;native.library=lambda:lib
        try:
            for exponent in range(4,17):
                n=1<<exponent;fixed=model(n,2);solver=native.TransportSolver(fixed)
                # Last incoming goal arc starts at a deep heap leaf; the
                # other patch exercises a nontrivial tree suffix boundary.
                edges=np.array([1,2*n-4],np.uint32)
                maxima=np.zeros(2,np.uint64)
                for iteration in range(16):
                    values=np.full(2,99 if iteration%2==0 else 100,np.int64)
                    lib.verification_reset();assert solver.update(0,2,edges,values)==1
                    counts=np.zeros(2,np.uint64);lib.verification_read(counts.ctypes.data)
                    maxima=np.maximum(maxima,counts)
                    assert solver.result()['cost_q16']==1
                assert solver.stats()['builds']==1
                records.append(dict(nodes=n,arcs=fixed.m,patches=2,
                    maximum_decrease_calls=int(maxima[0]),maximum_tree_visits=int(maxima[1]),
                    conservative_tree_visit_bound=2*(4*exponent+1),
                    retained_bytes=solver.stats()['retained_numeric_bytes']))
                assert maxima[1]<=2*(4*exponent+1)
                solver.close()
            memory=[]
            for deadline in (2,16,256,4096):
                solver=native.TransportSolver(model(512,deadline))
                memory.append(dict(deadline=deadline,**solver.stats()));solver.close()
            assert len({r['retained_numeric_bytes'] for r in memory})==1
            admission=[]
            for deadline in (2048,4096):
                try:
                    solver=native.TransportSolver(model(1024,deadline))
                except MemoryError:
                    admission.append(dict(nodes=1024,deadline=deadline,budget_bytes=64*1024*1024,
                        admitted=False,reason='Worst-case construction admission cap, despite a direct feasible optimum'))
                else:
                    admission.append(dict(nodes=1024,deadline=deadline,budget_bytes=64*1024*1024,
                        admitted=True,retained_bytes=solver.stats()['retained_numeric_bytes']))
                    solver.close()
        finally:native.library=original
    assert source.read_bytes()==before
    report=dict(source_sha256=hashlib.sha256(before).hexdigest(),instrumentation_sha256=hashlib.sha256(value.encode()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),records=records,
        deadline_memory=memory,memory_admission=admission,accepted_updates=13*16,
        scope='Declared direct-route graph family only; operation counts and retained numeric memory, excluding output and construction scratch; no latency inference')
    path=ROOT/'outputs/query-verification/operation-counts.json';path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

if __name__=='__main__':main()
