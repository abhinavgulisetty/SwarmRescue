"""Reuse frozen paired analysis with an explicit contracted candidate name."""
import argparse
import json
from pathlib import Path
from eval.transport_analysis import analyze,load


def adapted(studies):
    rename=lambda name: "transport_sparse" if name=="contracted_certificate" else (
        "unfiltered_transport" if name=="transport_sparse" else name)
    out=[]
    for study in studies:
        rows=[dict(row,runs=[{rename(k):v for k,v in run.items()} for run in row["runs"]])
              for row in study["rows"]]
        out.append(dict(study,design=dict(study["design"],
            methods=[rename(m) for m in study["design"]["methods"]]),rows=rows))
    return out


def one(rows,methods):
    return analyze(adapted([dict(design=dict(methods=methods),rows=rows)]))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("inputs",nargs="+",type=Path)
    ap.add_argument("--output",required=True,type=Path)
    args=ap.parse_args();studies=[load(p) for p in args.inputs];data=adapted(studies)
    summary=dict(candidate="contracted_certificate",primary=analyze(data),by_kind={},by_rate={})
    for kind in studies[0]["design"]["kinds"]:
        summary["by_kind"][kind]=analyze(data,lambda r:r["kind"]==kind)
    for rate in studies[0]["design"]["rates"]:
        summary["by_rate"][str(rate)]=analyze(data,lambda r:r["rate"]==rate)
    summary["output_records_checked"]=sum(len(run[m]["results"]) for s in studies
        for r in s["rows"] for run in r["runs"] for m in s["design"]["methods"])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary["primary"]),flush=True)


if __name__=="__main__":
    main()
