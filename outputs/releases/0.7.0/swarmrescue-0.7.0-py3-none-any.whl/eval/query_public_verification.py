"""Separate public-geometry replay; endpoints/hazards remain authored adaptations."""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.event_public import public_case
from eval.query_confirmation import METHODS,solver,frozen_hashes as primary_hashes

MAPS=Path(__file__).resolve().parents[1]/'outputs/event/public-maps'

def hashes():
    root=Path(__file__).resolve().parents[1]
    paths=('eval/query_public_verification.py','eval/event_public.py','eval/event_research.py')
    own={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
    maps={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(MAPS.glob('*.map'))}
    return dict(primary_hashes(),**own,**maps)

def main():
    experiment.METHODS=METHODS;experiment.TransportSolver=solver;experiment.hashes=hashes
    experiment.make_case=lambda seed,family:public_case(MAPS/family,seed)
    experiment.main()

if __name__=='__main__':main()
