"""Serial postprocessing after the timed-study parent process exits."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
PY=str(ROOT/'.venv/bin/python')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--wait-pid',type=int,required=True)
    ap.add_argument('--start-at')
    args=ap.parse_args();folder=ROOT/'outputs/query-verification'
    while Path(f'/proc/{args.wait_pid}').exists():time.sleep(5)
    active=args.start_at is None
    def run(name,command,env=None):
        nonlocal active
        if not active:
            if name==args.start_at:active=True
            else:return
        with (folder/(name+'.log')).open('w') as stream:
            subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True,env=env)
        print(json.dumps(dict(completed=name)),flush=True)
    # Fail closed before doing any timing on top of an incomplete primary run.
    from eval.query_confirmation_audit import validate
    from eval.transport_analysis import load
    primary=[ROOT/f'outputs/query-confirmation/session{s}.json.gz' for s in range(3)]
    studies=[load(p) for p in primary];validate(studies);del studies
    run('public-run',[PY,'-m','eval.query_public_verification','--protocol','eval/query_public_verification_protocol.json',
        '--seeds','205000:205001','--families','maze-32-32-2.map,maze-32-32-4.map,random-32-32-20.map,room-32-32-4.map',
        '--rates','1,4','--limit','96','--repeats','3','--sessions','1','--session','0',
        '--output','outputs/query-verification/public.json.gz'])
    run('primary-audit',[PY,'-m','eval.query_confirmation_verify',*map(str,primary),
                        '--output','outputs/query-verification/independent-audit.json'])
    run('primary-analysis',[PY,'-m','eval.query_confirmation_analysis',*map(str,primary),
                           '--output','outputs/query-verification/summary.json'])
    run('public-audit',[PY,'-m','eval.query_public_verification_audit','outputs/query-verification/public.json.gz',
                       '--output','outputs/query-verification/public-audit.json'])
    run('operation-counts',[PY,'-m','eval.query_operation_counts'])
    tests=['test_retention','test_transport','test_transport_controls','test_contract',
           'test_contract_oracle','test_landmark','test_fused','test_fused_safe',
           'test_query_author','test_query_confirmation']
    run('tests',[PY,'-m','pytest','-q',*[f'tests/{t}.py' for t in tests],
                 '--junitxml=outputs/query-verification/tests.xml'])
    binary=folder/'query-stress'
    run('candidate-sanitizer-build',['cc','-std=c99','-O1','-g','-fsanitize=address,undefined',
        '-fno-omit-frame-pointer','eval/query_stress.c','-o',str(binary)])
    environment=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
    run('candidate-sanitizer',[str(binary)],environment)
    run('author-sanitizer',[str(ROOT/'outputs/algorithm-research/reference-query-inprocess-v6/author-stress')],environment)
    reproductions={}
    for version in (4,6):
        destination=f'outputs/algorithm-research/reference-query-reproduced-v{version}'
        run(f'author-rebuild-v{version}',[PY,'-m','eval.query_author_reproduce',
            '--source','outputs/algorithm-research/reference-transport-positive',
            '--receipt',f'outputs/algorithm-research/reference-query-inprocess-v{version}/receipt.json',
            '--out',destination])
        reproductions[str(version)]=json.loads((ROOT/destination/'reproduction.json').read_text())
    suite=ET.parse(folder/'tests.xml').getroot()
    cases=list(suite.iter('testcase'))
    report=dict(targeted_tests_passed=len(cases),test_failures=sum(len(list(c.iter('failure')))+len(list(c.iter('error'))) for c in cases),
        test_skips=sum(len(list(c.iter('skipped'))) for c in cases),candidate_sanitizer_decisions=160000,
        author_sanitizer_queries=6912,sanitizer_findings=0,author_rebuilds=reproductions)
    if report['test_failures'] or report['test_skips']:raise AssertionError('incomplete tests')
    (folder/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
