"""Replay fixed-query streams, check certificates, and cluster speed estimates."""

from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

from eval.paper_confirmation import estimate
from eval.retention_certificates import (
    certificate_summary,
    deficits,
    prefix_rule,
    route_cost,
    scalar_rule,
)
from eval.routing_certificates import (
    bellman_table,
    read_json,
    require,
    verify_result,
    verify_table,
    write_json,
)

CANDIDATE = "prefix_certificate"


def analyze(paths, protocol_path, *, audit=True):
    protocol = read_json(protocol_path)
    digest = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    expected = set(
        itertools.product(
            protocol["seeds"], protocol["families"], protocol["stream_kinds"]
        )
    )
    groups, summaries = {}, {}
    models_cache, margins_cache = {}, {}
    verified_outputs = certificate_checks = equalities = 0
    for path in paths:
        report = read_json(path)
        require(report["protocol_sha256"] == digest, "protocol digest")
        require(report["source_sha256"] == protocol["source_sha256"], "source lock")
        session = report["session"]
        require(session not in groups, "duplicate session")
        index = {}
        for row in report["rows"]:
            key = row["seed"], row["family"], row["stream_kind"]
            require(key not in index, "duplicate stream")
            require(set(row["results"]) == set(protocol["methods"]), "methods")
            require(len(row["changes"]) == protocol["frames"], "stream length")
            require(len(row["orders"]) == protocol["repeats"], "order length")
            require(
                all(sorted(o) == sorted(protocol["methods"]) for o in row["orders"]),
                "random order permutations",
            )
            stream_hash = hashlib.sha256(
                json.dumps(
                    [row["initial_model"], row["changes"], row["optima_q16"]],
                    sort_keys=True,
                ).encode()
            ).hexdigest()
            if key in models_cache:
                old_hash, models, optima = models_cache[key]
                require(old_hash == stream_hash, "different stream across sessions")
            else:
                models = [row["initial_model"]]
                locations = [
                    (u, i)
                    for u, adjacent in enumerate(models[0]["adjacent"])
                    for i in range(len(adjacent))
                ]
                for changes in row["changes"]:
                    current = copy.deepcopy(models[-1])
                    require(
                        len({e for e, _ in changes}) == len(changes), "duplicate arc"
                    )
                    for e, cost in changes:
                        require(0 <= e < len(locations), "changed arc index")
                        u, i = locations[e]
                        current["adjacent"][u][i][2] = cost
                    models.append(current)
                optima = []
                for model in models:
                    if audit:
                        optimum = verify_table(model, bellman_table(model))
                        equalities += (model["deadline"] + 1) * len(model["adjacent"])
                    else:
                        optimum = row["optima_q16"][len(optima)]
                    optima.append(optimum)
                require(optima == row["optima_q16"], "stored oracle optima")
                models_cache[key] = stream_hash, models, optima
            for method, entry in row["results"].items():
                require(len(entry["repeats"]) == protocol["repeats"], "repeat count")
                require(
                    entry["median_total_ms"]
                    == float(np.median([r["total_ms"] for r in entry["repeats"]])),
                    "median total",
                )
                for repeat in entry["repeats"]:
                    require(
                        repeat["total_ms"]
                        == repeat["setup_ms"]
                        + sum(f["elapsed_ms"] for f in repeat["frames"]),
                        "total accounting",
                    )
                    require(repeat["setup_ms"] > 0, "setup time")
                    stats = repeat["stats"]
                    require(
                        0
                        <= stats["retained_numeric_bytes"]
                        <= stats["peak_numeric_bytes"]
                        <= protocol["memory_limit"],
                        "memory accounting",
                    )
                    records = [repeat["initial_result"], *repeat["frames"]]
                    require(len(records) == len(models), "output count")
                    anchor = 0
                    cert = repeat["initial_certificate"]
                    for frame, (model, record, optimum) in enumerate(
                        zip(models, records, optima, strict=True)
                    ):
                        verify_result(model, record, optimum)
                        require(record["optimal"], "nonoptimal output")
                        verified_outputs += 1
                        if frame:
                            require(record["frame"] == frame - 1, "frame index")
                            require(record["elapsed_ms"] > 0, "update time")
                        if not method.endswith("certificate"):
                            continue
                        if frame and record["status"] == 2:
                            anchor, cert = frame, record["certificate"]
                        require(cert is not None, "missing certificate")
                        if not record["feasible"]:
                            require(optima[anchor] is None, "infeasible anchor")
                            continue
                        margin_key = key, anchor, tuple(record["route"]), cert["fast"]
                        if margin_key not in margins_cache and audit:
                            margins_cache[margin_key] = certificate_summary(
                                models[anchor], record["route"], cert["fast"]
                            )
                        if audit:
                            require(
                                margins_cache[margin_key]
                                == (cert["gaps"], cert["alternative_floor"]),
                                "margin witness",
                            )
                        if frame and record["status"] == 1:
                            require(
                                record["route"] == records[anchor]["route"],
                                "retained route changed",
                            )
                            shift = route_cost(model, record["route"]) - route_cost(
                                models[anchor], record["route"]
                            )
                            rule = prefix_rule if method == CANDIDATE else scalar_rule
                            require(
                                rule(
                                    cert["gaps"],
                                    deficits(models[anchor], model),
                                    shift,
                                    cert["alternative_floor"],
                                ),
                                "unsafe retained certificate",
                            )
                            certificate_checks += 1
            index[key] = row
        require(set(index) == expected, "stream coverage")
        groups[session] = index
    require(set(groups) == set(range(protocol["sessions"])), "session coverage")
    scopes = {
        "all_feasible": [
            k for k in sorted(expected) if groups[0][k]["optima_q16"][0] is not None
        ]
    }
    for kind in protocol["stream_kinds"]:
        scopes[kind] = [k for k in scopes["all_feasible"] if k[2] == kind]
    for family in protocol["families"]:
        for kind in protocol["stream_kinds"]:
            scopes[f"{family}/{kind}"] = [k for k in scopes[kind] if k[1] == family]
    for scope, keys in scopes.items():
        summaries[scope] = {}
        pairs = [
            (
                k,
                [
                    {
                        m: groups[s][k]["results"][m]["median_total_ms"]
                        / groups[s][k]["results"][CANDIDATE]["median_total_ms"]
                        for m in protocol["methods"]
                    }
                    for s in range(protocol["sessions"])
                ],
            )
            for k in keys
        ]
        for method in protocol["methods"]:
            if method == CANDIDATE or not pairs:
                continue
            summaries[scope][method] = estimate(
                pairs, method, comparisons=len(protocol["primary_comparisons"])
            )
    memory = {}
    for method in protocol["methods"]:
        rows = [
            groups[0][k]["results"][method]["repeats"][0]
            for k in scopes["all_feasible"]
        ]
        memory[method] = dict(
            retained_max_bytes=max(
                (r["stats"]["retained_numeric_bytes"] for r in rows), default=0
            ),
            peak_max_bytes=max(
                (r["stats"]["peak_numeric_bytes"] for r in rows), default=0
            ),
            retentions=sum(r["stats"]["retentions"] for r in rows),
            builds=sum(r["stats"]["builds"] for r in rows),
            setup_total_ms=sum(r["setup_ms"] for r in rows),
            update_total_ms=sum(r["total_ms"] - r["setup_ms"] for r in rows),
        )
    comparisons = summaries["all_feasible"]
    return dict(
        protocol_sha256=digest,
        audited=audit,
        verified_outputs=verified_outputs,
        retained_certificate_checks=certificate_checks,
        bellman_equalities=equalities,
        total_streams=len(expected),
        feasible_streams=len(scopes["all_feasible"]),
        excluded_infeasible_streams=len(expected) - len(scopes["all_feasible"]),
        frame_updates_per_session=len(expected) * protocol["frames"],
        estimates=summaries,
        memory_and_retention_first_session=memory,
        primary_pass=all(
            comparisons[m]["bonferroni_simultaneous_95ci"][0] > 1
            for m in protocol["primary_comparisons"]
        ),
        limitations=[
            "One host; synthetic cost streams; fixed query/topology/clock.",
            "Timers include setup and C updates; shared encoding and copying excluded.",
            "Local source lock is not publicly timestamped preregistration.",
            "No claim of universal speed dominance or established historical priority.",
        ],
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="+", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.reports, args.protocol)
    write_json(args.output, result)
    print(
        json.dumps(
            {
                "verified_outputs": result["verified_outputs"],
                "primary_pass": result["primary_pass"],
                "all_feasible": result["estimates"]["all_feasible"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
