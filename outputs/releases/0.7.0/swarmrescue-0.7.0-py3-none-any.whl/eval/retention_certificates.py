"""Independent arbitrary-precision verification of node-gap retention certificates."""

from __future__ import annotations

import heapq
from itertools import pairwise

from eval.routing_certificates import (
    bellman_table,
    require,
    validate_model,
    verify_table,
)


def node_gaps(model):
    validate_model(model)
    n, deadline = len(model["adjacent"]), model["deadline"]
    backward = bellman_table(model)
    optimum = verify_table(model, backward)
    forward = [[None] * n for _ in range(deadline + 1)]
    forward[0][model["start"]] = 0
    goals = set(model["goals"])
    for elapsed, row in enumerate(forward):
        for u, value in enumerate(row):
            if value is None or u in goals:
                continue
            for v, duration, cost in model["adjacent"][u]:
                if elapsed + duration <= deadline:
                    proposal = value + cost
                    old = forward[elapsed + duration][v]
                    if old is None or proposal < old:
                        forward[elapsed + duration][v] = proposal
    gaps = []
    for v in range(n):
        alternatives = [
            forward[t][v] + backward[deadline - t][v]
            for t in range(deadline + 1)
            if forward[t][v] is not None and backward[deadline - t][v] is not None
        ]
        gap = (
            min(alternatives) - optimum
            if alternatives and optimum is not None
            else None
        )
        require(gap is None or gap >= 0, "negative node gap")
        gaps.append(gap)
    return optimum, gaps


def deficits(anchor, current):
    require(
        anchor["start"] == current["start"]
        and anchor["goals"] == current["goals"]
        and anchor["deadline"] == current["deadline"],
        "query changed",
    )
    require(len(anchor["adjacent"]) == len(current["adjacent"]), "node count changed")
    result = [0] * len(anchor["adjacent"])
    for old_row, new_row in zip(anchor["adjacent"], current["adjacent"], strict=True):
        require(len(old_row) == len(new_row), "topology changed")
        for old, new in zip(old_row, new_row, strict=True):
            require(old[:2] == new[:2], "topology/clock changed")
            v, _, cost = new
            require(cost > 0, "nonpositive cost")
            result[v] = max(result[v], old[2] - cost)
    return result


def prefix_rule(gaps, reductions, shift=0, floor=0):
    floor = float("inf") if floor is None else floor
    if shift > floor:
        return False
    order = sorted(
        (g if g is not None else float("inf"), d)
        for g, d in zip(gaps, reductions, strict=True)
        if d > 0
    )
    total = 0
    for gap, reduction in order:
        total += reduction
        if total + shift > max(gap, floor):
            return False
    return True


def scalar_rule(gaps, reductions, shift=0, floor=0):
    floor = float("inf") if floor is None else floor
    if shift > floor:
        return False
    active = [
        (g, d) for g, d in zip(gaps, reductions, strict=True) if d > 0 and g is not None
    ]
    return sum(d for _, d in active) + shift <= max(
        floor, min((g for g, _ in active), default=float("inf"))
    )


def route_cost(model, route):
    cost = 0
    for u, v in pairwise(route):
        arcs = [arc for arc in model["adjacent"][u] if arc[0] == v]
        require(len(arcs) == 1, "ambiguous or missing route edge")
        cost += arcs[0][2]
    return cost


def certificate_summary(model, route, fast=False):
    """Recompute the two possible certificate constructions with Python integers."""
    n, deadline = len(model["adjacent"]), model["deadline"]
    goals = set(model["goals"])
    selected = set(pairwise(route))
    optimum = route_cost(model, route)
    if fast:
        reverse = [[] for _ in range(n)]
        for u, row in enumerate(model["adjacent"]):
            for v, _, cost in row:
                reverse[v].append((u, cost))

        def distances(reverse_search):
            distance = [None] * n
            queue = []
            for v in goals if reverse_search else [model["start"]]:
                distance[v] = 0
                heapq.heappush(queue, (0, v))
            while queue:
                value, u = heapq.heappop(queue)
                if value != distance[u]:
                    continue
                if not reverse_search and u in goals:
                    continue
                arcs = (
                    reverse[u]
                    if reverse_search
                    else [(v, c) for v, _, c in model["adjacent"][u]]
                )
                for v, cost in arcs:
                    proposal = value + cost
                    if distance[v] is None or proposal < distance[v]:
                        distance[v] = proposal
                        heapq.heappush(queue, (proposal, v))
            return distance

        a, b = distances(False), distances(True)
        require(b[model["start"]] == optimum, "fast certificate is not supported")
        gaps = [
            a[v] + b[v] - optimum if a[v] is not None and b[v] is not None else None
            for v in range(n)
        ]
        candidates = [
            a[u] + cost + b[v] - optimum
            for u, row in enumerate(model["adjacent"])
            for v, _, cost in row
            if u not in goals
            and (u, v) not in selected
            and a[u] is not None
            and b[v] is not None
        ]
    else:
        _, gaps = node_gaps(model)
        b = bellman_table(model)
        a = [[None] * n for _ in range(deadline + 1)]
        a[0][model["start"]] = 0
        candidates = []
        for t in range(deadline + 1):
            for u, row in enumerate(model["adjacent"]):
                if a[t][u] is None or u in goals:
                    continue
                for v, duration, cost in row:
                    if duration > deadline - t:
                        continue
                    value = a[t][u] + cost
                    old = a[t + duration][v]
                    if old is None or value < old:
                        a[t + duration][v] = value
                    tail = b[deadline - t - duration][v]
                    if (u, v) not in selected and tail is not None:
                        candidates.append(value + tail - optimum)
    return gaps, min(candidates, default=None)


def verify_retention(anchor, current, route, gaps, floor=0, fast=False):
    optimum = route_cost(anchor, route)
    independent_gaps, independent_floor = certificate_summary(anchor, route, fast)
    require(gaps == independent_gaps, "gap summary mismatch")
    require(floor == independent_floor, "alternative floor mismatch")
    shift = route_cost(current, route) - optimum
    require(
        prefix_rule(gaps, deficits(anchor, current), shift, floor),
        "coupled prefix rule fails",
    )
    return optimum + shift
