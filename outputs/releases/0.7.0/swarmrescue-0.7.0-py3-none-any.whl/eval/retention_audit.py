"""Adapt stream ratios to the frozen historical bootstrap helper's report schema.

This schema correction was added after locking sources, before inspecting fresh
timings. It changes neither the estimand nor the resampling/statistical rules.
The frozen analyzer and raw reports are retained unchanged.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from eval import retention_analysis
from eval.paper_confirmation import estimate as historical_estimate
from eval.routing_certificates import write_json


def stream_estimate(pairs, method, *, comparisons=6):
    # The helper expects baseline/candidate latencies under results/median_ms.
    # A stored comparator/candidate ratio and candidate latency 1 have exactly
    # the same log ratio, including process and seed clustering.
    adapted = [
        (
            key,
            [
                dict(
                    results={
                        **{m: dict(median_ms=value) for m, value in ratios.items()},
                        "native_exact": dict(median_ms=1.0),
                    }
                )
                for ratios in sessions
            ],
        )
        for key, sessions in pairs
    ]
    return historical_estimate(adapted, method, comparisons=comparisons)


def analyze(paths, protocol_path):
    retention_analysis.estimate = stream_estimate
    result = retention_analysis.analyze(paths, protocol_path)
    result["analysis_schema_correction"] = {
        "description": (
            "Schema adapter added after source locking, before fresh timing "
            "inspection; frozen statistical estimand and bootstrap unchanged."
        ),
        "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="+", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.reports, args.protocol)
    write_json(args.output, result)
    print(
        json.dumps(
            {
                "verified_outputs": result["verified_outputs"],
                "primary_pass": result["primary_pass"],
                "all_feasible": result["estimates"]["all_feasible"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
