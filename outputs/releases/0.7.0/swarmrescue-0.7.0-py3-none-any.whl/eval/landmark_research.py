"""Source-aware monotone landmark contraction; third research iteration."""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.contract_research import frozen_hashes as previous_hashes,solver as previous_solver
from eval.landmark_analysis import one
from mcu.landmark import LandmarkSolver
from mcu.fused import FusedSolver

METHODS=("landmark_certificate","contracted_certificate","transport_sparse",
         "sparse_incremental_dp","expanded_dstar_lite","sparse_event","sparse_hybrid")
EXTRA=("firmware/deadline_landmark.c","mcu/landmark.py","tests/test_landmark.py",
       "eval/landmark_research.py","eval/landmark_analysis.py","firmware/deadline_fused.c",
       "mcu/fused.py","tests/test_fused.py")


def frozen_hashes():
    root=Path(__file__).resolve().parents[1]
    return dict(previous_hashes(),**{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in EXTRA})


def solver(fixed,method="transport_sparse",*,memory_bytes=64*1024*1024):
    if method=="landmark_certificate":
        return FusedSolver(LandmarkSolver(fixed,memory_bytes=memory_bytes),"landmark")
    base=previous_solver(fixed,method,memory_bytes=memory_bytes)
    kinds={"contracted_certificate":"contract","transport_sparse":"transport",
           "sparse_incremental_dp":"dp","expanded_dstar_lite":"dynamic"}
    return FusedSolver(base,kinds[method]) if method in kinds else base


def main():
    experiment.METHODS=METHODS;experiment.TransportSolver=solver
    experiment.hashes=frozen_hashes;experiment.analyze=one;experiment.main()


if __name__=="__main__":
    main()
