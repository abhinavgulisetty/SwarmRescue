"""Supplementary author-binary checks on initial/middle/final stream snapshots.

No upstream source is bundled. Author initialization/search timings have a
different scope and unrestricted memory; they are not primary speed claims.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path

from eval.routing_certificates import read_json, require, write_json


def call(binary, model):
    terminal = len(model["adjacent"])
    edges = [(u, v, c, t) for u, row in enumerate(model["adjacent"]) for v, t, c in row]
    edges.extend((g, terminal, 1, 1) for g in model["goals"])
    env = os.environ.copy()
    env["EMBER_REFERENCE_DEADLINE"] = str(model["deadline"] + 1)
    with tempfile.TemporaryDirectory(prefix="cmr-author-") as folder:
        path = Path(folder) / "query.xy"
        lines = [f"nodes {terminal + 1} edges {len(edges)} objectives 2"]
        lines.extend(f"v {v} 0 0 0" for v in range(terminal + 1))
        lines.extend(f"e {u} {v} {c} {t}" for u, v, c, t in edges)
        path.write_text("\n".join(lines) + "\n")
        process = subprocess.run(
            [
                str(binary),
                "--alg",
                "NWRCA",
                "--input",
                str(path),
                "--start",
                str(model["start"]),
                "--goal",
                str(terminal),
                "--constraint",
                "50",
                "--queue",
                "bucket",
                "--noheader",
                "--nruns",
                "3",
            ],
            env=env,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    rows = [
        line.split()
        for line in process.stdout.splitlines()
        if line.startswith("NWRCA ")
    ]
    require(process.returncode == 0 and len(rows) == 3, "author binary failure")
    values = [(int(r[6]), int(r[7])) for r in rows]
    require(len(set(values)) == 1, "author repeat disagreement")
    cost, count = values[0]
    return dict(
        feasible=count > 0,
        cost_q16=cost - 1 if count else None,
        author_core_ms=[1000 * (float(r[8]) + float(r[9])) for r in rows],
        stdout=process.stdout,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = read_json(args.report)
    binary = args.binary.absolute()
    results = []
    for row in report["rows"]:
        # One background stream per map; endpoints/topology shared across kinds.
        if row["stream_kind"] != "background":
            continue
        model = json.loads(json.dumps(row["initial_model"]))
        locations = [
            (u, i)
            for u, edges in enumerate(model["adjacent"])
            for i in range(len(edges))
        ]
        selected = {0, len(row["changes"]) // 2, len(row["changes"])}
        for frame in range(len(row["changes"]) + 1):
            if frame:
                for e, cost in row["changes"][frame - 1]:
                    u, i = locations[e]
                    model["adjacent"][u][i][2] = cost
            if frame not in selected:
                continue
            result = call(binary, model)
            optimum = row["optima_q16"][frame]
            require(result["feasible"] == (optimum is not None), "author feasibility")
            require(result["cost_q16"] == optimum, "author optimum")
            results.append(
                dict(
                    seed=row["seed"],
                    family=row["family"],
                    frame=frame,
                    optimum_q16=optimum,
                    result=result,
                )
            )
        print(f"Author check {row['seed']}/{row['family']}", flush=True)
    write_json(
        args.output,
        dict(
            supplementary=True,
            matched=len(results),
            total=len(results),
            report_sha256=hashlib.sha256(args.report.read_bytes()).hexdigest(),
            binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
            revision="4098543d0c5d78afc977017b5abf6054671a8c43",
            timing_scope=(
                "Author core timer; unrestricted memory; no primary speed claim."
            ),
            rows=results,
        ),
    )


if __name__ == "__main__":
    main()
