"""Audit every event-study certificate and repeat; separate API/kernel endpoints."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

from eval.constrained_benchmark import FAMILIES, LABEL_CAPS
from eval.event_research import METHODS
from eval.paper_confirmation import estimate
from eval.routing_certificates import read_json, require, verify_result, verify_table


def analyze(paths, protocol_path):
    protocol = read_json(protocol_path)
    protocol_digest = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
    reports = [read_json(p) for p in paths]
    expected = set(itertools.product(protocol["seeds"], FAMILIES, LABEL_CAPS))
    groups = {}
    checks = states = 0
    for report in reports:
        require(report["protocol_sha256"] == protocol_digest, "protocol digest")
        require(report["source_sha256"] == protocol["source_sha256"], "source hashes")
        arena = report["numeric_arena_bytes"]
        session = report["session"]
        require(arena in protocol["arenas"], "arena")
        require(session not in groups.setdefault(arena, {}), "duplicate session")
        models = {}
        for cert in report["certificates"]:
            key = cert["seed"], cert["family"]
            require(key not in models, "duplicate certificate")
            optimum = verify_table(cert["model"], cert["values"])
            require(optimum == cert["optimum_q16"], "oracle optimum")
            models[key] = cert
            states += len(cert["values"]) * len(cert["model"]["adjacent"])
        index = {}
        for row in report["rows"]:
            key = row["seed"], row["family"], row["label_capacity"]
            require(key not in index, "duplicate case")
            cert = models[key[:2]]
            model = cert["model"]
            require(
                hashlib.sha256(json.dumps(model, sort_keys=True).encode()).hexdigest()
                == row["model_sha256"],
                "model hash",
            )
            require(row["optimum_q16"] == cert["optimum_q16"], "case optimum")
            require(set(row["results"]) == set(METHODS), "methods")
            require(len(row["orders"]) == protocol["repeats"], "orders count")
            require(
                all(sorted(order) == sorted(METHODS) for order in row["orders"]),
                "orders permutations",
            )
            require(
                all(
                    index_row["nontrivial"] == row["nontrivial"]
                    for idx in groups[arena].values()
                    if key in idx
                    for index_row in [idx[key]]
                ),
                "classification differs by session",
            )
            for entry in row["results"].values():
                kernel_values = [sample["kernel_ms"] for sample in entry["samples"]]
                expected_kernel = (
                    float(np.median(kernel_values))
                    if all(value is not None for value in kernel_values)
                    else None
                )
                require(entry["median_kernel_ms"] == expected_kernel, "kernel median")
                require(len(entry["samples"]) == protocol["repeats"], "repeat count")
                require(
                    entry["median_ms"]
                    == float(np.median([s["elapsed_ms"] for s in entry["samples"]])),
                    "median",
                )
                for sample in entry["samples"]:
                    verify_result(model, sample, cert["optimum_q16"], arena_bytes=arena)
                    require(sample["elapsed_ms"] > 0, "nonpositive timing")
                    if sample["kernel_ms"] is not None:
                        require(
                            0 < sample["kernel_ms"] <= sample["elapsed_ms"],
                            "kernel timing",
                        )
                    checks += 1
            index[key] = row
        require(set(index) == expected, "case coverage")
        groups[arena][session] = index
    result = {}
    scopes = {}
    for arena, sessions in groups.items():
        require(set(sessions) == set(range(protocol["sessions"])), "session coverage")

        def exact(key, method, sessions=sessions):
            return all(
                s["feasible"] and s["optimal"]
                for index in sessions.values()
                for s in index[key]["results"][method]["samples"]
            )

        feasible = [
            k for k in sorted(expected) if sessions[0][k]["optimum_q16"] is not None
        ]
        result[str(arena)] = {}
        for method in METHODS:
            pairs = []
            for key in feasible:
                if exact(key, method) and exact(key, "event_exact"):
                    pair_rows = [
                        dict(
                            results={
                                "native_exact": sessions[p][key]["results"][
                                    "event_exact"
                                ],
                                "baseline": sessions[p][key]["results"][method],
                            }
                        )
                        for p in range(protocol["sessions"])
                    ]
                    pairs.append((key, pair_rows))
            entry = dict(
                feasible_cases=len(feasible),
                all_sessions_all_repeats_exact=sum(exact(k, method) for k in feasible),
                max_numeric_bytes=max(
                    s["arena_high_water_bytes"]
                    for idx in sessions.values()
                    for row in idx.values()
                    for s in row["results"][method]["samples"]
                ),
                statistics=estimate(pairs, "baseline", comparisons=2),
                unresolved_cases=[list(k) for k in feasible if not exact(k, method)],
            )
            result[str(arena)][method] = entry
            for scope in (
                "all_full",
                "nontrivial_full",
                "all_kernel",
                "nontrivial_kernel",
            ):
                scope_pairs = []
                for key in feasible:
                    if "nontrivial" in scope and not sessions[0][key]["nontrivial"]:
                        continue
                    if not (exact(key, method) and exact(key, "event_exact")):
                        continue
                    is_kernel = "kernel" in scope
                    if is_kernel and not all(
                        s["kernel_complete"]
                        for idx in sessions.values()
                        for m in (method, "event_exact")
                        for s in idx[key]["results"][m]["samples"]
                    ):
                        continue
                    metric = "median_kernel_ms" if is_kernel else "median_ms"
                    pair_rows = [
                        dict(
                            results={
                                "native_exact": {
                                    "median_ms": sessions[p][key]["results"][
                                        "event_exact"
                                    ][metric]
                                },
                                "baseline": {
                                    "median_ms": sessions[p][key]["results"][method][
                                        metric
                                    ]
                                },
                            }
                        )
                        for p in range(protocol["sessions"])
                    ]
                    scope_pairs.append((key, pair_rows))
                scopes.setdefault(str(arena), {}).setdefault(scope, {})[method] = (
                    estimate(
                        scope_pairs,
                        "baseline",
                        comparisons=2
                        if method in protocol["primary_comparators"]
                        else len(METHODS) - 1,
                    )
                )

    primary = scopes[str(protocol["arenas"][0])]["all_full"]
    candidate_coverage = result[str(protocol["arenas"][0])]["event_exact"][
        "all_sessions_all_repeats_exact"
    ]
    primary_passes = all(
        primary[method]["bonferroni_simultaneous_95ci"][0] > 1
        and candidate_coverage
        >= result[str(protocol["arenas"][0])][method]["all_sessions_all_repeats_exact"]
        for method in protocol["primary_comparators"]
    )
    return dict(
        primary_rule_passes=primary_passes,
        verified_repeats=checks,
        verified_bellman_equalities=states,
        distinct_maps=len(protocol["seeds"]) * len(FAMILIES),
        cap_specific_cases_per_arena=len(expected),
        summary=result,
        scopes=scopes,
        protocol_sha256=protocol_digest,
        raw_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("reports", type=Path, nargs="+")
    args = parser.parse_args()
    result = analyze(args.reports, args.protocol)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    with args.output.with_suffix(".csv").open("w") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "arena_bytes",
                "method",
                "exact",
                "feasible",
                "max_numeric_bytes",
                "speedup",
                "ci_low",
                "ci_high",
            ]
        )
        for arena, methods in result["summary"].items():
            for method, entry in methods.items():
                stats = entry["statistics"]
                writer.writerow(
                    [
                        arena,
                        method,
                        entry["all_sessions_all_repeats_exact"],
                        entry["feasible_cases"],
                        entry["max_numeric_bytes"],
                        stats.get("candidate_geomean_speedup"),
                        *stats.get("process_and_seed_bootstrap_95ci", [None, None]),
                    ]
                )
    print(
        json.dumps(
            {
                "verified_repeats": result["verified_repeats"],
                "summary": result["summary"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
