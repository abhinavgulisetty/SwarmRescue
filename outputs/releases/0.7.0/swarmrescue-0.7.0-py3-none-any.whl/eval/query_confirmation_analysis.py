"""Locked whole-seed/session bootstrap with joint correction over all reported CIs."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from eval.transport_analysis import load
from eval.query_confirmation_audit import validate

def analyze(studies,kind=None):
    design=studies[0]['design'];methods=[m for m in design['methods'] if m!='transport_sparse']
    chosen=[[r for r in s['rows'] if r['initial']['feasible'] and r['frames']
             and (kind is None or r['kind']==kind)] for s in studies]
    seeds=sorted({r['seed'] for r in chosen[0]})
    counts=np.array([sum(r['seed']==seed for r in chosen[0]) for seed in seeds])
    rng=np.random.default_rng(417802)
    seed_draw=rng.integers(len(seeds),size=(100000,len(seeds)))
    session_draw=rng.integers(len(studies),size=(100000,len(studies)))
    # Primary mixture and two predefined processes, jointly over all controls.
    alpha=.05/(3*len(methods))
    out=dict(feasible_traces=len(chosen[0]),seed_blocks=len(seeds),sessions=len(studies),comparisons={})
    for method in methods:
        logs=np.array([[math.log(np.median([run[method]['total_ns'] for run in r['runs']])/
                        np.median([run['transport_sparse']['total_ns'] for run in r['runs']]))
                       for r in rows] for rows in chosen])
        sums=np.array([[sum(v for v,r in zip(values,rows,strict=True) if r['seed']==seed)
                        for seed in seeds] for values,rows in zip(logs,chosen,strict=True)])
        boot=np.exp(sums[session_draw[:,:,None],seed_draw[:,None,:]].sum((1,2))/
                    (len(studies)*counts[seed_draw].sum(1)))
        interval=np.quantile(boot,[alpha/2,1-alpha/2]).tolist()
        # Diagnostic sensitivity only, without interpreting these as CIs.
        loo=[math.exp(float((sums.sum()-sums[:,i].sum())/
                   (len(studies)*(counts.sum()-counts[i])))) for i in range(len(seeds))]
        out['comparisons'][method]=dict(ratio=math.exp(float(logs.mean())),
            simultaneous_95_interval=interval,interval_above_one=interval[0]>1,
            leave_one_seed_out_point_range=[min(loo),max(loo)],
            per_family_point_ratios={family:math.exp(float(logs[:,[r['family']==family for r in chosen[0]]].mean()))
                for family in design['families']})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('inputs',nargs='+',type=Path)
    ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    studies=[load(p) for p in args.inputs];complete=validate(studies)
    output=dict(primary=analyze(studies),by_kind={kind:analyze(studies,kind) for kind in ('background','mixed')},
        completeness=complete,confidence_family='15 jointly Bonferroni-corrected intervals: 5 comparators x (mixture, background, mixed)',
        bootstrap='100000 draws, whole seeds crossed with whole process sessions; median 3 repeats per trace/session',
        diagnostic_scope='Family and leave-one-seed-out values are point estimates only, without superiority inference',
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in args.inputs})
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output['primary']),flush=True)

if __name__=='__main__':main()
