"""Independent arbitrary-integer constrained A* / Pareto-label oracle.

No native planner calls or certificate summaries. Bounds are ordinary reverse
shortest paths; dominated elapsed-time/cost labels are removed explicitly.
This is verification code implementing established search principles.
"""
import heapq
from eval.routing_certificates import validate_model


def solve(model):
    validate_model(model)
    adjacent=model["adjacent"];n=len(adjacent);goals=set(model["goals"])
    reverse=[[] for _ in range(n)]
    for u,row in enumerate(adjacent):
        for v,t,c in row:
            reverse[v].append((u,t,c))

    def distances(clock_only):
        distance=[None]*n;queue=[]
        for goal in goals:
            distance[goal]=(0,0);heapq.heappush(queue,(0,0,goal))
        while queue:
            value,clock,u=heapq.heappop(queue)
            if distance[u]!=(value,clock):
                continue
            for v,t,c in reverse[u]:
                proposal=(value+(t if clock_only else c),clock+t)
                if distance[v] is None or proposal<distance[v]:
                    distance[v]=proposal;heapq.heappush(queue,(*proposal,v))
        return distance

    start=model["start"];budget=model["deadline"]
    lower_clock=distances(True)
    if lower_clock[start] is None or lower_clock[start][0]>budget:
        return None
    lower_cost=distances(False)
    if lower_cost[start][1]<=budget:
        return lower_cost[start][0]
    fronts=[[] for _ in range(n)];fronts[start]=[(0,0)]
    queue=[(lower_cost[start][0],0,0,start)]
    while queue:
        _,cost,elapsed,u=heapq.heappop(queue)
        if (elapsed,cost) not in fronts[u]:
            continue
        if u in goals:
            return cost
        for v,t,c in adjacent[u]:
            time=elapsed+t
            if lower_clock[v] is None or time+lower_clock[v][0]>budget:
                continue
            value=cost+c
            if any(old_t<=time and old_c<=value for old_t,old_c in fronts[v]):
                continue
            fronts[v]=[(old_t,old_c) for old_t,old_c in fronts[v]
                       if not (time<=old_t and value<=old_c)]
            fronts[v].append((time,value))
            heapq.heappush(queue,(value+lower_cost[v][0],value,time,v))
    return None
