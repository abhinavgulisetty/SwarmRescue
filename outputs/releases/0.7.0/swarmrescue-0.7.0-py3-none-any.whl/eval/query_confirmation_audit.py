"""Fail-closed study completeness checks followed by all-query independent replay."""
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
import eval.transport_audit as audit
from eval.contract_oracle import solve
from eval.query_confirmation import frozen_hashes

def validate(studies):
    design=studies[0]['design']
    expected=list(product(design['seeds'],design['families'],design['kinds'],design['rates']))
    sessions=[s['session'] for s in studies]
    if sorted(sessions)!=list(range(design['sessions'])):
        raise ValueError('missing or duplicate sessions')
    for s in studies:
        if s['design']!=design:raise ValueError('protocol mismatch')
        keys=[tuple(r[k] for k in ('seed','family','kind','rate')) for r in s['rows']]
        if keys!=expected:raise ValueError('missing, duplicate or reordered trace')
        for row in s['rows']:
            if len(row['runs'])!=design['repeats']:raise ValueError('repeat count')
            for run in row['runs']:
                if set(run)!=set(design['methods']):raise ValueError('method count')
                for item in run.values():
                    if (len(item['results'])!=1+len(row['frames'])
                        or len(item['statuses'])!=len(row['frames'])
                        or type(item['total_ns']) is not int or item['total_ns']<=0):
                        raise ValueError('incomplete or invalid result series')
    return dict(expected_traces=len(expected),expected_sessions=design['sessions'],
        expected_repeats=design['repeats'],expected_methods=len(design['methods']))

def main():
    inputs=[Path(v) for v in sys.argv[1:sys.argv.index('--output')]]
    studies=[]
    for p in inputs:
        with gzip.open(p,'rt') as stream:studies.append(json.load(stream))
    completeness=validate(studies)
    audit.hashes=frozen_hashes;audit.bellman_table=solve;audit.verify_table=lambda model,value:value
    audit.main()
    output=Path(sys.argv[sys.argv.index('--output')+1])
    receipt=json.loads(output.read_text());receipt.pop('bellman_equalities')
    receipt['completeness']=completeness
    receipt['independent_oracle']='Python arbitrary-integer constrained A* / Pareto labels; no native solver'
    receipt['oracle_source_sha256']=hashlib.sha256(Path(__file__).with_name('contract_oracle.py').read_bytes()).hexdigest()
    receipt['wrapper_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

if __name__=='__main__':main()
