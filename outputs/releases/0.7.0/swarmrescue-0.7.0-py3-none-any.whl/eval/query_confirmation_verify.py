"""Memory-bounded entry point for the locked completeness/all-query audit.

Same frozen validators/oracle as the planned auditor, but release the first
JSON decode before the generic replay decodes again. No statistical changes.
"""
import gc
import hashlib
import json
from pathlib import Path
import sys
import eval.transport_audit as audit
from eval.contract_oracle import solve
from eval.query_confirmation import frozen_hashes
from eval.query_confirmation_audit import validate
from eval.transport_analysis import load

def main():
    inputs=[Path(v) for v in sys.argv[1:sys.argv.index('--output')]]
    studies=[load(p) for p in inputs]
    completeness=validate(studies)
    del studies
    gc.collect()
    audit.hashes=frozen_hashes;audit.bellman_table=solve;audit.verify_table=lambda model,value:value
    audit.main()
    path=Path(sys.argv[sys.argv.index('--output')+1]);receipt=json.loads(path.read_text())
    receipt.pop('bellman_equalities')
    receipt.update(completeness=completeness,
        independent_oracle='Python arbitrary-integer constrained A* / Pareto labels; no native solver',
        oracle_source_sha256=hashlib.sha256(Path(__file__).with_name('contract_oracle.py').read_bytes()).hexdigest(),
        wrapper_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        adjustment='Release completeness-check JSON objects before replay; same frozen validation logic and oracle')
    path.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

if __name__=='__main__':main()
