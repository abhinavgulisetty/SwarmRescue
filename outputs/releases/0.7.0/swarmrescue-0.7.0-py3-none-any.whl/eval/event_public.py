"""Supplementary public Moving AI geometry with declared synthetic hazards."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from eval.constrained_benchmark import _graph, _pair_distance, arcs
from eval.event_research import METHODS, hashes, measured_call
from eval.paper_evidence import independently_encode
from eval.routing_certificates import (
    bellman_table,
    verify_result,
    verify_table,
    write_json,
)
from mcu import MCUArena


def public_case(path, seed):
    lines = path.read_text().splitlines()
    width, height = int(lines[2].split()[1]), int(lines[1].split()[1])
    pixels = lines[4:]
    if len(pixels) != height or any(len(row) != width for row in pixels):
        raise ValueError("map dimensions")
    cells = [
        (x, y)
        for y, row in enumerate(pixels)
        for x, char in enumerate(row)
        if char in ".GS"
    ]
    index = {cell: i for i, cell in enumerate(cells)}
    edges = [
        (i, index[next_cell])
        for (x, y), i in index.items()
        for next_cell in ((x + 1, y), (x, y + 1))
        if next_cell in index
    ]
    positions = np.array([[x, y, 0] for x, y in cells])
    graph = _graph(len(cells), edges, np.ones(len(edges)), positions)
    rng = np.random.default_rng(seed)
    start, goal = map(int, rng.choice(len(cells), 2, replace=False))
    risk = np.full(len(cells), 0.1)
    for _ in range(6):
        center = rng.uniform([0, 0], [width, height])
        spread = rng.uniform(1.5, 6.0)
        risk += rng.uniform(4, 25) * np.exp(
            -np.sum((positions[:, :2] - center) ** 2, axis=1) / (2 * spread * spread)
        )
    adjacent = arcs(graph, risk)
    fastest = _pair_distance(adjacent, start, {goal}, True)
    cheapest = _pair_distance(adjacent, start, {goal}, False)
    deadline = int(fastest[0] + 0.5 * (cheapest[1] - fastest[0])) if fastest else 30
    return graph, start, (goal,), risk, deadline


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--maps", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    before = hashes()
    manifest = json.loads((args.maps / "manifest.json").read_text())
    rows = []
    certificates = []
    for entry in manifest:
        path = args.maps / entry["name"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise RuntimeError("map checksum")
        for seed in range(133000, 133012):
            case = public_case(path, seed)
            model = independently_encode(case)
            values = bellman_table(model)
            optimum = verify_table(model, values)
            certificates.append(
                dict(
                    map=entry["name"],
                    seed=seed,
                    model=model,
                    values=values,
                    optimum_q16=optimum,
                )
            )
            results = {method: {"samples": []} for method in METHODS}
            order_rng = np.random.default_rng(seed)
            for _ in range(5):
                order = list(METHODS)
                order_rng.shuffle(order)
                for method in order:
                    result = measured_call(case, 128, method, MCUArena(204800))
                    verify_result(model, result, optimum, arena_bytes=204800)
                    results[method]["samples"].append(result)
            for item in results.values():
                item["median_ms"] = float(
                    np.median([x["elapsed_ms"] for x in item["samples"]])
                )
            rows.append(
                dict(
                    map=entry["name"],
                    seed=seed,
                    results=results,
                    optimum_q16=optimum,
                    nodes=case[0].n_nodes,
                    deadline=case[-1],
                )
            )
        print(f"Public geometry {entry['name']}: completed", flush=True)
    if hashes() != before:
        raise RuntimeError("source changed")
    summary = {}
    for method in METHODS:
        feasible = [x for x in rows if x["optimum_q16"] is not None]

        def exact(row, method):
            return all(
                s["feasible"] and s["optimal"]
                for s in row["results"][method]["samples"]
            )

        pairs = [x for x in feasible if exact(x, method) and exact(x, "event_exact")]
        summary[method] = dict(
            feasible_cases=len(feasible),
            exact=sum(exact(x, method) for x in feasible),
            exact_pairs=len(pairs),
            speedup=(
                float(
                    np.exp(
                        np.mean(
                            [
                                np.log(
                                    x["results"][method]["median_ms"]
                                    / x["results"]["event_exact"]["median_ms"]
                                )
                                for x in pairs
                            ]
                        )
                    )
                )
                if pairs
                else None
            ),
        )
    write_json(
        args.output,
        dict(
            supplementary_posthoc=True,
            source_sha256=before,
            description=(
                "Public map geometry, four-neighbor movement, authored "
                "hazards and endpoints; not original MAPF or calibrated egress."
            ),
            map_manifest=manifest,
            rows=rows,
            certificates=certificates,
            summary=summary,
        ),
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
