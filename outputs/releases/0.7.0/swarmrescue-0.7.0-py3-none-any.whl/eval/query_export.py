"""Export the final typed-interface study, proofs and all negative comparisons."""
import argparse
import hashlib
import json
import platform
import re
import shutil
import subprocess
import tarfile
from pathlib import Path
from eval.transport_analysis import load

ROOT=Path(__file__).resolve().parents[1]
LABELS={"contracted_certificate":"Goal-clock contraction","landmark_certificate":"Landmark contraction",
    "sparse_incremental_dp":"Sparse incremental DP","expanded_dstar_lite":"Expanded D* Lite (h=0)",
    "sparse_event":"Sparse-input event solver","sparse_hybrid":"Sparse-input hybrid solver"}


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--study",type=Path,default=Path("outputs/query-safe"))
    ap.add_argument("--out",type=Path,default=Path("docs/paper/query"));args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    summary=json.loads((args.study/"summary.json").read_text())
    audit=json.loads((args.study/"independent-audit.json").read_text())
    studies=[load(args.study/f"fresh-session{i}.json.gz") for i in range(3)]
    design=studies[0]["design"]
    if any(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h for p,h in design["sources"].items()):
        raise ValueError("source lock changed")
    for name in ("fresh-session0.json.gz","fresh-session1.json.gz","fresh-session2.json.gz",
                 "summary.json","independent-audit.json","validation.json","published-reference.json.gz"):
        if (args.study/name).exists():
            shutil.copy2(args.study/name,args.out/name)
    shutil.copy2(ROOT/"eval/query_safe_protocol.json",args.out/"protocol.json")
    for source,name in (("outputs/contract/summary.json","earlier-negative-study.json"),
        ("outputs/transport/published-reference.json.gz.failure.json","original-author-failure.json"),
        ("outputs/algorithm-research/reference-transport-positive/ember-build.json","positive-author-build.json")):
        if (ROOT/source).exists():
            shutil.copy2(ROOT/source,args.out/name)
    table="| Comparator | Comparator / TSC time | Simultaneous 95% interval | Interpretation |\n| --- | ---: | --- | --- |\n"
    for method,result in summary["primary"]["comparisons"].items():
        lo,hi=result["simultaneous_95_interval"]
        verdict="TSC faster" if lo>1 else "TSC slower" if hi<1 else "Inconclusive"
        table+=f"| {LABELS[method]} | {result['ratio']:.3f}x | [{lo:.3f}, {hi:.3f}] | {verdict} |\n"
    counts=summary["primary"]
    text=(f"The study contains {len(studies[0]['rows'])} traces, {counts['feasible_traces']} "
        f"initially feasible traces and {counts['seed_blocks']} informative seed blocks, "
        "with three repeats in each of three process sessions. Ratios are geometric "
        "whole-stream ratios and include construction; values above one favor TSC.\n\n"+table+
        f"\nIndependent arbitrary-integer Python replay checks {audit['output_records']:,} "
        f"output records over {audit['unique_queries']:,} distinct queries. Repeated "
        "records are not independent statistical samples.\n")
    text+="\nThe predefined hazard-process slices are secondary. Their intervals correct six comparisons within each slice; they do not replace the primary mixture.\n\n"
    text+="| Update process | Versus sparse event solver | Versus sparse hybrid solver |\n| --- | --- | --- |\n"
    for kind in ("background","mixed"):
        cells=[]
        for name in ("sparse_event","sparse_hybrid"):
            value=summary["by_kind"][kind]["comparisons"][name]
            lo,hi=value["simultaneous_95_interval"]
            cells.append(f"{value['ratio']:.3f}x [{lo:.3f}, {hi:.3f}]")
        text+=f"| {kind} | {cells[0]} | {cells[1]} |\n"
    paper=args.out/"manuscript.md";body=paper.read_text()
    block="<!-- RESULTS:START -->\n"+text+"<!-- RESULTS:END -->"
    body=body.replace("@@RESULTS@@",block) if "@@RESULTS@@" in body else re.sub(
        r"<!-- RESULTS:START -->.*?<!-- RESULTS:END -->",lambda _:block,body,flags=re.S)
    paper.write_text(body)
    memory={}
    for method in design["methods"]:
        parts=[]
        for row in studies[0]["rows"]:
            stats=row["runs"][0][method]["stats"]
            m=sum(map(len,row["model"]["adjacent"]))
            adapter=28*m if method in ("sparse_event","sparse_hybrid") else 0
            parts.append(dict(core_retained=stats["retained_numeric_bytes"],core_peak=stats["peak_numeric_bytes"],
                adapter_arrays=adapter,combined_counted_peak=stats["peak_numeric_bytes"]+adapter,
                reserved_arena=stats.get("reserved_arena_bytes",0)))
        memory[method]={k:max(p[k] for p in parts) for k in parts[0]}
    (args.out/"memory.json").write_text(json.dumps(dict(scope="Counted private numeric payloads; output arrays, shared inputs, Python/allocator overhead and stack excluded. Arena reservation is separate.",methods=memory),indent=2)+"\n")
    head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()
    import importlib.metadata
    metadata=dict(parent_commit=head,platform=platform.platform(),python=platform.python_version(),
        numpy=importlib.metadata.version("numpy"),
        compiler=subprocess.check_output(["cc","--version"],text=True).splitlines()[0],sources=design["sources"])
    for line in Path("/proc/cpuinfo").read_text().splitlines():
        if line.startswith("model name"):
            metadata["cpu"]=line.split(":",1)[1].strip();break
    (args.out/"host-and-source.json").write_text(json.dumps(metadata,indent=2)+"\n")
    readme=("# Transported Sparse Certificates: proof and evidence\n\n"
        "The candidate transports coupled optimality bounds across executed route prefixes "
        "and maintains them after sparse cost patches. An accepted update costs "
        "O(k log(1+Delta)+k log(1+V)+a+1), excluding output, with O(V+E) retained "
        "state independent of the deadline. Optional clock cuts strictly enlarge "
        "the same-anchor sufficient region but do not necessarily run faster.\n\n"
        "[Research and novelty boundaries](../../query-routing-research.md), "
        "[full transport proof](../../transport-routing-research.md), "
        "[working manuscript](manuscript.md), [source lock](protocol.json).\n\n"+text+
        "\n![Optional sufficient-region improvement and complete-call speed](region-and-speed.svg)\n\n"
        "## Scope\n\n"
        "All methods use the same positive integer objective, fixed topology/goals/clocks, "
        "moving starts and shrinking budgets. Sparse arrays and fused update/output "
        "interfaces are used for the comparators. The typed-bridge rerun preserves the "
        "preselected cohort, methods and inference rules. Shared topology/patch generation "
        "and compilation are excluded; setup, call validation, output and teardown are included. "
        "These are authored software traces on one host. Subgroup gains do not override "
        "an inconclusive primary mixture. Historical priority and superiority over all "
        "published methods are not established.\n\n"
        "The D* baseline is our h=0 expanded-state implementation. The sparse DP control "
        "retains generic once-per-stream metadata allocations. Numeric memory counts "
        "are in [memory.json](memory.json); they are not whole-process or MCU RAM. "
        "The [earlier negative study](earlier-negative-study.json) remains preserved.\n\n"
        "The original author binary's [positive-cost failure](original-author-failure.json) "
        "and the separate [positive-cost adaptation](positive-author-build.json) are "
        "documented. Adapted-author checks are supplementary correctness evidence, "
        "without a matched primary speed claim.\n\n"
        "## Reproduction\n\n"
        f"Use parent checkout `{head}`, overlay `research-source.tar.gz`, and install "
        "the project's declared Python dependencies and a C compiler.\n\n"
        "```bash\nfor session in 0 1 2; do\n"
        "  .venv/bin/python -m eval.query_safe_research --protocol eval/query_safe_protocol.json "
        "--seeds 193000:193011 --families grid,tradeoff,large_grid --rates 1,4 --limit 96 "
        '--repeats 3 --session "$session" --output "outputs/query-safe/fresh-session${session}.json.gz"\ndone\n'
        ".venv/bin/python -m eval.transport_analysis outputs/query-safe/fresh-session{0,1,2}.json.gz --output outputs/query-safe/summary.json\n"
        ".venv/bin/python -m eval.query_audit outputs/query-safe/fresh-session{0,1,2}.json.gz --output outputs/query-safe/independent-audit.json\n```\n\n"
        "The lock is local, not publicly timestamped preregistration. Raw records, "
        "audit receipts, source hashes and checksums preserve the evidence. The "
        "earlier transport and contraction studies remain separately archived.\n")
    (args.out/"README.md").write_text(readme)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    fig,axes=plt.subplots(1,2,figsize=(11.8,4.2),gridspec_kw={"width_ratios":[1,1.7]})
    d=np.linspace(0,5,300)
    axes[0].fill_between(d,-3,2,color="#c6dfd5",label="Optional contraction")
    axes[0].fill_between(d,-3,2-d,color="#387f92",alpha=.85,label="Default guard")
    axes[0].plot([3],[0],"o",color="#ad3c30",label="Strict witness")
    axes[0].set(xlim=(0,5),ylim=(-3,3),xlabel="Reduction on excluded node's incoming arc",
        ylabel="Current suffix cost shift",title="Same-anchor sufficient regions")
    axes[0].legend(fontsize=8,loc="lower left")
    names=list(summary["primary"]["comparisons"])
    for i,name in enumerate(names):
        result=summary["primary"]["comparisons"][name];ratio=result["ratio"]
        lo,hi=result["simultaneous_95_interval"]
        axes[1].errorbar(ratio,i,xerr=[[ratio-lo],[hi-ratio]],fmt="o",capsize=3,
            color="#276d83" if lo>1 else "#777777")
    axes[1].axvline(1,color="#ad3c30",linestyle="--",linewidth=1)
    axes[1].set_yticks(range(len(names)),[LABELS[n] for n in names],fontsize=8)
    axes[1].invert_yaxis();axes[1].set_xscale("log")
    axes[1].set(xlabel="Comparator time / TSC time",title="Complete calls, simultaneous 95% intervals")
    fig.tight_layout()
    for suffix in ("svg","pdf","png"):
        fig.savefig(args.out/f"region-and-speed.{suffix}",dpi=180)
    plt.close(fig)
    extra=("eval/query_audit.py","eval/transport_audit.py","eval/contract_oracle.py",
        "tests/test_contract_oracle.py","eval/query_export.py","eval/query_safe_protocol.json",
        "eval/query_protocol.json","eval/contract_protocol.json","eval/transport_protocol.json",
        "eval/transport_reference.py","eval/transport_author_build.py","eval/query_stress.c",
        "docs/query-routing-research.md","docs/transport-routing-research.md",
        "docs/contract-routing-research.md","docs/retention-routing-research.md",
        "docs/paper/query/manuscript.md","tests/test_retention.py","eval/retention_certificates.py")
    with tarfile.open(args.out/"research-source.tar.gz","w:gz") as archive:
        for path in sorted(set(design["sources"])|set(extra)):
            archive.add(ROOT/path,arcname=path)
    sums=[f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}" for p in sorted(args.out.iterdir())
          if p.is_file() and p.name!="SHA256SUMS"]
    (args.out/"SHA256SUMS").write_text("\n".join(sums)+"\n")
    print(json.dumps(dict(exported=str(args.out),source_lock_matches=True)),flush=True)


if __name__=="__main__":
    main()
