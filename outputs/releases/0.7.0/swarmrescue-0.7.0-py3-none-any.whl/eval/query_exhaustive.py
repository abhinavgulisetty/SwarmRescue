"""Finite-domain verification independent of native Bellman and A* solvers.

Enumerates budget-feasible walks for anchor bounds (cycles may be necessary
for valid transport bounds), and simple paths for current exact optima.
This is bounded model checking, not a replacement for the mathematical proof.
"""
from __future__ import annotations
import argparse
from collections import Counter
from itertools import combinations,product
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from eval.retention_exhaustive import enumerated_optimum
from eval.routing_certificates import verify_result
from mcu.retention import FixedModel
from eval.query_safe_research import solver as native_solver

def paths(adjacent,start,goals,budget,simple):
    answer=[]
    def visit(u,clock,cost,route,edges):
        if u in goals:
            answer.append((clock,cost,route,edges));return
        for i,(v,t,c) in enumerate(adjacent[u]):
            if t+clock<=budget and (not simple or v not in route):
                visit(v,clock+t,cost+c,route+(v,),edges+((u,i),))
    visit(start,0,0,(start,),())
    return answer

def prefix(gaps,red,shift,floor):
    if floor is None:return True
    if shift>floor:return False
    total=0
    for g,a in sorted((g,red[v]) for v,g in enumerate(gaps) if g is not None):
        total+=a
        if shift+total>max(g,floor):return False
    return True

def prefix_equivalence():
    count=0
    for n in range(5):
        for gaps in combinations(range(n+3),n):
            for reductions in product(range(3),repeat=n):
                for floor,shift in product(range(3),range(-2,4)):
                    scan=all(shift+sum(reductions[i] for i in range(n) if mask>>i&1)
                        <=max([floor]+[gaps[i] for i in range(n) if mask>>i&1])
                        for mask in range(1<<n))
                    assert prefix(gaps,reductions,shift,floor)==scan
                    count+=1
    return count

def mathematical_domain():
    counts=Counter();arcs=[(u,v) for u in range(3) for v in range(3) if u!=v]
    # Every directed topology on 3 vertices, with each existing arc assigned
    # either (clock=1,cost=4) or (clock=2,cost=2), including true tradeoffs.
    for states in product(range(3),repeat=6):
        adjacent=[[] for _ in range(3)]
        for (u,v),state in zip(arcs,states):
            if state:adjacent[u].append([v,state,6-2*state])
        locations=[(u,i) for u,row in enumerate(adjacent) for i in range(len(row))]
        counts['weighted_graphs']+=1
        for goals,deadline in product(({2},{1,2}),range(1,5)):
            walks=paths(adjacent,0,goals,deadline,False)
            if not walks:continue
            optimum=min(p[1] for p in walks)
            anchors=[p for p in paths(adjacent,0,goals,deadline,True) if p[1]==optimum]
            for anchor in anchors:
                _,_,route,chosen=anchor;selected=set(chosen)
                gaps=[min((p[1]-optimum for p in walks if v in p[2]),default=None)
                      for v in range(3)]
                floor=min((p[1]-optimum for p in walks if any(e not in selected for e in p[3])),default=None)
                counts['anchor_certificates']+=1
                tau=0
                for cursor,x in enumerate(route):
                    suffix=chosen[cursor:]
                    suffix_clock=sum(adjacent[u][i][1] for u,i in suffix)
                    old_cost=sum(adjacent[u][i][2] for u,i in suffix)
                    for budget in range(suffix_clock,deadline-tau+1):
                        competitors=paths(adjacent,x,goals,budget,True)
                        for revisions in product((-1,0,1),repeat=len(locations)):
                            red=[0]*3;delta=dict(zip(locations,revisions))
                            for (u,i),change in delta.items():
                                v=adjacent[u][i][0];red[v]=max(red[v],-change)
                            shift=sum(delta[e] for e in suffix)
                            counts['transport_guards']+=1
                            if prefix(gaps,red,shift,floor):
                                current=min(p[1]+sum(delta[e] for e in p[3]) for p in competitors)
                                assert current==old_cost+shift,(adjacent,goals,deadline,anchor,budget,delta)
                                counts['accepted_transport_guards']+=1
                    if cursor<len(chosen):
                        u,i=chosen[cursor];tau+=adjacent[u][i][1]
        if counts['weighted_graphs']%81==0:
            print(json.dumps(dict(stage='walk-enumeration',**counts)),flush=True)
    return dict(counts)

def native_domain():
    counts=Counter()
    methods=('transport_sparse','contracted_certificate','landmark_certificate','expanded_dstar_lite')
    arcs=[(u,v) for u in range(3) for v in range(3) if u!=v]
    # All 64 directed topologies. Costs near INT32_MAX exercise 64-bit path
    # sums; duplicate patches, rollbacks, off-anchor sources and clock resets.
    for mask in range(64):
        adjacent=[[] for _ in range(3)]
        for e,(u,v) in enumerate(arcs):
            if mask>>e&1:adjacent[u].append([v,1+(u+v)%2,2_147_483_640-e])
        for goals in ([2],[1,2]):
            fixed=FixedModel(dict(adjacent=adjacent,start=0,goals=goals,deadline=5))
            costs=fixed.initial_cost.copy()
            solvers={m:native_solver(fixed,m) for m in methods}
            try:
                for start,budget,phase in product(range(3),range(6),range(3)):
                    if phase==0:
                        edges=np.arange(fixed.m,dtype=np.uint32)
                        values=np.ones(fixed.m,np.int64)
                    elif phase==1:
                        # Duplicate ids have sequential, last-write-wins semantics.
                        edges=np.repeat(np.arange(fixed.m,dtype=np.uint32),2)
                        values=np.tile(np.array([3,2_147_483_646],np.int64),fixed.m)
                    else:
                        edges=np.arange(fixed.m,dtype=np.uint32)
                        values=fixed.initial_cost.copy()
                    costs[edges]=values
                    current=fixed.updated_model(costs);current.update(start=start,deadline=budget)
                    exact=enumerated_optimum(current)
                    for method,s in solvers.items():
                        status=s.update(start,budget,edges,values)
                        verify_result(current,s.result(),exact)
                        counts['native_query_outputs']+=1
                        counts['native_accepts']+=status==1
                    counts['distinct_revision_queries']+=1
            finally:
                for s in solvers.values():s.close()
    return dict(counts)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();stamp=time.time()
    result=dict(prefix_subset_cases=prefix_equivalence(),mathematics=mathematical_domain(),native=native_domain(),
        scope='Complete stated finite domains only; positive costs, unique directed arcs, stop at first goal; no speed inference',
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.time()-stamp)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
