"""Rebuild either recorded author adapter from its receipt and pinned parent.

Reads locally fetched upstream sources; bundles or downloads no upstream code.
Fails closed on any adapted-source or bridge mismatch.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--receipt',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();record=json.loads(args.receipt.read_text())
    if args.out.exists():raise FileExistsError('output must be new')
    if sha(args.source/'src/search/core_algs.h')!=record['parent']['core_sha256']:
        raise ValueError('positive-cost parent mismatch')
    shutil.copytree(args.source/'src',args.out/'src',ignore=shutil.ignore_patterns('*.o','*.d','bin','lib'))
    for change in record['changes']:
        p=args.out/'src'/change['path'];value=p.read_text()
        if value.count(change['before'])!=1:raise ValueError(f"patch mismatch: {change['path']}")
        p.write_text(value.replace(change['before'],change['after']))
    for path,digest in record['author_sources'].items():
        if sha(args.out/'src'/path)!=digest:raise ValueError(f'author source mismatch: {path}')
    bridge=Path(__file__).with_name('query_author_bridge.cpp').read_text()
    if hashlib.sha256(bridge.encode()).hexdigest()!=record['adapter_sha256']:
        bridge=bridge.replace('using Queue = pqueue_label_hybrid_cyclic_fixed_min_wo_tie;',
                              'using Queue = pqueue_label_heap<search_label_pri>;')
    if hashlib.sha256(bridge.encode()).hexdigest()!=record['adapter_sha256']:
        raise ValueError('bridge mismatch')
    adapter=args.out/'query_author_bridge.cpp';adapter.write_text(bridge)
    src=args.out/'src';out=args.out/'author.so'
    command=['g++','-std=c++11','-O3','-DNDEBUG','-DPATH','-shared','-fPIC','-pthread','-fopenmp',
             '-Wall','-Wextra','-Wno-unused-parameter',str(adapter),str(src/'util/pqueue.cpp'),'-o',str(out)]
    command+=['-I'+str(src/p) for p in ('','sys','search','domains','util','heuristics')]
    result=subprocess.run(command,capture_output=True,text=True)
    (args.out/'build.log').write_text(result.stdout+result.stderr);result.check_returncode()
    report=dict(all_adapted_source_hashes_match=True,bridge_hash_matches=True,
        binary_sha256=sha(out),recorded_binary_sha256=record['binary_sha256'],
        binary_matches=sha(out)==record['binary_sha256'],
        compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0])
    (args.out/'reproduction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

if __name__=='__main__':main()
