"""Typed-bridge rerun; algorithm, workload and inference rules are unchanged."""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.query_research import frozen_hashes as previous_hashes,METHODS
from eval.contract_research import solver as base_solver
from eval.transport_research import analyze as stream_analysis
from mcu.landmark import LandmarkSolver
from mcu.fused_safe import FusedSolver


def frozen_hashes():
    root=Path(__file__).resolve().parents[1]
    paths=("firmware/deadline_fused_safe.c","mcu/fused_safe.py","eval/query_safe_research.py",
           "tests/test_fused_safe.py")
    return dict(previous_hashes(),**{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths})


def solver(fixed,method="transport_sparse",*,memory_bytes=64*1024*1024):
    if method=="landmark_certificate":
        return FusedSolver(LandmarkSolver(fixed,memory_bytes=memory_bytes),"landmark")
    base=base_solver(fixed,method,memory_bytes=memory_bytes)
    kinds={"transport_sparse":"transport","contracted_certificate":"contract",
           "sparse_incremental_dp":"dp","expanded_dstar_lite":"dynamic"}
    return FusedSolver(base,kinds[method]) if method in kinds else base


def main():
    experiment.METHODS=METHODS;experiment.TransportSolver=solver
    experiment.hashes=frozen_hashes;experiment.analyze=stream_analysis;experiment.main()


if __name__=="__main__":
    main()
