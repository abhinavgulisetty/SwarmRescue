"""Supplementary authors' NWRCA* check against saved fresh-map certificates."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from eval.constrained_benchmark import make_case
from eval.paper_evidence import independently_encode
from eval.reference_constrained import reference_call
from eval.routing_certificates import read_json, require, verify_table


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--build-manifest", type=Path, required=True)
    parser.add_argument("--certificates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = read_json(args.build_manifest)
    binary = args.binary.resolve()
    require(
        hashlib.sha256(binary.read_bytes()).hexdigest() == manifest["binary_sha256"],
        "reference binary hash",
    )
    report = read_json(args.certificates)
    rows = []
    for cert in report["certificates"]:
        case = make_case(cert["seed"], cert["family"])
        require(independently_encode(case) == cert["model"], "regenerated model")
        optimum = verify_table(cert["model"], cert["values"])
        result = reference_call(binary, case)
        result["correct"] = (
            result["status"] == "ok"
            and result["feasible"] == (optimum is not None)
            and (optimum is None or result["cost_q16"] == optimum)
        )
        rows.append(
            dict(
                seed=cert["seed"],
                family=cert["family"],
                optimum_q16=optimum,
                result=result,
            )
        )
    output = dict(
        supplementary_posthoc=True,
        build=manifest,
        scope=(
            "Author init plus search; parsing/IPC excluded; memory unbounded. "
            "No matched-memory or universal speed claim."
        ),
        rows=rows,
        correct=sum(x["result"]["correct"] for x in rows),
        total=len(rows),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(f"Published reference correct {output['correct']}/{output['total']}")


if __name__ == "__main__":
    main()
