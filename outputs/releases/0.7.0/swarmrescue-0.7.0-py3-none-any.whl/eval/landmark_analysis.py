"""Explicit landmark candidate mapping for the frozen paired analysis."""
import argparse
import json
from pathlib import Path
from eval.contract_analysis import adapted as contract_adapted
from eval.transport_analysis import analyze,load


def adapted(studies):
    rename=lambda name: "contracted_certificate" if name=="landmark_certificate" else (
        "goal_clock_transport" if name=="contracted_certificate" else name)
    mapped=[dict(study,design=dict(study["design"],methods=[rename(m) for m in study["design"]["methods"]]),
        rows=[dict(row,runs=[{rename(k):v for k,v in run.items()} for run in row["runs"]])
              for row in study["rows"]]) for study in studies]
    return contract_adapted(mapped)


def one(rows,methods):
    return analyze(adapted([dict(design=dict(methods=methods),rows=rows)]))


def main():
    ap=argparse.ArgumentParser();ap.add_argument("inputs",nargs="+",type=Path)
    ap.add_argument("--output",required=True,type=Path);args=ap.parse_args()
    studies=[load(p) for p in args.inputs];data=adapted(studies)
    out=dict(candidate="landmark_certificate",primary=analyze(data),by_kind={},by_rate={})
    for kind in studies[0]["design"]["kinds"]:
        out["by_kind"][kind]=analyze(data,lambda r:r["kind"]==kind)
    for rate in studies[0]["design"]["rates"]:
        out["by_rate"][str(rate)]=analyze(data,lambda r:r["rate"]==rate)
    out["output_records_checked"]=sum(len(run[m]["results"]) for s in studies for row in s["rows"]
        for run in row["runs"] for m in s["design"]["methods"])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out["primary"]),flush=True)


if __name__=="__main__":
    main()
