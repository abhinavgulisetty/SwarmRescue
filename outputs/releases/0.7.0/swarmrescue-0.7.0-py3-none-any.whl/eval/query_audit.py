"""Independent all-query audit for the typed-interface confirmation."""
import hashlib
import json
import sys
from pathlib import Path
import eval.transport_audit as audit
from eval.query_safe_research import frozen_hashes
from eval.contract_oracle import solve


def main():
    audit.hashes=frozen_hashes;audit.bellman_table=solve
    audit.verify_table=lambda model,value:value
    audit.main()
    output=Path(sys.argv[sys.argv.index("--output")+1])
    receipt=json.loads(output.read_text());receipt.pop("bellman_equalities")
    receipt["independent_oracle"]="Python arbitrary-integer constrained A* / Pareto labels; no native planner calls"
    receipt["oracle_source_sha256"]=hashlib.sha256(Path(__file__).with_name("contract_oracle.py").read_bytes()).hexdigest()
    receipt["audit_wrapper_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    output.write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt),flush=True)


if __name__=="__main__":
    main()
