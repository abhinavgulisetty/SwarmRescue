"""Paired whole-session/whole-seed analysis of locked transport studies."""
from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path

import numpy as np


def load(path):
    with gzip.open(path, "rt") as stream:
        return json.load(stream)


def analyze(studies, selector=lambda row: True):
    design = studies[0]["design"]
    if any(s["design"] != design for s in studies):
        raise ValueError("different protocols")
    methods = design["methods"]
    chosen = [[r for r in s["rows"] if r["initial"]["feasible"] and r["frames"] and selector(r)]
              for s in studies]
    keys = lambda rows: [(r["seed"], r["family"], r["kind"], r["rate"]) for r in rows]
    if any(keys(r) != keys(chosen[0]) for r in chosen):
        raise ValueError("unpaired sessions")
    seeds = sorted({r["seed"] for r in chosen[0]})
    out = dict(feasible_traces=len(chosen[0]),seed_blocks=len(seeds),sessions=len(studies),
               comparisons={})
    if not seeds:
        return out
    counts = np.array([sum(r["seed"]==seed for r in chosen[0]) for seed in seeds])
    rng = np.random.default_rng(971412)
    seed_draw = rng.integers(len(seeds),size=(30000,len(seeds)))
    session_draw = rng.integers(len(studies),size=(30000,len(studies)))
    alpha = .05/(len(methods)-1)
    for method in methods:
        if method == "transport_sparse":
            continue
        logs = np.array([[math.log(np.median([run[method]["total_ns"] for run in r["runs"]]) /
                                  np.median([run["transport_sparse"]["total_ns"] for run in r["runs"]]))
                          for r in rows] for rows in chosen])
        sums = np.array([[sum(v for v,r in zip(values,rows,strict=True) if r["seed"]==seed)
                          for seed in seeds] for values,rows in zip(logs,chosen,strict=True)])
        bootstrap = np.exp(sums[session_draw[:,:,None],seed_draw[:,None,:]].sum((1,2)) /
                           (len(studies)*counts[seed_draw].sum(1)))
        interval = np.quantile(bootstrap,[alpha/2,1-alpha/2]).tolist()
        out["comparisons"][method] = dict(ratio=math.exp(float(logs.mean())),
            simultaneous_95_interval=interval, interval_above_one=interval[0]>1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+",type=Path)
    ap.add_argument("--output",required=True,type=Path)
    args = ap.parse_args()
    studies = [load(p) for p in args.inputs]
    summary = dict(primary=analyze(studies),by_kind={},by_rate={})
    for kind in studies[0]["design"]["kinds"]:
        summary["by_kind"][kind] = analyze(studies,lambda r:r["kind"]==kind)
    for rate in studies[0]["design"]["rates"]:
        summary["by_rate"][str(rate)] = analyze(studies,lambda r:r["rate"]==rate)
    summary["output_records_checked"] = sum(len(run[m]["results"]) for s in studies
        for r in s["rows"] for run in r["runs"] for m in s["design"]["methods"])
    summary["inputs"] = list(map(str,args.inputs))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary["primary"]),flush=True)


if __name__ == "__main__":
    main()
