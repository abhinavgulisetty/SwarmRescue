"""Post-hoc public geometry check; hazards and update processes are authored."""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

from eval.event_public import public_case
from eval.retention_research import (
    METHODS,
    STREAMS,
    StreamSolver,
    benchmark_stream,
    hashes,
)
from eval.routing_certificates import read_json, require, write_json
from mcu.retention import FixedModel


def main():
    folder = Path("docs/paper/event/public-maps")
    before = hashes()
    warm = FixedModel(dict(adjacent=[[[1, 1, 4]], []], start=0, goals=[1], deadline=3))
    for method in METHODS:
        solver = StreamSolver(warm, method, 64 * 1024 * 1024)
        solver.step()
        solver.close()
    manifest = read_json(folder / "manifest.json")
    rows = []
    for entry in manifest:
        path = folder / entry["name"]
        require(
            hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"],
            "public map digest",
        )
        seed = 153000
        case = public_case(path, seed)
        for kind in STREAMS:
            rows.append(
                benchmark_stream(
                    case, seed, entry["name"], kind, 64, 3, 64 * 1024 * 1024, 0
                )
            )
        print(f"Public streams {entry['name']}", flush=True)
    require(before == hashes(), "source changed")
    summary = {}
    feasible = [r for r in rows if r["optima_q16"][0] is not None]
    for kind in ("all_feasible", *STREAMS):
        selected = [
            r for r in feasible if kind == "all_feasible" or r["stream_kind"] == kind
        ]
        summary[kind] = (
            {
                method: float(
                    np.exp(
                        np.mean(
                            [
                                np.log(
                                    r["results"][method]["median_total_ms"]
                                    / r["results"]["prefix_certificate"][
                                        "median_total_ms"
                                    ]
                                )
                                for r in selected
                            ]
                        )
                    )
                )
                for method in METHODS
            }
            if selected
            else {}
        )
    write_json(
        Path("docs/paper/retention/public-geometry.json.gz"),
        dict(
            supplementary_posthoc=True,
            seeds=[153000],
            map_manifest=manifest,
            source_sha256=before,
            feasible_streams=len(feasible),
            total_streams=len(rows),
            description=(
                "Public MovingAI geometry; four-neighbor movement and authored "
                "hazards/endpoints/updates, not original benchmark tasks."
            ),
            timing="Setup-inclusive stream timing; one session; no registered CI.",
            summary=summary,
            rows=rows,
        ),
    )
    print(summary)


if __name__ == "__main__":
    main()
