"""Export further-verification evidence without replacing previous studies."""
from __future__ import annotations
import ast
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
EVIDENCE=ROOT/'outputs/query-verification'
DEST=ROOT/'docs/paper/query-verification'
LABELS={'sparse_incremental_dp':'Sparse incremental DP','sparse_event':'Sparse event solver',
        'sparse_hybrid':'Sparse hybrid solver','author_nwrca':'Adapted author NWRCA* (hybrid)',
        'author_heap_control':'Author search with heap (sensitivity control)'}

def read(name):return json.loads((EVIDENCE/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def dependency_closure(paths):
    found=set(paths);pending=list(paths)
    def add(path):
        if path.is_file():
            name=str(path.relative_to(ROOT))
            if name not in found:found.add(name);pending.append(name)
    def module(name):
        if not name:return
        parts=name.split('.')
        add(ROOT/Path(*parts).with_suffix('.py'))
        add(ROOT/Path(*parts)/'__init__.py')
        for n in range(1,len(parts)):add(ROOT/Path(*parts[:n])/'__init__.py')
    while pending:
        path=pending.pop()
        if not path.endswith('.py'):continue
        for node in ast.walk(ast.parse((ROOT/path).read_text())):
            if isinstance(node,ast.Import):
                for alias in node.names:module(alias.name)
            elif isinstance(node,ast.ImportFrom):
                if node.level:
                    package=list(Path(path).parent.parts)
                    package=package[:len(package)-node.level+1]
                    name='.'.join(package+([node.module] if node.module else []))
                else:name=node.module or ''
                module(name)
                for alias in node.names:module(name+'.'+alias.name if name else alias.name)
    return sorted(found)

def table(section):
    lines=['| Comparator | Comparator / TSC | Joint 95% interval | Geometric-mean direction |',
           '| --- | ---: | --- | --- |']
    for method,item in section['comparisons'].items():
        low,high=item['simultaneous_95_interval']
        verdict='TSC faster' if low>1 else 'Comparator faster' if high<1 else 'Inconclusive'
        lines.append(f'| {LABELS[method]} | {item["ratio"]:.3f}x | [{low:.3f}, {high:.3f}] | {verdict} |')
    return '\n'.join(lines)

def timing_csv(inputs,path):
    columns=['seed','family','kind','rate','session','method','included_in_speed',
        'nodes','arcs','initial_deadline','update_queries','patched_arcs','maximum_patch_size',
        'median_total_ns','repeat0_ns','repeat1_ns','repeat2_ns',
        'repeat0_position','repeat1_position','repeat2_position','retained_updates']
    with path.open('w',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=columns);writer.writeheader()
        for filename in inputs:
            with gzip.open(filename,'rt') as stream:study=json.load(stream)
            for row in study['rows']:
                frames=row['frames'];model=row['model']
                for method in study['design']['methods']:
                    times=[run[method]['total_ns'] for run in row['runs']]
                    item={key:row[key] for key in ('seed','family','kind','rate')}
                    item.update(session=study['session'],method=method,
                        included_in_speed=bool(row['initial']['feasible'] and frames),
                        nodes=len(model['adjacent']),arcs=sum(map(len,model['adjacent'])),
                        initial_deadline=model['deadline'],update_queries=len(frames),
                        patched_arcs=sum(len(f['edges']) for f in frames),
                        maximum_patch_size=max((len(f['edges']) for f in frames),default=0),
                        median_total_ns=int(np.median(times)),
                        retained_updates=sum(s==1 for s in row['runs'][0][method]['statuses']))
                    for repeat,run in enumerate(row['runs']):
                        item[f'repeat{repeat}_ns']=times[repeat]
                        item[f'repeat{repeat}_position']=list(run).index(method)
                    writer.writerow(item)
            del study

def diagnostics(path):
    grouped={}
    with path.open(newline='') as stream:
        for row in csv.DictReader(stream):
            if row['included_in_speed']!='True':continue
            key=tuple(row[k] for k in ('seed','family','kind','rate','session'))
            grouped.setdefault(key,{})[row['method']]=int(row['median_total_ns'])
    base=np.array([r['transport_sparse'] for r in grouped.values()],float)
    output=dict(scope='Descriptive only; same eligible traces; each stream/session uses its median repeat. No additional superiority inference.',comparisons={})
    for method in LABELS:
        other=np.array([r[method] for r in grouped.values()],float)
        output['comparisons'][method]=dict(ratio_of_summed_solver_times=float(other.sum()/base.sum()),
            tsc_summed_ms=float(base.sum()/1e6),comparator_summed_ms=float(other.sum()/1e6),
            fraction_of_stream_sessions_tsc_faster=float((other>base).mean()),
            ratio_quantiles_min_p05_median_p95_max=np.quantile(other/base,[0,.05,.5,.95,1]).tolist())
    return output

def figure(summary,operations):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,(ax,cx,bx)=plt.subplots(1,3,figsize=(15,4.7),gridspec_kw={'width_ratios':[1.1,1,1.15]},layout='constrained')
    methods=list(summary['primary']['comparisons'])
    short=['Sparse DP','Sparse event','Sparse hybrid','Hybrid queue','Heap control']
    for i,m in enumerate(methods):
        target=ax if i<3 else cx
        row=i if i<3 else i-3
        for j,(key,label,color,marker) in enumerate(((None,'Mixture','#244b70','o'),
                ('background','Background','#348759','s'),('mixed','Mixed','#bd6633','^'))):
            item=(summary['primary'] if key is None else summary['by_kind'][key])['comparisons'][m]
            ratio=item['ratio'];lo,hi=item['simultaneous_95_interval']
            target.errorbar(ratio,row+(j-1)*.2,xerr=[[ratio-lo],[hi-ratio]],fmt=marker,color=color,
                        capsize=3,label=label if i==0 else None,markersize=4)
    for target in (ax,cx):
        target.axvline(1,color='#555',linestyle='--',linewidth=1)
        target.invert_yaxis();target.grid(axis='x',alpha=.2)
    ax.set_yticks(range(3),short[:3]);cx.set_yticks(range(2),short[3:])
    cx.set_xscale('log')
    ax.set_xlabel('Comparator / TSC time');cx.set_xlabel('Comparator / TSC time (log scale)')
    ax.set_title('Project kernels: geometric ratios',fontsize=11)
    cx.set_title('Adapted author: geometric ratios',fontsize=11)
    ax.legend(fontsize=8,loc='best')
    rows=operations['records'];n=[r['nodes'] for r in rows]
    bx.plot(n,[r['maximum_tree_visits'] for r in rows],'o-',label='Tree calls')
    bx.plot(n,[r['maximum_decrease_calls'] for r in rows],'s-',label='Incoming-decrease reads')
    bx.set_xscale('log',base=2);bx.set_xlabel('Vertices; two patched arcs per accepted update')
    bx.set_ylabel('Maximum instrumented calls per update')
    bx.set_title('Mechanism check on a declared graph family',fontsize=10)
    bx.grid(alpha=.2);bx.legend(fontsize=8)
    fig.suptitle('Geometric stream ratios (15 joint intervals) and an accepted-update mechanism check',fontsize=12)
    for suffix in ('svg','pdf','png'):fig.savefig(DEST/f'verification.{suffix}',dpi=180)
    plt.close(fig)

def main():
    summary=read('summary.json');audit=read('independent-audit.json');valid=read('validation.json')
    exhaustive=read('exhaustive-tradeoff.json');operation=read('operation-counts.json')
    public_audit=read('public-audit.json')
    # Validate the counts against actual successful executable output.
    assert int(re.search(r'Checked (\d+) dynamic solver decisions',(EVIDENCE/'candidate-sanitizer.log').read_text())[1])==valid['candidate_sanitizer_decisions']
    assert int(re.search(r'checked_author_queries=(\d+)',(EVIDENCE/'author-sanitizer.log').read_text())[1])==valid['author_sanitizer_queries']
    assert valid['test_failures']==valid['test_skips']==valid['sanitizer_findings']==0
    assert all(v['all_adapted_source_hashes_match'] and v['bridge_hash_matches'] for v in valid['author_rebuilds'].values())
    protocol=json.loads((ROOT/'eval/query_confirmation_hybrid_protocol.json').read_text())
    assert audit['sources_match']
    for path,digest in protocol['sources'].items():assert sha(ROOT/path)==digest,path
    DEST.mkdir(exist_ok=True,parents=True)
    copies={'summary.json':'summary.json','independent-audit.json':'independent-audit.json',
        'validation.json':'validation.json','exhaustive-tradeoff.json':'exhaustive.json',
        'separation.json':'separation.json','operation-counts.json':'operation-counts.json',
        'public.json.gz':'public.json.gz','public-audit.json':'public-audit.json',
        'hybrid-failure.json':'initial-hybrid-adapter-failure.json',
        'tests.xml':'tests.xml','candidate-sanitizer.log':'candidate-sanitizer.log',
        'author-sanitizer.log':'author-sanitizer.log','host.json':'host.json',
        'exhaustive-profile.json':'exhaustive-profile.json',
        'transport-witness.json':'transport-witness.json'}
    for src,dst in copies.items():shutil.copy2(EVIDENCE/src,DEST/dst)
    for session in range(3):shutil.copy2(ROOT/f'outputs/query-confirmation/session{session}.json.gz',DEST/f'session{session}.json.gz')
    timing_csv([DEST/f'session{s}.json.gz' for s in range(3)],DEST/'timings.csv')
    timing_csv([DEST/'public.json.gz'],DEST/'public-timings.csv')
    descriptive=diagnostics(DEST/'timings.csv')
    (DEST/'descriptive-times.json').write_text(json.dumps(descriptive,indent=2)+'\n')
    shutil.copy2(ROOT/'eval/query_confirmation_hybrid_protocol.json',DEST/'protocol.json')
    shutil.copy2(ROOT/'eval/query_public_verification_protocol.json',DEST/'public-protocol.json')
    for version,name in ((6,'hybrid'),(4,'heap')):
        shutil.copy2(ROOT/f'outputs/algorithm-research/reference-query-inprocess-v{version}/receipt.json',DEST/f'author-{name}-receipt.json')
    shutil.copy2(ROOT/'outputs/query-confirmation-aborted-heap/ABORT.json',DEST/'aborted-first-attempt.json')
    for src,dst in (('protocol.json','aborted-heap-protocol.json'),
                    ('session0.json.gz','aborted-heap-partial-session0.json.gz'),
                    ('source-at-abort.tar.gz','aborted-heap-source.tar.gz')):
        shutil.copy2(ROOT/'outputs/query-confirmation-aborted-heap'/src,DEST/dst)
    shutil.copy2(ROOT/'outputs/algorithm-research/reference-transport-positive/ember-build.json',DEST/'positive-author-parent.json')
    shutil.copy2(ROOT/'docs/paper/query/original-author-failure.json',DEST/'original-author-failure.json')
    proof=(ROOT/'docs/query-proof-audit.md').read_text().replace('](transport-routing-research.md)','](../../transport-routing-research.md)').replace('](../eval/','](../../../eval/')
    (DEST/'proof-audit.md').write_text(proof)
    (DEST/'AUTHOR-PROVENANCE.md').write_text('Author sources: https://bitbucket.org/s-ahmadi/multiobj\n\n'
        'Pinned revision: 4098543d0c5d78afc977017b5abf6054671a8c43.\n\n'
        'The upstream README identifies AGPL-3.0. Upstream source and compiled libraries are omitted from this package. '
        'Each receipt contains every mechanical source adaptation, source hashes, compiler and binary hash. '
        'The recommended hybrid queue uses an inclusive range constructor; the heap variant is explicitly a sensitivity control. '
        'The initial adapter boundary counterexample is preserved and passed by the final adapter.\n')
    primary=summary['primary'];math=exhaustive['mathematics']
    totals=['| Method | Sum of median solver times (s) | Comparator / TSC sum |',
            '| --- | ---: | ---: |',
            f'| TSC | {descriptive["comparisons"]["sparse_event"]["tsc_summed_ms"]/1000:.3f} | 1.000 |']
    for method,item in descriptive['comparisons'].items():
        totals.append(f'| {LABELS[method]} | {item["comparator_summed_ms"]/1000:.3f} | {item["ratio_of_summed_solver_times"]:.3f} |')
    total_table='\n'.join(totals)
    profile=read('exhaustive-profile.json')
    report=f'''# Further verification of transported certificates

Verification materially narrows both novelty and speed claims. The sorted-prefix stability construction is established prior work. TSC wins the planned geometric-average comparison, but uses more summed solver time than the three project controls on the same eligible traces. A broad superiority or wholly novel algorithm claim is unsupported. See [proof and priority assessment](proof-audit.md), including the direct mathematical mapping. Transport and sparse maintenance remain a narrower contribution hypothesis, not verified historical priority.

## Locked independent confirmation

This separate cohort declares 32 previously unused seeds, six graph families, both update processes, two sensing rates, three repeats and three sequential process sessions. There are {audit['completeness']['expected_traces']:,} traces, {primary['feasible_traces']:,} informative feasible traces and {primary['seed_blocks']} seed blocks. No candidate algorithm changed. The incomplete first heap-only attempt was stopped for author queue fidelity before speed estimates were inspected; its raw evidence remains in outputs/query-confirmation-aborted-heap. The final cohort uses different seeds.

{table(primary)}

Ratios above one favor TSC. These are geometric whole-stream ratios of median repeat times. All 15 intervals below and above are jointly Bonferroni-corrected: five comparators across the primary mixture and two predefined processes. The bootstrap uses 100,000 whole-seed/whole-session resamples. Secondary process results do not replace the mixture.

### Absolute-time diagnostic

{total_table}

These are descriptive sums of per-stream median repeat times over the eligible traces and three sessions, not the entire benchmark's wall time. They do not replace the locked primary statistic. TSC uses **{(1/descriptive['comparisons']['sparse_event']['ratio_of_summed_solver_times']-1)*100:.1f}% more solver time** than sparse event over this batch. Large-grid point ratios also favor the project comparators; the mixed large-grid event/TSC geometric ratio is {summary['by_kind']['mixed']['comparisons']['sparse_event']['per_family_point_ratios']['large_grid']:.3f}. This prevents interpreting the geometric-average win as lower total processing cost. [Every repeat and method order](timings.csv), [descriptive distributions](descriptive-times.json) and [claim ledger](claims.json) are included.

### Background updates

{table(summary['by_kind']['background'])}

### Mixed updates

{table(summary['by_kind']['mixed'])}

![Geometric stream ratios and operation counts](verification.svg)

## Correctness and mechanism evidence

- Independent arbitrary-integer Pareto/A* replay: **{audit['output_records']:,} output records**, **{audit['unique_queries']:,} distinct queries**; all exact values and route witnesses match. Repeated records are not independent samples.
- Complete declared finite tradeoff domain: **{math['transport_guards']:,} guards**, **{math['accepted_transport_guards']:,} acceptances**, no false acceptance. Bounds use walk enumeration; optima use simple-path enumeration.
- Non-vacuity: **{profile['counts']['unsafe_incumbents']:,}** incumbent routes are actually nonoptimal after perturbation, and **{profile['counts']['accepted_with_distinct_competitors']:,}** accepted guards have distinct feasible competitors. Deliberately omitting the incumbent shift or incoming decreases produces **{profile['counts']['unsafe_if_shift_omitted']:,}** and **{profile['counts']['unsafe_if_decreases_omitted']:,}** detected unsafe acceptances. An additional **{profile['tied_gap_subset_cases']:,}** tied-gap subset systems agree.
- **{exhaustive['prefix_subset_cases']:,}** prefix/subset equivalence cases and **{exhaustive['native']['native_query_outputs']:,}** native boundary outputs pass.
- **{valid['targeted_tests_passed']} tests**, **{valid['candidate_sanitizer_decisions']:,} candidate sanitizer decisions**, and **{valid['author_sanitizer_queries']:,} author sanitizer queries** pass, including leak checks.
- Instrumented copies measure **{operation['accepted_updates']} accepted updates** over 16–65,536 vertices and verify retained numeric memory is unchanged across deadlines 2, 16, 256 and 4,096 on the declared graph family. These counts support the implementation mechanism; they do not prove universal elapsed-time dominance or deadline-independent construction memory.
- The initialization admission check is deadline-dependent: at 1,024 nodes and deadline 4,096, the 64 MiB cap rejects setup even though this graph's cheapest direct route is feasible. The retained-memory demonstration uses 512 nodes; it does not imply arbitrary deadlines fit the cap.
- Exact transport witnesses show both the benefit after past-cost increases and a counterexample to unconditional acceptance-region dominance over checking the whole anchor. Both are saved in [transport-witness.json](transport-witness.json).
- A separate fresh replay on four public MovingAI geometries independently checks **{public_audit['output_records']:,} records** over **{public_audit['unique_queries']:,} distinct queries**. Movement, endpoints, hazards and update traces are authored adaptations, not original benchmark tasks or measured rescue data. Its timings are descriptive, with no confirmatory superiority claim.

## Comparison scope and remaining gaps

Shared topology/patch generation, compilation and verification are outside timing. Construction, public validation, sparse patch ingestion, route output and public close calls are timed. Python object destruction after close is not fully timed. Sparse DP retains generic once-per-stream metadata. Author graph conversion and per-query initialization/search/cleanup are timed in process; there is no subprocess/file-I/O penalty. The author control uses positive costs, int64 objective arithmetic, explicit budgets, fixed terminal-goal semantics and documented ownership/queue setup corrections. It has no 64 MiB enforced cap, while project kernels do. The author's README discourages heap benchmarking, so that configuration is labeled as our queue sensitivity control.

This is one shared host and authored workloads. A win against this adapted author implementation is not a win against every published method or a measured MCU result. Modern dynamic-label comparisons, operational traces and an expert novelty assessment of the transport/maintenance combination remain unresolved. The core prefix rule must be attributed to Kılınç-Karzan et al. (ORL 2009, author manuscript Theorem 2.3). The revised [working manuscript](manuscript.md) retains this limitation.

## Reproduction and integrity

Use parent checkout 4e0a1196654f86e15562a0567d82ee9288ba7ade and overlay research-source.tar.gz. The archive includes our code and adapters, and omits upstream author sources and compiled libraries. Fetch/build the pinned author parent using eval/build_constrained_reference.py and eval/transport_author_build.py; author-*-receipt.json and eval/query_author_reproduce.py reproduce the two isolated adapters. Binary/source reproduction receipts are in validation.json. A different compiler may produce different binary hashes and needs a new local source lock; do not silently alter the archived protocol.

```bash
for session in 0 1 2; do
  .venv/bin/python -m eval.query_confirmation --protocol eval/query_confirmation_hybrid_protocol.json --seeds 195000:195031 --families grid,rooms,dense,deadends,tradeoff,large_grid --rates 1,4 --limit 96 --repeats 3 --sessions 3 --session "$session" --output "outputs/query-confirmation/session${{session}}.json.gz"
done
.venv/bin/python -m eval.query_confirmation_verify outputs/query-confirmation/session{{0,1,2}}.json.gz --output outputs/query-verification/independent-audit.json
.venv/bin/python -m eval.query_confirmation_analysis outputs/query-confirmation/session{{0,1,2}}.json.gz --output outputs/query-verification/summary.json
.venv/bin/python -m eval.query_exhaustive --output outputs/query-verification/exhaustive-tradeoff.json
sha256sum -c SHA256SUMS
```

The source lock is local, not publicly timestamped preregistration. All losses, excluded initial infeasible cases and earlier studies remain preserved. Completeness checks reject missing seeds, traces, methods, repeats, sessions or output records.
'''
    (DEST/'README.md').write_text(report)
    manuscript=(ROOT/'docs/paper/query/manuscript.md').read_text()
    manuscript=manuscript.replace('Working research manuscript, 15 October 2026. Venue-neutral draft.',
        'Revised research manuscript, 15 October 2026. The prefix stability construction is inherited from [8]; historical novelty of transport/maintenance remains unresolved.')
    manuscript=manuscript.replace('We investigate a compact certificate','We investigate maintenance and suffix-query transport of known prefix stability bounds [8], using a compact certificate')
    manuscript=manuscript.replace('## 3. Sparse dynamic representation',
        'The zero-floor, zero-shift prefix construction is prior work [8, Theorem 2.3]. Its use here does not establish a novel sensitivity region.\n\n## 3. Sparse dynamic representation')
    start=manuscript.index('## 5. Related work and novelty boundaries')
    end=manuscript.index('## References')
    manuscript=manuscript[:start]+'''## 5. Related work and novelty boundary

The ordered stability-region construction is inherited from Kılınç-Karzan et al. [8], and cannot be claimed as a new algorithmic principle. Set tolerances [1,2], incremental planning [3,4], dynamic RCSP [5] and landmark bounds [7] are also established. The remaining hypothesis is a useful sparse implementation and suffix-query transport of those bounds. Its historical priority and significance need expert review. The [proof audit](proof-audit.md) includes an exact-region separation witness and the prior-art mapping.

## 6. Further verification

'''+report[report.index('## Locked independent confirmation'):report.index('## Reproduction and integrity')]+'''\n## References\n\n'''+manuscript[end+len('## References'):]
    manuscript+='\n8. F. Kılınç-Karzan, A. Toriello, S. Ahmed, G. Nemhauser and M. Savelsbergh, “Approximating the stability region for binary mixed-integer programs,” Operations Research Letters 37(4), 250–254, 2009. DOI: [10.1016/j.orl.2009.04.001](https://doi.org/10.1016/j.orl.2009.04.001). [Author manuscript](https://www2.isye.gatech.edu/~sahmed/bincover_final.pdf), Theorem 2.3.\n'
    manuscript=manuscript.replace('The revised [working manuscript](manuscript.md) retains this limitation.',
                                  'These limitations remain part of this draft.')
    left=manuscript.index('## Locked independent confirmation')
    right=manuscript.index('## References',left)
    manuscript=manuscript[:left]+re.sub(r'(?m)^(#{2,}) ',r'#\1 ',manuscript[left:right])+manuscript[right:]
    (DEST/'manuscript.md').write_text(manuscript)
    extra=['eval/query_confirmation_verify.py','eval/query_public_verification.py',
        'eval/query_public_verification_audit.py','eval/query_operation_counts.py','eval/query_separation.py',
        'eval/query_author_reproduce.py','eval/query_verify_finish.py','eval/query_verification_export.py',
        'eval/query_exhaustive_profile.py','eval/query_transport_witness.py',
        'eval/query_confirmation_hybrid_protocol.json','eval/query_public_verification_protocol.json',
        'eval/build_constrained_reference.py','eval/transport_author_build.py','eval/contract_oracle.py',
        'eval/transport_audit.py','eval/query_stress.c','eval/event_public.py','eval/event_research.py']
    extra+=['eval/retention_exhaustive.py','eval/retention_certificates.py',
        'tests/test_retention.py','tests/test_transport.py','tests/test_transport_controls.py',
        'tests/test_contract.py','tests/test_contract_oracle.py','tests/test_landmark.py',
        'tests/test_fused.py','tests/test_fused_safe.py','tests/test_query_author.py',
        'tests/test_query_confirmation.py']
    sources=dependency_closure({p for p in protocol['sources'] if not p.startswith('outputs/')}|set(extra))
    source_manifest={p:sha(ROOT/p) for p in sources}
    heap_bridge=(ROOT/'eval/query_author_bridge.cpp').read_text().replace(
        'using Queue = pqueue_label_hybrid_cyclic_fixed_min_wo_tie;',
        'using Queue = pqueue_label_heap<search_label_pri>;')
    assert hashlib.sha256(heap_bridge.encode()).hexdigest()==json.loads((DEST/'author-heap-receipt.json').read_text())['adapter_sha256']
    (DEST/'heap-bridge.cpp').write_text(heap_bridge)
    with tarfile.open(DEST/'research-source.tar.gz','w:gz') as archive:
        for p in sources:archive.add(ROOT/p,arcname=p)
    (DEST/'source-archive-manifest.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
    claims=dict(prefix_construction_novelty=dict(status='established prior work',
            source='https://www2.isye.gatech.edu/~sahmed/bincover_final.pdf',theorem='2.3'),
        transport_maintenance_historical_priority=dict(status='unresolved'),
        exact_outputs=dict(status='all checked outputs agree',records=audit['output_records'],
                           distinct_queries=audit['unique_queries'],evidence='independent-audit.json'),
        primary_speed_estimator='Geometric mean of paired per-stream median time ratios; complete solver calls',
        primary_speed={method:dict(status='TSC faster geometrically' if item['simultaneous_95_interval'][0]>1 else
            'comparator faster' if item['simultaneous_95_interval'][1]<1 else 'inconclusive',**item)
            for method,item in primary['comparisons'].items()},
        summed_solver_time_diagnostic=descriptive,
        universal_speed_dominance=dict(status='not established'),
        operational_rescue_and_mcu_improvement=dict(status='not measured'),
        worst_case_update_bound=dict(status='conditional on acceptance; no rebuild-count bound',
            formula='O(k log(1+Delta) + k log(1+V) + a + 1), excluding route output'))
    (DEST/'claims.json').write_text(json.dumps(claims,indent=2)+'\n')
    figure(summary,operation)
    sums=''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='SHA256SUMS')
    (DEST/'SHA256SUMS').write_text(sums)
    print(json.dumps(dict(package=str(DEST),files=len(sums.splitlines()),source_files=len(sources))),flush=True)

if __name__=='__main__':main()
