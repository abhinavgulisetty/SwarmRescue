"""Independent all-query replay, with contracted candidate counters."""
import hashlib
import json
import sys
from pathlib import Path
import eval.transport_audit as audit
from eval.contract_research import frozen_hashes
from eval.transport_analysis import load
from eval.contract_oracle import solve


def main():
    audit.hashes=frozen_hashes
    audit.bellman_table=solve
    audit.verify_table=lambda model,value:value
    audit.main()
    output=Path(sys.argv[sys.argv.index("--output")+1])
    receipt=json.loads(output.read_text())
    receipt["accepted_unfiltered_transport_records"]=receipt.pop("accepted_candidate_records")
    receipt.pop("bellman_equalities")
    receipt["independent_oracle"]="Python arbitrary-integer constrained A* with Pareto dominance; no native planner calls"
    receipt["oracle_source_sha256"]=hashlib.sha256(Path(__file__).with_name("contract_oracle.py").read_bytes()).hexdigest()
    inputs=list(receipt["inputs"])
    receipt["accepted_candidate_records"]=sum(
        status==1 for path in inputs for row in load(path)["rows"] for run in row["runs"]
        for status in run["contracted_certificate"]["statuses"])
    receipt["audit_wrapper_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    output.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt),flush=True)


if __name__=="__main__":
    main()
