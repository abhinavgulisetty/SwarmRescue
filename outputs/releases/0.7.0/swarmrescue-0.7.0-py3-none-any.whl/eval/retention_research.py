"""Exact fixed-query hazard-update streams; setup costs are included."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np

from eval.constrained_benchmark import make_case
from eval.paper_evidence import independently_encode
from eval.routing_certificates import (
    bellman_table,
    verify_result,
    verify_table,
    write_json,
)
from mcu.retention import BYTE, MODES, FixedModel, RetentionSolver, library, pointer

ROOT = Path(__file__).resolve().parents[1]
METHODS = (*MODES, "native_recompute", "event_recompute")
FAMILIES = ("grid", "tradeoff", "large_grid", "rooms")
STREAMS = ("background", "mixed")
SOURCES = (
    "firmware/deadline_retention.c",
    "mcu/retention.py",
    "eval/retention_certificates.py",
    "eval/retention_research.py",
    "eval/retention_analysis.py",
    "eval/paper_confirmation.py",
    "tests/test_retention.py",
    "firmware/deadline_exact.c",
    "firmware/deadline_exact.h",
    "firmware/deadline_event.c",
    "mcu/native_deadline.py",
    "mcu/event_deadline.py",
    "eval/constrained_benchmark.py",
    "eval/paper_evidence.py",
    "eval/routing_certificates.py",
)


def hashes():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SOURCES}


class StreamSolver:
    def __init__(self, fixed, method, budget):
        self.fixed, self.method = fixed, method
        self.native = method.endswith("recompute")
        self.handle = None
        if not self.native:
            self.handle = RetentionSolver(fixed, method, memory_bytes=budget)
            self.prepare(fixed.initial_cost)
            return
        if method == "native_recompute":
            from mcu.native_deadline import _library, _Stats

            symbol, mode = "ember_deadline_exact", 4
        else:
            from mcu.event_deadline import _library, _Stats

            symbol, mode = "ember_deadline_event", 0
        self.fn = getattr(_library(), symbol)
        self.stats_native = _Stats()
        self.native_peak = 0
        self.arena = np.empty(budget, np.uint8)
        self.route = np.empty(fixed.n, np.uint32)
        reverse_to = np.ascontiguousarray(fixed.from_nodes[fixed.reverse_edges])
        reverse_time = np.ascontiguousarray(fixed.duration[fixed.reverse_edges])
        self.reverse_arrays = reverse_to, reverse_time
        self.args = [
            fixed.n,
            pointer(fixed.rows),
            pointer(fixed.to),
            pointer(fixed.duration),
            None,
            pointer(fixed.reverse_rows),
            pointer(reverse_to),
            pointer(reverse_time),
            None,
            pointer(fixed.goals),
            fixed.start,
            fixed.deadline,
            4096,
            mode,
            self.arena.ctypes.data_as(BYTE),
            budget,
            0,
            pointer(self.route),
            ctypes.byref(self.stats_native),
        ]
        self.prepare(fixed.initial_cost)
        self.step()

    def prepare(self, cost):
        self.cost = cost
        self.cost_pointer = pointer(cost)
        if self.native:
            self.reverse_cost = np.ascontiguousarray(cost[self.fixed.reverse_edges])
            self.args[4], self.args[8] = self.cost_pointer, pointer(self.reverse_cost)

    def step(self):
        if self.native:
            status = self.fn(*self.args)
            if status < 0:
                raise RuntimeError("native exact comparator exceeded fixed host budget")
            self.native_peak = max(self.native_peak, int(self.stats_native.peak))
            return 3
        status = self.handle.lib.ember_retention_update(
            self.handle.handle, self.cost_pointer
        )
        if status < 0:
            raise RuntimeError("retention kernel failed")
        return status

    def result(self):
        if not self.native:
            return self.handle.result()
        stats = self.stats_native
        return dict(
            route=self.route[: stats.route_length].astype(int).tolist(),
            feasible=bool(stats.feasible),
            optimal=bool(stats.optimal),
            cost_q16=int(stats.cost) if stats.feasible else None,
            lower_bound_q16=int(stats.lower_bound) if stats.feasible else None,
        )

    def stats(self):
        if not self.native:
            return self.handle.stats()
        return dict(
            retained_numeric_bytes=0,
            peak_numeric_bytes=self.native_peak,
            reserved_arena_bytes=self.arena.nbytes,
            builds=0,
            retentions=0,
            recomputed_states=0,
        )

    def close(self):
        if self.handle:
            self.handle.close()

    def certificate(self, previous_fast=0):
        if not self.method.endswith("certificate"):
            return None
        return dict(
            gaps=self.handle.gaps(),
            alternative_floor=self.handle.alternative_floor(),
            fast=self.handle.stats()["fast_builds"] > previous_fast,
        )


def stream_costs(case, fixed, seed, kind, frames):
    risk = case[3].copy()
    # Model adjacency ordering differs from the undirected edge array: recover
    # each original length by endpoint identity, before generating any update.
    mapping = {
        tuple(sorted(map(int, edge))): float(length)
        for edge, length in zip(case[0].edges, case[0].edge_cost, strict=True)
    }
    lengths = np.array(
        [
            mapping[tuple(sorted((int(u), int(v))))]
            for u, v in zip(fixed.from_nodes, fixed.to, strict=True)
        ]
    )
    rng = np.random.default_rng(
        np.random.SeedSequence([seed, STREAMS.index(kind), 94137])
    )
    stream = []
    # Background sensing is spatially sampled everywhere; no route/gap is read.
    # Mixed streams have larger and bidirectional revisions, also everywhere.
    for _ in range(frames):
        count = min(fixed.n, 3 if kind == "background" else 8)
        changed = rng.choice(fixed.n, count, replace=False)
        factors = (
            rng.uniform(0.98, 1.02, count)
            if kind == "background"
            else rng.uniform(0.6, 1.4, count)
        )
        risk[changed] = np.maximum(0.0, risk[changed] * factors)
        cost = np.maximum(
            1, np.rint((lengths + risk[fixed.to] * fixed.duration) * 65536)
        ).astype(np.int64)
        if np.any(cost >= (1 << 31) - 1):
            raise ValueError("generated objective exceeds native range")
        stream.append(cost)
    return stream


def benchmark_stream(case, seed, family, kind, frames, repeats, budget, session):
    model = independently_encode(case)
    fixed = FixedModel(model)
    snapshots = stream_costs(case, fixed, seed, kind, frames)
    # Independent checks run before timers and are shared across every method.
    optima = []
    for cost in [fixed.initial_cost, *snapshots]:
        current = fixed.updated_model(cost)
        optima.append(verify_table(current, bellman_table(current)))
    results = {m: {"repeats": []} for m in METHODS}
    rng = np.random.default_rng(seed + session * 991)
    orders = []
    for repeat in range(repeats):
        order = list(METHODS)
        rng.shuffle(order)
        orders.append(order)
        for method in order:
            begun = time.perf_counter_ns()
            solver = StreamSolver(fixed, method, budget)
            setup_ms = (time.perf_counter_ns() - begun) / 1e6
            initial_result = solver.result()
            verify_result(model, initial_result, optima[0])
            initial_certificate = solver.certificate()
            previous_fast = (
                solver.handle.stats()["fast_builds"] if not solver.native else 0
            )
            records = []
            for frame, cost in enumerate(snapshots):
                solver.prepare(cost)
                begun = time.perf_counter_ns()
                status = solver.step()
                elapsed_ms = (time.perf_counter_ns() - begun) / 1e6
                result = solver.result()
                verify_result(fixed.updated_model(cost), result, optima[frame + 1])
                records.append(
                    dict(
                        frame=frame,
                        elapsed_ms=elapsed_ms,
                        status=status,
                        certificate=(
                            solver.certificate(previous_fast) if status == 2 else None
                        ),
                        **result,
                    )
                )
                if not solver.native:
                    previous_fast = solver.handle.stats()["fast_builds"]
            stats = solver.stats()
            solver.close()
            results[method]["repeats"].append(
                dict(
                    repeat=repeat,
                    setup_ms=setup_ms,
                    initial_result=initial_result,
                    initial_certificate=initial_certificate,
                    total_ms=setup_ms + sum(x["elapsed_ms"] for x in records),
                    frames=records,
                    stats=stats,
                )
            )
    for entry in results.values():
        entry["median_total_ms"] = float(
            np.median([r["total_ms"] for r in entry["repeats"]])
        )
    # Stream encoding suffices to replay exact integer models and every decision.
    changes = []
    previous = fixed.initial_cost
    for cost in snapshots:
        indexes = np.flatnonzero(cost != previous)
        changes.append([[int(e), int(cost[e])] for e in indexes])
        previous = cost
    return dict(
        seed=seed,
        family=family,
        stream_kind=kind,
        initial_model=model,
        changes=changes,
        optima_q16=optima,
        results=results,
        orders=orders,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", default="72000:72003")
    parser.add_argument("--frames", type=int, default=128)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--session", type=int, default=0)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    low, high = map(int, args.seeds.split(":"))
    if low > high or args.frames <= 0 or args.repeats <= 0 or args.session < 0:
        parser.error(
            "require ordered seeds, positive frames/repeats, nonnegative session"
        )
    before = hashes()
    protocol = None
    budget = 64 * 1024 * 1024
    if args.protocol:
        protocol = json.loads(args.protocol.read_text())
        if (
            not protocol["frozen"]
            or protocol["source_sha256"] != before
            or protocol["seeds"] != list(range(low, high + 1))
            or protocol["frames"] != args.frames
            or protocol["repeats"] != args.repeats
            or args.session not in range(protocol["sessions"])
            or protocol["methods"] != list(METHODS)
            or protocol["families"] != list(FAMILIES)
            or protocol["stream_kinds"] != list(STREAMS)
            or protocol["memory_limit"] != budget
        ):
            raise RuntimeError("run differs from source-locked protocol")
    # All libraries and native dispatchers are warmed outside measurement.
    warm = FixedModel(dict(adjacent=[[[1, 1, 4]], []], start=0, goals=[1], deadline=3))
    library()
    for method in METHODS:
        solver = StreamSolver(warm, method, budget)
        solver.step()
        solver.close()
    rows = []
    for seed in range(low, high + 1):
        for family in FAMILIES:
            case = make_case(seed, family)
            for kind in STREAMS:
                rows.append(
                    benchmark_stream(
                        case,
                        seed,
                        family,
                        kind,
                        args.frames,
                        args.repeats,
                        budget,
                        args.session,
                    )
                )
        print(f"Completed {seed}: {len(rows)} streams", flush=True)
    if hashes() != before:
        raise RuntimeError("source changed during experiment")
    summary = {}
    for method in METHODS:
        ratios = [
            row["results"][method]["median_total_ms"]
            / row["results"]["prefix_certificate"]["median_total_ms"]
            for row in rows
        ]
        summary[method] = dict(
            candidate_total_speedup=float(np.exp(np.mean(np.log(ratios)))),
            retentions=sum(
                r["stats"]["retentions"]
                for row in rows
                for r in row["results"][method]["repeats"]
            ),
            peak_numeric_bytes=max(
                r["stats"]["peak_numeric_bytes"]
                for row in rows
                for r in row["results"][method]["repeats"]
            ),
        )
    write_json(
        args.output,
        dict(
            source_sha256=before,
            protocol_sha256=(
                hashlib.sha256(args.protocol.read_bytes()).hexdigest()
                if args.protocol
                else None
            ),
            session=args.session,
            frames=args.frames,
            repeats=args.repeats,
            exploratory=protocol is None,
            python=platform.python_version(),
            memory_limit=budget,
            timing=(
                "Initial solver/certificate construction plus all C updates on fixed "
                "CSR inputs. Output copying, cost encoding/CSR preparation and "
                "independent checks excluded equally. ABI argument count differs "
                "across interfaces."
            ),
            summary=summary,
            rows=rows,
        ),
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
