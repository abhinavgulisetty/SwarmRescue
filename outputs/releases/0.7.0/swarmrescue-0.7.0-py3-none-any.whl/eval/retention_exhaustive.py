"""Tiny exhaustive hazard revisions checked by simple-path enumeration, not DP."""

from __future__ import annotations

import itertools
from pathlib import Path

import numpy as np

from eval.routing_certificates import verify_result, write_json
from mcu.retention import MODES, FixedModel, RetentionSolver


def enumerated_optimum(model):
    goals = set(model["goals"])
    best = None

    def visit(u, elapsed, cost, seen):
        nonlocal best
        if u in goals:
            if best is None or cost < best:
                best = cost
            return
        for v, duration, weight in model["adjacent"][u]:
            if v not in seen and elapsed + duration <= model["deadline"]:
                visit(v, elapsed + duration, cost + weight, seen | {v})

    visit(model["start"], 0, 0, {model["start"]})
    return best


def main():
    models = [
        dict(
            adjacent=[
                [[1, 1, 10], [2, 1, 10], [3, 1, 20]],
                [[4, 1, 10]],
                [[4, 1, 13], [3, 1, 10]],
                [[4, 1, 10]],
                [],
            ],
            start=0,
            goals=[4],
            deadline=3,
        ),
        dict(
            adjacent=[
                [[1, 1, 10], [2, 1, 10], [3, 1, 22]],
                [[4, 1, 10]],
                [[4, 1, 13], [3, 1, 5]],
                [[4, 1, 10]],
                [],
            ],
            start=0,
            goals=[4],
            deadline=3,
        ),
        dict(
            adjacent=[
                [
                    [v, 1 + (u + v) % 3, 10 + (u * 7 + v * 3) % 11]
                    for v in range(5)
                    if v != u
                ]
                for u in range(5)
            ],
            start=0,
            goals=[3, 4],
            deadline=5,
        ),
    ]
    checked = 0
    retained = {m: 0 for m in MODES}
    for model in models:
        fixed = FixedModel(model)
        solvers = {m: RetentionSolver(fixed, m) for m in MODES}
        for revisions in itertools.product(range(-2, 3), repeat=5):
            revision = np.array(revisions, np.int64)
            cost = np.ascontiguousarray(
                fixed.initial_cost + revision[fixed.to] * fixed.duration,
                dtype=np.int64,
            )
            assert np.all(cost > 0)
            current = fixed.updated_model(cost)
            optimum = enumerated_optimum(current)
            for method, solver in solvers.items():
                status = solver.update(cost)
                verify_result(current, solver.result(), optimum)
                retained[method] += status == 1
                checked += 1
        for solver in solvers.values():
            solver.close()
    write_json(
        Path("docs/paper/retention/exhaustive-checks.json"),
        dict(
            graphs=models,
            positive_integer_risk_revisions_per_node=list(range(-2, 3)),
            revision_vectors_per_graph=5**5,
            checked_updates=checked,
            independent_oracle="Enumerate all simple routes, stop at first goal.",
            retained=retained,
            scope="Three five-node graphs; does not cover all graphs or costs.",
        ),
    )
    print(f"Independent simple-path enumeration checked {checked} updates.")


if __name__ == "__main__":
    main()
