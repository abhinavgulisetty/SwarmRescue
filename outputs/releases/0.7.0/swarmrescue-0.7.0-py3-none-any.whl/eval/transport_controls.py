"""Exploratory fairness checks with sparse-input baseline adapters.

Uses already opened confirmation traces: this is a post-hoc sensitivity study,
not a replacement for the source-locked primary endpoint.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import shutil
import subprocess
import tempfile
import time
from functools import cache
from pathlib import Path

import numpy as np
from eval.retention_research import StreamSolver
from eval.routing_certificates import verify_result
from eval.transport_analysis import load
from eval.transport_research import write
from mcu.retention import FixedModel, U32, I64, pointer
from mcu.transport import TransportSolver,library


@cache
def control_library():
    source=Path(__file__).resolve().parents[1]/"firmware/deadline_transport_controls.c"
    with tempfile.TemporaryDirectory(prefix="transport-controls-") as folder:
        output=Path(folder)/"controls.so"
        subprocess.run([shutil.which("cc") or "cc","-std=c99","-O3","-Wall",
            "-Wextra","-Werror","-shared","-fPIC",str(source),"-o",str(output)],
            check=True,capture_output=True)
        lib=ctypes.CDLL(str(output))
    lib.ember_sparse_dp_update.argtypes=[ctypes.c_void_p]+[ctypes.c_uint32]*3+[U32,I64]
    lib.ember_sparse_dp_update.restype=ctypes.c_int
    return lib


def sparse_dp(fixed):
    solver=TransportSolver(fixed,"moving_incremental_dp")
    solver.step=control_library().ember_sparse_dp_update
    return solver


class SparseNative(StreamSolver):
    def __init__(self,fixed,method,budget):
        super().__init__(fixed,method,budget)
        self.cost=fixed.initial_cost.copy()
        self.args[4]=pointer(self.cost)
        self.inverse=np.empty(fixed.m,np.uint32)
        self.inverse[fixed.reverse_edges]=np.arange(fixed.m,dtype=np.uint32)

    def update(self,start,deadline,edges,values):
        self.cost[edges]=values
        self.reverse_cost[self.inverse[edges]]=values
        self.args[10],self.args[11]=start,deadline
        return self.step()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("report",type=Path)
    ap.add_argument("--output",required=True,type=Path)
    args=ap.parse_args()
    original=load(args.report)
    methods=["transport_sparse","sparse_incremental_dp","sparse_event","sparse_hybrid"]
    design=dict(original["design"],methods=methods,sessions=1,post_hoc=True,
        trace_sha256=hashlib.sha256(args.report.read_bytes()).hexdigest(),
        controls_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        control_c_sha256=hashlib.sha256((Path(__file__).resolve().parents[1]/
            "firmware/deadline_transport_controls.c").read_bytes()).hexdigest())
    library();control_library()
    tiny=FixedModel(dict(adjacent=[[[1,1,1]],[]],start=0,goals=[1],deadline=2))
    for name in ("event_recompute","native_recompute"):
        s=SparseNative(tiny,name,design["budget"]);s.close()
    rows=[];rng=np.random.default_rng(709311)
    for row in original["rows"]:
        fixed=FixedModel(row["model"])
        cost=fixed.initial_cost.copy();frames=[]
        for f in row["frames"]:
            e=np.array(f["edges"],np.uint32);v=np.array(f["values"],np.int64)
            cost[e]=v;model=fixed.updated_model(cost)
            model.update(start=f["start"],deadline=f["deadline"])
            frames.append((f,e,v,model))
        runs=[]
        for _ in range(design["repeats"]):
            run={}
            for method in rng.permutation(methods):
                stamp=time.perf_counter_ns()
                if method=="transport_sparse":
                    solver=TransportSolver(fixed)
                elif method=="sparse_incremental_dp":
                    solver=sparse_dp(fixed)
                else:
                    name="event_recompute" if method=="sparse_event" else "native_recompute"
                    solver=SparseNative(fixed,name,design["budget"])
                result=solver.result();elapsed=time.perf_counter_ns()-stamp
                verify_result(row["model"],result,row["initial"]["cost_q16"])
                results=[result];statuses=[]
                for f,e,v,model in frames:
                    stamp=time.perf_counter_ns()
                    status=solver.update(f["start"],f["deadline"],e,v)
                    result=solver.result();elapsed+=time.perf_counter_ns()-stamp
                    verify_result(model,result,f["optimum"])
                    results.append(result);statuses.append(status)
                stats=solver.stats()
                stamp=time.perf_counter_ns();solver.close();elapsed+=time.perf_counter_ns()-stamp
                run[str(method)]=dict(total_ns=elapsed,results=results,statuses=statuses,stats=stats)
            runs.append(run)
        rows.append(dict(row,runs=runs))
        print(json.dumps(dict(controls_seed=row["seed"],family=row["family"],kind=row["kind"],rate=row["rate"])),flush=True)
    write(args.output,dict(design=design,session=0,rows=rows))


if __name__=="__main__":
    main()
