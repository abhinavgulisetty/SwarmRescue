"""A stable point excluded by TSC's conservative surrogate."""
import json
from pathlib import Path
import numpy as np
from eval.retention_certificates import certificate_summary,prefix_rule
from eval.retention_exhaustive import enumerated_optimum
from mcu.retention import FixedModel
from eval.query_safe_research import solver

def main():
    model=dict(adjacent=[[[3,1,10],[1,1,6],[2,1,6]],[[3,1,6]],[[3,1,6]],[]],
               start=0,goals=[3],deadline=2)
    fixed=FixedModel(model);native=solver(fixed)
    assert native.result()['route']==[0,3]
    gaps,floor=certificate_summary(model,[0,3])
    assert floor==2 and gaps[1]==gaps[2]==2
    assert not prefix_rule(gaps,[0,2,2,0],0,floor)
    edges=np.array([1,2],np.uint32);values=np.array([4,4],np.int64)
    cost=fixed.initial_cost.copy();cost[edges]=values
    current=fixed.updated_model(cost)
    status=native.update(0,2,edges,values)
    assert status==2
    assert native.result()['cost_q16']==enumerated_optimum(current)==10
    native.close()
    out=dict(model=model,reductions=[0,2,2,0],gaps=gaps,floor=floor,
        stable=True,surrogate_accepts=False,native_status=status,
        exact_region='a1<=2,a2<=2,a1>=0,a2>=0',surrogate_region='a1+a2<=2,a1>=0,a2>=0')
    path=Path('outputs/query-verification/separation.json')
    path.parent.mkdir(exist_ok=True,parents=True);path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))

if __name__=='__main__':main()
