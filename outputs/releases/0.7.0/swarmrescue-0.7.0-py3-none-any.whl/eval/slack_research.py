"""Exploratory residual-clock DP study; does not consume sealed protocols."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import platform
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np

from ember.routing.deadline import deadline_route
from eval.constrained_benchmark import FAMILIES, LABEL_CAPS, make_case
from eval.native_deadline_benchmark import source_hashes
from eval.paper_evidence import independently_encode
from eval.routing_certificates import bellman_table, verify_result, verify_table
from mcu import MCUArena
from mcu.slack_deadline import slack_route

METHODS = (
    "slack_policy",
    "slack_recompute",
    "native_exact",
    "native_astar",
    "native_window_dp",
    "hybrid_exact",
)
ROOT = Path(__file__).resolve().parents[1]


def hashes():
    return source_hashes() | {
        p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
        for p in (
            "firmware/deadline_slack.c",
            "mcu/slack_deadline.py",
            "eval/slack_research.py",
            "tests/test_slack_deadline.py",
        )
    }


def call(case, capacity, method, *, arena=None):
    graph, start, goals, risk, deadline = case
    solver = slack_route if method.startswith("slack_") else deadline_route
    result = solver(
        graph,
        start,
        goals,
        risk,
        available_steps=deadline,
        walking_speed_m_s=1,
        dt_s=1,
        max_labels=capacity,
        arena=arena or MCUArena(204800),
        strategy=method,
    )
    row = asdict(result)
    row["cost_q16"] = (
        round(result.estimated_objective * 65536) if result.feasible else None
    )
    return row


def summarize(rows):
    answer = {}
    for method in METHODS:
        feasible = [r for r in rows if r["optimum_q16"] is not None]
        pairs = [
            r
            for r in feasible
            if all(
                all(s["optimal"] and s["feasible"] for s in r["results"][m]["samples"])
                for m in (method, "slack_policy")
            )
        ]
        entry = {
            "feasible_cases": len(feasible),
            "all_repeat_exact": sum(
                all(s["optimal"] for s in r["results"][method]["samples"])
                for r in feasible
            ),
            "exact_pairs": len(pairs),
            "max_numeric_bytes": max(
                s["arena_high_water_bytes"]
                for r in rows
                for s in r["results"][method]["samples"]
            ),
        }
        if pairs:
            seeds = sorted({r["seed"] for r in pairs})
            logs = np.array(
                [
                    np.log(
                        r["results"][method]["median_ms"]
                        / r["results"]["slack_policy"]["median_ms"]
                    )
                    for r in pairs
                ]
            )
            sums = np.array(
                [
                    sum(
                        x for x, r in zip(logs, pairs, strict=True) if r["seed"] == seed
                    )
                    for seed in seeds
                ]
            )
            counts = np.array([sum(r["seed"] == seed for r in pairs) for seed in seeds])
            draws = np.random.default_rng(8317).integers(
                0, len(seeds), (10000, len(seeds))
            )
            entry.update(
                speedup=float(np.exp(logs.mean())),
                seed_bootstrap_95ci=np.quantile(
                    np.exp(sums[draws].sum(1) / counts[draws].sum(1)), [0.025, 0.975]
                ).tolist(),
                faster_pairs=int(sum(logs > 0)),
                slower_pairs=int(sum(logs < 0)),
            )
        answer[method] = entry
    return answer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", default="72000:72003")
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arena", type=int, default=204800)
    parser.add_argument("--session", type=int, default=0)
    parser.add_argument("--protocol", type=Path)
    args = parser.parse_args()
    low, high = map(int, args.seeds.split(":"))
    if args.repeats < 1 or high < low:
        raise ValueError("invalid repeats or seeds")
    before = hashes()
    protocol = None
    if args.protocol:
        protocol = json.loads(args.protocol.read_text())
        if not protocol["frozen"] or protocol["source_sha256"] != before:
            raise RuntimeError("sources differ from frozen research protocol")
        if (
            list(range(low, high + 1)) != protocol["seeds"]
            or args.repeats != protocol["repeats"]
            or args.arena not in protocol["arenas"]
            or args.session not in range(protocol["sessions"])
        ):
            raise RuntimeError("run differs from frozen research protocol")
    for method in METHODS:
        call(make_case(72000, "tradeoff"), 128, method)
    rng = np.random.default_rng(982743 + args.session)
    rows = []
    certificates = []
    for seed in range(low, high + 1):
        for family in FAMILIES:
            case = make_case(seed, family)
            model = independently_encode(case)
            values = bellman_table(model)
            optimum = verify_table(model, values)
            certificates.append(
                dict(
                    seed=seed,
                    family=family,
                    model=model,
                    values=values,
                    optimum_q16=optimum,
                )
            )
            for capacity in LABEL_CAPS:
                results = {m: {"samples": []} for m in METHODS}
                orders = []
                for _ in range(args.repeats):
                    order = list(METHODS)
                    rng.shuffle(order)
                    orders.append(order)
                    for method in order:
                        begun = time.perf_counter_ns()
                        result = call(
                            case, capacity, method, arena=MCUArena(args.arena)
                        )
                        result["elapsed_ms"] = (time.perf_counter_ns() - begun) / 1e6
                        verify_result(model, result, optimum, arena_bytes=args.arena)
                        results[method]["samples"].append(result)
                for entry in results.values():
                    entry["median_ms"] = float(
                        np.median([s["elapsed_ms"] for s in entry["samples"]])
                    )
                rows.append(
                    dict(
                        seed=seed,
                        family=family,
                        label_capacity=capacity,
                        optimum_q16=optimum,
                        model_sha256=hashlib.sha256(
                            json.dumps(model, sort_keys=True).encode()
                        ).hexdigest(),
                        nodes=case[0].n_nodes,
                        deadline=case[-1],
                        results=results,
                        orders=orders,
                    )
                )
        print(f"Completed {seed}: {len(rows)} cases", flush=True)
    if hashes() != before:
        raise RuntimeError("source changed during study")
    report = dict(
        exploratory=protocol is None,
        numeric_arena_bytes=args.arena,
        session=args.session,
        protocol_sha256=(
            hashlib.sha256(args.protocol.read_bytes()).hexdigest()
            if args.protocol
            else None
        ),
        certificates=certificates,
        python=platform.python_version(),
        source_sha256=before,
        seeds=list(range(low, high + 1)),
        repeats=args.repeats,
        timing=(
            "Full wrapper call; libraries warmed; verification outside timing. "
            "Same public validation and encoding as native comparators."
        ),
        memory_scope=(
            "Numeric arena only; graph, output, Python objects and C stack excluded."
        ),
        summary=summarize(rows),
        rows=rows,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(args.output, "wt") as stream:
        json.dump(report, stream)
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
