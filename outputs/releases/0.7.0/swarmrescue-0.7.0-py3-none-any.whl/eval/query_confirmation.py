"""Further confirmation on untouched seeds, with an in-process author control."""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.query_safe_research import frozen_hashes as previous_hashes,solver as previous_solver
from eval.query_author import AuthorSolver,DEFAULT

METHODS=('transport_sparse','sparse_incremental_dp','sparse_event','sparse_hybrid',
         'author_nwrca','author_heap_control')
EXTRA=('eval/query_confirmation.py','eval/query_confirmation_audit.py',
       'eval/query_author.py','eval/query_author_bridge.cpp','tests/test_query_author.py',
       'eval/query_author_stress.cpp','eval/query_exhaustive.py',
       'eval/query_confirmation_analysis.py','tests/test_query_confirmation.py')

def frozen_hashes():
    root=Path(__file__).resolve().parents[1]
    paths=EXTRA+('outputs/algorithm-research/reference-query-inprocess-v6/author.so',
                 'outputs/algorithm-research/reference-query-inprocess-v6/receipt.json',
                 'outputs/algorithm-research/reference-query-inprocess-v4/author.so',
                 'outputs/algorithm-research/reference-query-inprocess-v4/receipt.json')
    return dict(previous_hashes(),**{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths})

def solver(fixed,method='transport_sparse',*,memory_bytes=64*1024*1024):
    if method=='author_nwrca':return AuthorSolver(fixed)
    if method=='author_heap_control':
        root=Path(__file__).resolve().parents[1]
        return AuthorSolver(fixed,library_path=root/'outputs/algorithm-research/reference-query-inprocess-v4/author.so')
    return previous_solver(fixed,method,memory_bytes=memory_bytes)

def main():
    experiment.METHODS=METHODS;experiment.TransportSolver=solver
    experiment.hashes=frozen_hashes;experiment.main()

if __name__=='__main__':main()
