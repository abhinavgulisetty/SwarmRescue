"""Second fresh study: contracted certificates and sparse-input comparators.

Reuses the frozen moving-trace protocol machinery with an explicit factory;
neither the first-study implementation nor its evidence is overwritten.
"""
import hashlib
from pathlib import Path
import eval.transport_research as experiment
from eval.contract_analysis import one
from eval.transport_controls import SparseNative,sparse_dp
from mcu.contract import ContractSolver
from mcu.transport import TransportSolver

METHODS=("contracted_certificate","transport_sparse","reset_cmr","sparse_incremental_dp",
         "expanded_dstar_lite","sparse_event","sparse_hybrid")
EXTRA=("firmware/deadline_contract.c","mcu/contract.py","eval/contract_research.py",
       "eval/contract_analysis.py","eval/transport_controls.py",
       "firmware/deadline_transport_controls.c","tests/test_contract.py",
       "tests/test_transport_controls.py")
BASE_HASHES=experiment.hashes


def frozen_hashes():
    root=Path(__file__).resolve().parents[1]
    return dict(BASE_HASHES(),**{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in EXTRA})


def solver(fixed,method="transport_sparse",*,memory_bytes=64*1024*1024):
    if method=="contracted_certificate":
        return ContractSolver(fixed,memory_bytes=memory_bytes)
    if method=="sparse_incremental_dp":
        return sparse_dp(fixed)
    if method in ("sparse_event","sparse_hybrid"):
        return SparseNative(fixed,"event_recompute" if method=="sparse_event" else
                            "native_recompute",memory_bytes)
    return TransportSolver(fixed,method,memory_bytes=memory_bytes)


def main():
    experiment.METHODS=METHODS
    experiment.TransportSolver=solver
    experiment.hashes=frozen_hashes
    experiment.analyze=one
    experiment.main()


if __name__=="__main__":
    main()
