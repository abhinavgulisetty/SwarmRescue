"""Post-hoc setup-inclusive break-even analysis of saved stream prefixes."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from eval.retention_audit import stream_estimate
from eval.routing_certificates import read_json, require, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="+", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol = read_json(args.protocol)
    indexes = {}
    for path in args.reports:
        report = read_json(path)
        indexes[report["session"]] = {
            (r["seed"], r["family"], r["stream_kind"]): r for r in report["rows"]
        }
    require(set(indexes) == set(range(protocol["sessions"])), "session coverage")
    methods = protocol["methods"]
    horizons = (1, 2, 4, 8, 16, 32, 64)
    output = {}
    for kind in ("all_feasible", *protocol["stream_kinds"]):
        keys = [
            k
            for k in sorted(indexes[0])
            if indexes[0][k]["optima_q16"][0] is not None
            and (kind == "all_feasible" or k[2] == kind)
        ]
        output[kind] = {}
        for horizon in horizons:
            pairs = []
            for key in keys:
                ratios = []
                for session in range(protocol["sessions"]):
                    times = {}
                    for method in methods:
                        samples = indexes[session][key]["results"][method]["repeats"]
                        times[method] = float(
                            np.median(
                                [
                                    r["setup_ms"]
                                    + sum(
                                        f["elapsed_ms"] for f in r["frames"][:horizon]
                                    )
                                    for r in samples
                                ]
                            )
                        )
                    ratios.append(
                        {m: t / times["prefix_certificate"] for m, t in times.items()}
                    )
                pairs.append((key, ratios))
            output[kind][horizon] = {
                method: stream_estimate(pairs, method, comparisons=6 * len(horizons))
                for method in methods
                if method != "prefix_certificate"
            }
    write_json(
        args.output,
        dict(
            posthoc=True,
            description="Saved prefixes; short streams not separately measured.",
            comparisons_per_scope=6 * len(horizons),
            estimates=output,
        ),
    )
    for horizon in horizons:
        print(
            horizon,
            {
                m: round(r["candidate_geomean_speedup"], 3)
                for m, r in output["all_feasible"][horizon].items()
            },
        )


if __name__ == "__main__":
    main()
