"""Package the contracted-certificate evidence without bundling author code."""
import argparse
import hashlib
import json
import platform
import re
import shutil
import subprocess
import tarfile
from pathlib import Path

from eval.transport_analysis import load

ROOT=Path(__file__).resolve().parents[1]
LABELS={"unfiltered_transport":"Unfiltered sparse transport", "reset_cmr":"Reset-on-query CMR",
        "sparse_incremental_dp":"Sparse incremental DP", "expanded_dstar_lite":"Expanded D* Lite (h=0)",
        "sparse_event":"Sparse-input event solver", "sparse_hybrid":"Sparse-input hybrid solver"}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--study",type=Path,default=Path("outputs/contract"))
    ap.add_argument("--out",type=Path,default=Path("docs/paper/contract"))
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    summary=json.loads((args.study/"summary.json").read_text())
    audit=json.loads((args.study/"independent-audit.json").read_text())
    studies=[load(args.study/f"fresh-session{i}.json.gz") for i in range(3)]
    design=studies[0]["design"]
    if any(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=digest for p,digest in design["sources"].items()):
        raise ValueError("source lock changed")
    for name in ["fresh-session0.json.gz","fresh-session1.json.gz","fresh-session2.json.gz",
                 "summary.json","independent-audit.json","validation.json","published-reference.json.gz"]:
        source=args.study/name
        if source.exists():
            shutil.copy2(source,args.out/name)
    shutil.copy2(ROOT/"eval/contract_protocol.json",args.out/"protocol.json")
    original_failure=ROOT/"outputs/transport/published-reference.json.gz.failure.json"
    if original_failure.exists():
        shutil.copy2(original_failure,args.out/"original-author-failure.json")
    build=ROOT/"outputs/algorithm-research/reference-transport-positive/ember-build.json"
    if build.exists():
        shutil.copy2(build,args.out/"positive-author-build.json")
    table="| Comparator | Comparator / BCT time | Simultaneous 95% interval | Evidence |\n| --- | ---: | --- | --- |\n"
    for method,result in summary["primary"]["comparisons"].items():
        lo,hi=result["simultaneous_95_interval"]
        verdict="BCT faster" if lo>1 else "BCT slower" if hi<1 else "Inconclusive"
        table+=f"| {LABELS[method]} | {result['ratio']:.3f}x | [{lo:.3f}, {hi:.3f}] | {verdict} |\n"
    total_traces=len(studies[0]["rows"]);feasible=summary["primary"]["feasible_traces"]
    blocks=summary["primary"]["seed_blocks"]
    records=audit["output_records"];unique=audit["unique_queries"]
    results=(f"The study contains {total_traces} traces, of which {feasible} are initially feasible, "
        f"with {blocks} informative seed blocks. The remaining traces are saved and checked. "
        "The following are complete-call geometric speed ratios, including construction. "
        "Values above one favor BCT.\n\n"+table+
        f"\nThe independent replay checks {records:,} output records over {unique:,} distinct "
        "queries using Python arbitrary-integer constrained A* with Pareto dominance. "
        "The primary trace generator also checks initial/middle/final queries with Python "
        "integer Bellman DP. Output records are repeated checks, not independent statistical samples.\n")
    manuscript=args.out/"manuscript.md"
    text=manuscript.read_text()
    block="<!-- RESULTS:START -->\n"+results+"<!-- RESULTS:END -->"
    text=(text.replace("@@RESULTS@@",block) if "@@RESULTS@@" in text else
          re.sub(r"<!-- RESULTS:START -->.*?<!-- RESULTS:END -->",lambda _:block,text,flags=re.S))
    manuscript.write_text(text)
    memory={}
    representative=studies[0]["rows"]
    for method in design["methods"]:
        stats=[row["runs"][0][method]["stats"] for row in representative]
        memory[method]={k:max(s.get(k,0) for s in stats) for k in
            ("retained_numeric_bytes","peak_numeric_bytes","reserved_arena_bytes")}
    (args.out/"memory.json").write_text(json.dumps(memory,indent=2)+"\n")
    head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()
    metadata=dict(parent_commit=head,platform=platform.platform(),python=platform.python_version(),
        compiler=subprocess.check_output(["cc","--version"],text=True).splitlines()[0],
        source_hashes=design["sources"])
    for line in Path("/proc/cpuinfo").read_text().splitlines():
        if line.startswith("model name"):
            metadata["cpu"]=line.split(":",1)[1].strip();break
    (args.out/"host-and-source.json").write_text(json.dumps(metadata,indent=2)+"\n")
    readme=("# Budget-Contracted Transport: research evidence\n\n"
        "The candidate transports coupled optimality bounds along an executed route and "
        "removes irrelevant perturbations as the remaining deadline shrinks. "
        "Its contracted sufficient region provably contains the unfiltered region, strictly "
        "on the saved four-node example. Sparse accepted updates have a logarithmic "
        "maintenance bound plus eligibility crossings and executed arcs.\n\n"
        "[Full proofs and literature limits](../../contract-routing-research.md), "
        "[transport lemma](../../transport-routing-research.md), "
        "[working manuscript](manuscript.md), [protocol](protocol.json).\n\n"+results+
        "\n![Contracted sufficient region and measured speed](region-and-speed.svg)\n\n"
        "## Scope and limitations\n\n"
        "These are exact software results for fixed topology/goals/traversal clocks and "
        "positive costs, under moving sources and shrinking deadlines. They are authored "
        "traces on one host. The D* Lite baseline is our h=0 implementation on expanded "
        "states. The event/hybrid and DP controls ingest sparse changes. The DP control "
        "still incurs generic once-per-stream metadata allocations. No universal solver "
        "dominance, historical first-ever priority, calibrated rescue benefit or measured "
        "MCU timing follows. Peak construction memory can exceed persistent storage; "
        "see [memory counts](memory.json).\n\n"
        "A published-author preprocessing failure on a positive-cost moving query is "
        "preserved in [the exact failing case](original-author-failure.json). A separate "
        "positive-cost adaptation disables the unsound negative-cycle depth rejection "
        "for this domain. Its [build receipt](positive-author-build.json) records the "
        "change. These adapted-author checks are supplementary correctness checks, "
        "not matched primary timings.\n\n"
        "## Reproduction\n\n"
        f"Start from parent checkout `{head}` and overlay `research-source.tar.gz`. "
        "Use the project's declared Python dependencies and a C compiler.\n\n"
        "```bash\n.venv/bin/pytest -q tests/test_transport.py tests/test_transport_controls.py tests/test_contract.py tests/test_contract_oracle.py tests/test_retention.py\n"
        "for session in 0 1 2; do\n  .venv/bin/python -m eval.contract_research --protocol eval/contract_protocol.json "
        "--seeds 192000:192011 --families grid,tradeoff,large_grid --rates 1,4 --limit 96 --repeats 3 "
        '--session "$session" --output "outputs/contract/fresh-session${session}.json.gz"\ndone\n'
        ".venv/bin/python -m eval.contract_analysis outputs/contract/fresh-session{0,1,2}.json.gz --output outputs/contract/summary.json\n"
        ".venv/bin/python -m eval.contract_audit outputs/contract/fresh-session{0,1,2}.json.gz --output outputs/contract/independent-audit.json\n```\n\n"
        "The source lock is local, not publicly timestamped preregistration. Raw records, "
        "audit hashes and checksums retain all losses. The initial unfiltered-transport "
        "study remains separately preserved in `outputs/transport`; its results must "
        "not be attributed to this contracted candidate.\n")
    (args.out/"README.md").write_text(readme)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    fig,axes=plt.subplots(1,2,figsize=(11.8,4.2),gridspec_kw={"width_ratios":[1,1.7]})
    d=np.linspace(0,5,300)
    axes[0].fill_between(d,-3,2,color="#b9ddd5",label="Contracted guard")
    axes[0].fill_between(d,-3,2-d,color="#387f92",alpha=.8,label="Unfiltered guard")
    axes[0].plot([3],[0],"o",color="#b44432",label="Strict witness")
    axes[0].set(xlim=(0,5),ylim=(-3,3),xlabel="Reduction on excluded node's incoming arc",
                ylabel="Current suffix cost shift",title="Same-anchor sufficient regions")
    axes[0].legend(fontsize=8,loc="lower left")
    names=list(summary["primary"]["comparisons"])
    for i,name in enumerate(names):
        result=summary["primary"]["comparisons"][name];ratio=result["ratio"]
        lo,hi=result["simultaneous_95_interval"]
        axes[1].errorbar(ratio,i,xerr=[[ratio-lo],[hi-ratio]],fmt="o",capsize=3,
                         color="#276d83" if lo>1 else "#777777")
    axes[1].axvline(1,color="#b44432",linestyle="--",linewidth=1)
    axes[1].set_yticks(range(len(names)),[LABELS[n] for n in names],fontsize=8)
    axes[1].invert_yaxis();axes[1].set(xlabel="Comparator time / BCT time",
        title="Whole-call timing, simultaneous 95% intervals")
    fig.tight_layout()
    for suffix in ("svg","pdf","png"):
        fig.savefig(args.out/f"region-and-speed.{suffix}",dpi=180)
    plt.close(fig)
    extra=["eval/transport_audit.py","eval/contract_audit.py","eval/contract_oracle.py",
        "eval/contract_export.py","eval/transport_reference.py","eval/transport_author_build.py",
        "eval/transport_stress.c","tests/test_contract_oracle.py","tests/test_retention.py",
        "eval/retention_certificates.py","eval/contract_protocol.json","eval/transport_protocol.json",
        "docs/contract-routing-research.md","docs/transport-routing-research.md",
        "docs/retention-routing-research.md","docs/paper/contract/manuscript.md"]
    paths=sorted(set(design["sources"])|set(extra))
    with tarfile.open(args.out/"research-source.tar.gz","w:gz") as archive:
        for path in paths:
            archive.add(ROOT/path,arcname=path)
    sums=[]
    for path in sorted(args.out.iterdir()):
        if path.is_file() and path.name!="SHA256SUMS":
            sums.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}")
    (args.out/"SHA256SUMS").write_text("\n".join(sums)+"\n")
    print(json.dumps(dict(exported=str(args.out),source_lock_matches=True,
                          comparisons=summary["primary"]["comparisons"])),flush=True)


if __name__=="__main__":
    main()
