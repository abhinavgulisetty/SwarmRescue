"""Source-locked moving-query study; complete solver calls and setup are timed.

Trace policy uses a separate full-DP solver, not candidate certificates. Cost
updates are sampled uniformly by the pre-existing hazard generator. This is
software replay of authored workloads, not measured robot sensor data.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import platform
import time
from pathlib import Path

import numpy as np

from eval.constrained_benchmark import make_case
from eval.paper_evidence import independently_encode
from eval.retention_research import StreamSolver, stream_costs
from eval.routing_certificates import bellman_table, verify_result, verify_table
from mcu.retention import FixedModel
from mcu.transport import TransportSolver, library

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("transport_sparse", "transport_scan", "reset_cmr", "moving_incremental_dp",
           "expanded_dstar_lite", "event_recompute", "native_recompute")
SOURCES = ("firmware/deadline_transport.c", "firmware/deadline_dynamic.c",
           "firmware/deadline_retention.c", "mcu/transport.py", "mcu/retention.py",
           "eval/transport_research.py", "eval/retention_research.py",
           "eval/routing_certificates.py", "eval/constrained_benchmark.py",
           "eval/paper_evidence.py", "firmware/deadline_exact.c",
           "firmware/deadline_exact.h", "firmware/deadline_event.c",
           "mcu/native_deadline.py", "mcu/event_deadline.py", "eval/transport_analysis.py",
           "tests/test_transport.py")


def hashes():
    return {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in SOURCES}


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".gz":
        with gzip.open(path, "wt") as out:
            json.dump(value, out)
    else:
        path.write_text(json.dumps(value, indent=2)+"\n")


def trace(seed, family, kind, rate, limit, budget):
    case = make_case(seed, family)
    model = independently_encode(case)
    fixed = FixedModel(model)
    reference = TransportSolver(fixed, "moving_full_dp", memory_bytes=budget)
    initial = reference.result()
    # Initial feasibility is the only exclusion from speed inference.
    optimum = verify_table(model, bellman_table(model))
    verify_result(model, initial, optimum)
    frames = []
    if not initial["feasible"]:
        reference.close()
        return fixed, model, initial, frames
    start, deadline = fixed.start, fixed.deadline
    old = fixed.initial_cost.copy()
    previous = initial
    for i, cost in enumerate(stream_costs(case, fixed, seed, kind, limit)):
        if i and i % rate == 0:
            route = previous["route"]
            if len(route)<2:
                break
            nxt = route[1]
            arc = next(e for e in range(int(fixed.rows[start]), int(fixed.rows[start+1]))
                       if fixed.to[e] == nxt)
            start = nxt
            deadline -= int(fixed.duration[arc])
        if fixed.goals[start]:
            break
        edges = np.flatnonzero(cost != old).astype(np.uint32)
        values = np.ascontiguousarray(cost[edges])
        reference.update(start, deadline, edges, values)
        previous = reference.result()
        current = fixed.updated_model(cost)
        current.update(start=start, deadline=deadline)
        verify_result(current, previous, previous["cost_q16"])
        frames.append(dict(start=start, deadline=deadline, edges=edges, values=values,
                           cost=cost, optimum=previous["cost_q16"], model=current))
        old = cost
    reference.close()
    # Independent Python integer Bellman replay at initial/middle/final queries.
    for i in sorted({0, len(frames)//2, len(frames)-1}):
        if i < 0 or not frames:
            continue
        f = frames[i]
        value = verify_table(f["model"], bellman_table(f["model"]))
        if value != f["optimum"]:
            raise AssertionError("trace policy disagrees with independent oracle")
    return fixed, model, initial, frames


def timed(method, fixed, initial, frames, budget):
    native = method.endswith("recompute")
    stamp = time.perf_counter_ns()
    solver = (StreamSolver(fixed, method, budget) if native else
              TransportSolver(fixed, method, memory_bytes=budget))
    result = solver.result()
    elapsed = time.perf_counter_ns()-stamp
    verify_result(fixed.updated_model(fixed.initial_cost), result, initial["cost_q16"])
    records = [result]
    statuses = []
    for f in frames:
        stamp = time.perf_counter_ns()
        if native:
            solver.args[10], solver.args[11] = f["start"], f["deadline"]
            solver.prepare(f["cost"])
            status = solver.step()
        else:
            status = solver.update(f["start"], f["deadline"], f["edges"], f["values"])
        result = solver.result()
        elapsed += time.perf_counter_ns()-stamp
        verify_result(f["model"], result, f["optimum"])
        records.append(result)
        statuses.append(status)
    stats = solver.stats()
    stamp = time.perf_counter_ns()
    solver.close()
    elapsed += time.perf_counter_ns()-stamp
    return dict(total_ns=elapsed, results=records, statuses=statuses, stats=stats)


def analyze(rows, methods):
    usable = [r for r in rows if r["initial"]["feasible"] and r["frames"]]
    seeds = sorted({r["seed"] for r in usable})
    output = dict(feasible_traces=len(usable), seed_blocks=len(seeds), comparisons={})
    if not usable:
        return output
    # Aggregate repeat noise per stream first. Resample whole seed blocks,
    # preserving all families, processes and sensing rates within a block.
    for method in methods:
        if method == "transport_sparse":
            continue
        logs = []
        for r in usable:
            a = np.median([x["transport_sparse"]["total_ns"] for x in r["runs"]])
            b = np.median([x[method]["total_ns"] for x in r["runs"]])
            logs.append(math.log(b/a))
        sums = np.array([sum(v for v,r in zip(logs,usable,strict=True) if r["seed"]==s)
                         for s in seeds])
        counts = np.array([sum(r["seed"]==s for r in usable) for s in seeds])
        draws = np.random.default_rng(771309).integers(len(seeds), size=(20000,len(seeds)))
        boot = np.exp(sums[draws].sum(1)/counts[draws].sum(1))
        alpha = .05/(len(methods)-1)
        output["comparisons"][method] = dict(ratio=math.exp(sum(logs)/len(logs)),
            simultaneous_95_interval=np.quantile(boot,[alpha/2,1-alpha/2]).tolist())
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--freeze", type=Path)
    ap.add_argument("--protocol", type=Path)
    ap.add_argument("--seeds", default="190000:190001")
    ap.add_argument("--families", default="grid,tradeoff,large_grid")
    ap.add_argument("--rates", default="1,4")
    ap.add_argument("--limit", type=int, default=96)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--session", type=int, default=0)
    ap.add_argument("--sessions", type=int, default=3)
    ap.add_argument("--methods", default=",".join(METHODS))
    ap.add_argument("--output", type=Path, default=Path("outputs/transport/pilot.json.gz"))
    args = ap.parse_args()
    first,last = map(int,args.seeds.split(":"))
    design = dict(seeds=list(range(first,last+1)), families=args.families.split(","),
        rates=list(map(int,args.rates.split(","))), kinds=["background","mixed"],
        limit=args.limit, repeats=args.repeats, sessions=args.sessions,methods=args.methods.split(","),
        budget=64*1024*1024, sources=hashes(),
        timing="setup + public update/result calls + teardown; compilation/trace generation excluded",
        inference="geometric stream speed ratios; median repeats; whole-session/whole-seed bootstrap; Bonferroni simultaneous 95%",
        exclusions="initial clock infeasibility only; retain all losses",
        oracle="separate full DP all queries; independent Python Bellman initial/middle/final")
    if args.freeze:
        if args.freeze.exists():
            raise RuntimeError("refusing to overwrite a frozen protocol")
        write(args.freeze, design)
        print(json.dumps(dict(frozen=str(args.freeze),design=design)),flush=True)
        return
    if args.protocol and json.loads(args.protocol.read_text()) != design:
        raise RuntimeError("protocol/source mismatch")
    if not 0 <= args.session < args.sessions:
        raise ValueError("session outside protocol")
    library()  # Compilation is outside all measurements for every method.
    # Warm the independent native comparator libraries too.
    tiny = FixedModel(dict(adjacent=[[[1,1,1]],[]],start=0,goals=[1],deadline=2))
    for method in design["methods"]:
        s = StreamSolver(tiny,method,design["budget"]) if method.endswith("recompute") else TransportSolver(tiny,method)
        s.close()
    rows = []
    rng = np.random.default_rng(190991+args.session)
    for seed in design["seeds"]:
        for family in design["families"]:
            for kind in design["kinds"]:
                for rate in design["rates"]:
                    fixed,model,initial,frames = trace(seed,family,kind,rate,args.limit,design["budget"])
                    runs = []
                    for _ in range(args.repeats):
                        run = {}
                        for method in rng.permutation(design["methods"]):
                            run[str(method)] = timed(str(method),fixed,initial,frames,design["budget"])
                        # Exact equality of guard decisions isolates tree implementation.
                        if "transport_scan" in run and run["transport_sparse"]["statuses"] != run["transport_scan"]["statuses"]:
                            raise AssertionError("sparse/scan decision mismatch")
                        runs.append(run)
                    row = dict(seed=seed,family=family,kind=kind,rate=rate,model=model,
                        initial=initial,frames=[dict(start=f["start"],deadline=f["deadline"],
                            edges=f["edges"].tolist(),values=f["values"].tolist(),optimum=f["optimum"])
                            for f in frames],runs=runs)
                    rows.append(row)
                    print(json.dumps(dict(seed=seed,family=family,kind=kind,rate=rate,
                        frames=len(frames),feasible=initial["feasible"])),flush=True)
        # Incremental, recoverable output after each complete seed.
        write(args.output,dict(design=design,session=args.session,host=platform.platform(),
            rows=rows,analysis=analyze(rows,design["methods"])))
    print(json.dumps(analyze(rows,design["methods"])),flush=True)


if __name__ == "__main__":
    main()
