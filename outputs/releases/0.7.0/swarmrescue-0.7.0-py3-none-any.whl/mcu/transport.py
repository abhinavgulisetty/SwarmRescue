"""Research API: sparse cost patches and moving deadline queries."""
from __future__ import annotations

import ctypes
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path

import numpy as np

from mcu.retention import FixedModel, INF, I64, U32, U64, BYTE, pointer

MODES = {"transport_sparse": 0, "transport_scan": 1, "reset_cmr": 2,
         "moving_incremental_dp": 3, "moving_full_dp": 4, "expanded_dstar_lite": 5}


@cache
def library():
    source = Path(__file__).resolve().parents[1] / "firmware/deadline_transport.c"
    with tempfile.TemporaryDirectory(prefix="ember-transport-") as folder:
        output = Path(folder) / "transport.so"
        subprocess.run([shutil.which("cc") or "cc", "-std=c99", "-O3", "-Wall",
                        "-Wextra", "-Werror", "-shared", "-fPIC", str(source),
                        "-o", str(output)], check=True, capture_output=True)
        lib = ctypes.CDLL(str(output))
    create_types = ([ctypes.c_uint32] * 2 + [U32] * 6 +
        [BYTE] + [ctypes.c_uint32] * 2 + [I64, ctypes.c_uint32, ctypes.c_size_t])
    for prefix in ("ember_transport", "ember_dynamic"):
        getattr(lib, prefix+"_create").argtypes = create_types
        getattr(lib, prefix+"_create").restype = ctypes.c_void_p
        getattr(lib, prefix+"_update").argtypes = [ctypes.c_void_p] + [ctypes.c_uint32] * 3 + [U32, I64]
        getattr(lib, prefix+"_update").restype = ctypes.c_int
        getattr(lib, prefix+"_result").argtypes = [ctypes.c_void_p, U32, U32]
        getattr(lib, prefix+"_result").restype = ctypes.c_int64
        getattr(lib, prefix+"_stats").argtypes = [ctypes.c_void_p, U64]
        getattr(lib, prefix+"_destroy").argtypes = [ctypes.c_void_p]
    return lib


class TransportSolver:
    def __init__(self, model, method="transport_sparse", *, memory_bytes=64*1024*1024):
        self.handle = None
        self.model = model if isinstance(model, FixedModel) else FixedModel(model)
        self.lib = library()
        prefix = "ember_dynamic" if method == "expanded_dstar_lite" else "ember_transport"
        self.create = getattr(self.lib, prefix+"_create")
        self.step = getattr(self.lib, prefix+"_update")
        self.read = getattr(self.lib, prefix+"_result")
        self.statistics = getattr(self.lib, prefix+"_stats")
        self.destroy = getattr(self.lib, prefix+"_destroy")
        m = self.model
        self.handle = self.create(m.n, m.m, pointer(m.rows),
            pointer(m.to), pointer(m.duration), pointer(m.from_nodes),
            pointer(m.reverse_rows), pointer(m.reverse_edges), pointer(m.goals),
            m.start, m.deadline, pointer(m.initial_cost), MODES[method], memory_bytes)
        if not self.handle:
            raise MemoryError("transport solver initialization failed or exceeds budget")
        self.output = np.empty(m.n, np.uint32)

    def close(self):
        if self.handle:
            self.destroy(self.handle)
            self.handle = None

    def __del__(self):
        self.close()

    def update(self, start, deadline, edges, costs):
        if not self.handle:
            raise RuntimeError("solver is closed")
        edges, costs = np.asarray(edges), np.asarray(costs)
        if (edges.dtype != np.uint32 or costs.dtype != np.int64 or edges.ndim != 1
                or costs.shape != edges.shape or not edges.flags.c_contiguous
                or not costs.flags.c_contiguous or not 0 <= start < self.model.n
                or not 0 <= deadline <= self.model.deadline):
            raise ValueError("invalid query or contiguous uint32/int64 patches")
        status = self.step(self.handle, start, deadline,
            len(edges), pointer(edges), pointer(costs))
        if status < 0:
            raise ValueError("invalid patch or failed native witness")
        return status

    def result(self):
        if not self.handle:
            raise RuntimeError("solver is closed")
        length = ctypes.c_uint32()
        value = int(self.read(self.handle, pointer(self.output),
                                                   ctypes.byref(length)))
        return dict(route=self.output[:length.value].astype(int).tolist(),
            feasible=value != INF, optimal=True,
            cost_q16=value if value != INF else None,
            lower_bound_q16=value if value != INF else None)

    def stats(self):
        data = np.empty(10, np.uint64)
        self.statistics(self.handle, pointer(data))
        names = ["retained_numeric_bytes", "peak_numeric_bytes", "builds", "retentions",
                 "recomputed_states", "fast_builds", "patched_arcs", "executed_arcs",
                 "transported_queries", "tree_updates"]
        return dict(zip(names, map(int, data), strict=True))
