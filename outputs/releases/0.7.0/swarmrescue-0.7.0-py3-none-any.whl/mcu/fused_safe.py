"""Typed fused bridge; the target is compiled in the same translation unit."""
import ctypes
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path
from mcu.fused import FusedSolver as PreviousFusedSolver,SOURCES


@cache
def library(kind):
    root=Path(__file__).resolve().parents[1]/"firmware"
    source,update,result=SOURCES[kind]
    with tempfile.TemporaryDirectory(prefix="transport-typed-fused-") as folder:
        out=Path(folder)/"fused.so"
        subprocess.run([shutil.which("cc") or "cc","-std=c99","-O3","-Wall","-Wextra",
            "-Werror","-shared","-fPIC",str(root/"deadline_fused_safe.c"),
            '-DTARGET_SOURCE="'+source+'"',"-DTARGET_UPDATE="+update,
            "-DTARGET_RESULT="+result,"-o",str(out)],check=True,capture_output=True)
        lib=ctypes.CDLL(str(out))
    lib.ember_fused_update.argtypes=[ctypes.c_void_p]+[ctypes.c_uint32]*3+[ctypes.c_void_p]*5
    lib.ember_fused_update.restype=ctypes.c_int
    return lib


class FusedSolver(PreviousFusedSolver):
    def __init__(self,base,kind):
        self.base=base;self.lib=library(kind)
        self.length=ctypes.c_uint32();self.value=ctypes.c_int64();self.output=base.output
        self.tail=(self.output.ctypes.data,ctypes.byref(self.length),ctypes.byref(self.value))
        self.value.value=int(base.read(base.handle,self.output.ctypes.data_as(
            ctypes.POINTER(ctypes.c_uint32)),ctypes.byref(self.length)))
