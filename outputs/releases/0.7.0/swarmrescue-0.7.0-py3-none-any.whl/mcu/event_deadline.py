"""Research event-driven residual-clock DP wrapper; the deployed solver is unchanged."""

from __future__ import annotations

import ctypes
import math
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path

import numpy as np

from cascade.extract import TraversabilityGraph
from ember.routing.deadline import DeadlineRoute
from mcu import INT32_MAX, Q16_SCALE, MCUArena

MODES = {
    "event_exact": 0,
    "event_no_lattice": 1,
    "event_dense": 2,
    "event_no_extinction": 3,
    "event_no_astar": 4,
}


class _Stats(ctypes.Structure):
    _fields_ = (
        [(name, ctypes.c_int64) for name in ("cost", "lower_bound", "travel")]
        + [("peak", ctypes.c_uint64)]
        + [
            (name, ctypes.c_uint32)
            for name in (
                "route_length",
                "feasible",
                "optimal",
                "labels",
                "states",
                "runs",
                "method",
                "expanded",
            )
        ]
    )


@cache
def _library():
    compiler = shutil.which("cc")
    if not compiler:
        raise RuntimeError("compiled deadline routing requires a C compiler")
    source = Path(__file__).resolve().parents[1] / "firmware/deadline_event.c"
    with tempfile.TemporaryDirectory(prefix="ember-deadline-") as folder:
        library_path = Path(folder) / "deadline.so"
        subprocess.run(
            [
                compiler,
                "-std=c99",
                "-O3",
                "-Wall",
                "-Wextra",
                "-Werror",
                "-shared",
                "-fPIC",
                str(source),
                "-o",
                str(library_path),
            ],
            check=True,
            capture_output=True,
        )
        library = ctypes.CDLL(str(library_path))
    u32 = ctypes.POINTER(ctypes.c_uint32)
    i64 = ctypes.POINTER(ctypes.c_int64)
    byte = ctypes.POINTER(ctypes.c_uint8)
    library.ember_deadline_event.argtypes = (
        [ctypes.c_uint32, u32, u32, u32, i64, u32, u32, u32, i64, byte]
        + [ctypes.c_uint32] * 4
        + [byte, ctypes.c_size_t, ctypes.c_size_t, u32, ctypes.POINTER(_Stats)]
    )
    library.ember_deadline_event.restype = ctypes.c_int
    return library


def event_graph_search(
    edges,
    steps,
    costs,
    n,
    start,
    goals,
    deadline,
    max_labels,
    *,
    arena,
    strategy,
):
    storage = arena if arena is not None else MCUArena(200 * 1024)
    source = edges.reshape(-1).astype(np.int64, copy=False)
    target = edges[:, ::-1].reshape(-1).astype(np.int64, copy=False)
    if len(source) >= 2**32:
        raise ValueError("native transition indexing exceeds uint32")
    order = np.argsort(source, kind="stable")
    rows = np.empty(n + 1, np.uint32)
    rows[0] = 0
    np.cumsum(np.bincount(source, minlength=n), out=rows[1:])
    targets = np.ascontiguousarray(target[order], dtype=np.uint32)
    duration = np.ascontiguousarray(np.repeat(steps, 2)[order], dtype=np.uint32)
    forward_weight = np.ascontiguousarray(costs[:, ::-1].reshape(-1)[order])
    reverse_weight = np.ascontiguousarray(costs.reshape(-1)[order])
    # Public graphs have both directions of each undirected edge. Topology
    # and clock arrays are identical in the reverse graph; only risk differs.
    forward = (rows, targets, duration, forward_weight)
    backward = (rows, targets, duration, reverse_weight)
    goal_flags = np.zeros(n, np.uint8)
    goal_flags[list(goals)] = 1
    route = np.empty(n, np.uint32)
    stats = _Stats()
    buffer = (ctypes.c_uint8 * storage.capacity).from_buffer(storage._storage)

    def pointers(csr):
        return [
            a.ctypes.data_as(
                ctypes.POINTER(ctypes.c_uint32 if i < 3 else ctypes.c_int64)
            )
            for i, a in enumerate(csr)
        ]

    status = _library().ember_deadline_event(
        n,
        *pointers(forward),
        *pointers(backward),
        goal_flags.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8)),
        start,
        deadline,
        min(max_labels, 2**32 - 1),
        MODES[strategy],
        buffer,
        storage.capacity,
        storage.used,
        route.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
        ctypes.byref(stats),
    )
    storage.high_water = max(storage.high_water, stats.peak)
    if status == -1:
        raise RuntimeError("compiled deadline certificate or witness failed")
    result = DeadlineRoute(
        tuple(int(node) for node in route[: stats.route_length]),
        int(stats.travel),
        stats.cost / 65536,
        bool(stats.feasible),
        bool(stats.optimal),
        not bool(stats.optimal),
        int(stats.labels),
        storage.high_water,
        lower_bound_q16=int(stats.lower_bound),
        search_strategy=strategy,
        expanded_labels=int(stats.expanded),
        preprocessing_runs=int(stats.runs),
        dynamic_states=int(stats.states),
    )

    return result


def event_route(
    graph: TraversabilityGraph,
    start: int,
    goals: tuple[int, ...],
    risk_cost: np.ndarray,
    *,
    available_steps: int,
    walking_speed_m_s: float,
    dt_s: float,
    max_labels: int = 4096,
    arena: MCUArena | None = None,
    strategy: str = "event_exact",
) -> DeadlineRoute:
    """Minimize length plus estimated exposure subject to a traversal deadline."""
    if strategy not in MODES:
        raise ValueError("unknown deadline search strategy")
    risk = np.asarray(risk_cost, dtype=float)
    if (
        risk.shape != (graph.n_nodes,)
        or np.any(risk < 0)
        or not np.all(np.isfinite(risk))
    ):
        raise ValueError("risk must be finite and nonnegative with one value per node")
    if (
        not 0 <= start < graph.n_nodes
        or not goals
        or any(not 0 <= goal < graph.n_nodes for goal in goals)
    ):
        raise ValueError("route endpoints must be graph nodes")
    if (
        not isinstance(available_steps, int)
        or isinstance(available_steps, bool)
        or available_steps < 0
        or available_steps >= INT32_MAX
    ):
        raise ValueError("available_steps must fit the nonnegative int32 clock")
    if (
        not isinstance(max_labels, int)
        or isinstance(max_labels, bool)
        or max_labels < 1
        or min(walking_speed_m_s, dt_s) <= 0
        or not all(math.isfinite(value) for value in (walking_speed_m_s, dt_s))
    ):
        raise ValueError("speed, time step and label capacity must be positive")
    if (
        graph.edges.ndim != 2
        or graph.edges.shape[1] != 2
        or not np.issubdtype(graph.edges.dtype, np.integer)
        or graph.edge_cost.shape != (graph.n_edges,)
        or np.any(graph.edges < 0)
        or np.any(graph.edges >= graph.n_nodes)
        or not np.all(np.isfinite(graph.edge_cost))
        or np.any(graph.edge_cost < 0)
    ):
        raise ValueError(
            "graph edges require valid endpoints and finite nonnegative lengths"
        )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        travel = np.maximum(1.0, np.ceil(graph.edge_cost / walking_speed_m_s / dt_s))
        if not np.all(np.isfinite(travel)) or np.any(travel >= INT32_MAX):
            raise ValueError("edge traversal time exceeds int32 clock range")
        steps = travel.astype(np.int64)
        encoded = np.rint(
            (graph.edge_cost[:, None] + risk[graph.edges] * steps[:, None] * dt_s)
            * Q16_SCALE
        )
        if not np.all(np.isfinite(encoded)) or np.any(encoded >= INT32_MAX):
            raise ValueError("edge objective exceeds integer finite range")
        costs = np.maximum(1, encoded).astype(np.int64)
    return event_graph_search(
        graph.edges,
        steps,
        costs,
        graph.n_nodes,
        start,
        goals,
        available_steps,
        max_labels,
        arena=arena,
        strategy=strategy,
    )
