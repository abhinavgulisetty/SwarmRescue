"""Budget-contracted extension; the frozen transport implementation is reused."""
import ctypes
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path
import numpy as np
from mcu.retention import FixedModel,BYTE,I64,U32,U64,pointer
from mcu.transport import TransportSolver


@cache
def library():
    source=Path(__file__).resolve().parents[1]/"firmware/deadline_contract.c"
    with tempfile.TemporaryDirectory(prefix="transport-contract-") as folder:
        out=Path(folder)/"contract.so"
        subprocess.run([shutil.which("cc") or "cc","-std=c99","-O3","-Wall",
            "-Wextra","-Werror","-shared","-fPIC",str(source),"-o",str(out)],
            check=True,capture_output=True)
        lib=ctypes.CDLL(str(out))
    lib.ember_contract_create.argtypes=([ctypes.c_uint32]*2+[U32]*6+[BYTE]+
        [ctypes.c_uint32]*2+[I64,ctypes.c_uint32,ctypes.c_size_t])
    lib.ember_contract_create.restype=ctypes.c_void_p
    lib.ember_contract_update.argtypes=[ctypes.c_void_p]+[ctypes.c_uint32]*3+[U32,I64]
    lib.ember_contract_update.restype=ctypes.c_int
    lib.ember_contract_result.argtypes=[ctypes.c_void_p,U32,U32]
    lib.ember_contract_result.restype=ctypes.c_int64
    lib.ember_contract_stats.argtypes=[ctypes.c_void_p,U64]
    lib.ember_contract_destroy.argtypes=[ctypes.c_void_p]
    return lib


class ContractSolver(TransportSolver):
    def __init__(self,model,*,memory_bytes=64*1024*1024):
        self.handle=None
        self.model=model if isinstance(model,FixedModel) else FixedModel(model)
        self.lib=library()
        self.create=self.lib.ember_contract_create;self.step=self.lib.ember_contract_update
        self.read=self.lib.ember_contract_result;self.statistics=self.lib.ember_contract_stats
        self.destroy=self.lib.ember_contract_destroy
        m=self.model
        self.handle=self.create(m.n,m.m,pointer(m.rows),pointer(m.to),pointer(m.duration),
            pointer(m.from_nodes),pointer(m.reverse_rows),pointer(m.reverse_edges),pointer(m.goals),
            m.start,m.deadline,pointer(m.initial_cost),0,memory_bytes)
        if not self.handle:
            raise MemoryError("contracted certificate initialization failed")
        self.output=np.empty(m.n,np.uint32)
