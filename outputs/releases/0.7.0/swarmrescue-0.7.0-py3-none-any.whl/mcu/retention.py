"""Research host interface for coupled-update certificates and exact DP repair."""

from __future__ import annotations

import ctypes
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path

import numpy as np

from eval.routing_certificates import validate_model

MODES = {
    "prefix_certificate": 0,
    "scalar_certificate": 1,
    "incremental_dp": 2,
    "full_dp": 3,
    "dual_check": 4,
}
INF = (1 << 63) - 1
U32 = ctypes.POINTER(ctypes.c_uint32)
I64 = ctypes.POINTER(ctypes.c_int64)
U64 = ctypes.POINTER(ctypes.c_uint64)
BYTE = ctypes.POINTER(ctypes.c_uint8)


def pointer(array):
    return array.ctypes.data_as(
        {
            np.dtype("uint32"): U32,
            np.dtype("int64"): I64,
            np.dtype("uint64"): U64,
            np.dtype("uint8"): BYTE,
        }[array.dtype]
    )


@cache
def library():
    compiler = shutil.which("cc")
    if not compiler:
        raise RuntimeError("C compiler required")
    source = Path(__file__).resolve().parents[1] / "firmware/deadline_retention.c"
    with tempfile.TemporaryDirectory(prefix="ember-retention-") as folder:
        output = Path(folder) / "retention.so"
        subprocess.run(
            [
                compiler,
                "-std=c99",
                "-O3",
                "-Wall",
                "-Wextra",
                "-Werror",
                "-shared",
                "-fPIC",
                str(source),
                "-o",
                str(output),
            ],
            check=True,
            capture_output=True,
        )
        lib = ctypes.CDLL(str(output))
    lib.ember_retention_create.argtypes = (
        [ctypes.c_uint32] * 2
        + [U32] * 6
        + [BYTE]
        + [ctypes.c_uint32] * 2
        + [I64, ctypes.c_uint32, ctypes.c_size_t]
    )
    lib.ember_retention_create.restype = ctypes.c_void_p
    lib.ember_retention_update.argtypes = [ctypes.c_void_p, I64]
    lib.ember_retention_update.restype = ctypes.c_int
    lib.ember_retention_destroy.argtypes = [ctypes.c_void_p]
    lib.ember_retention_result.argtypes = [ctypes.c_void_p, U32, U32]
    lib.ember_retention_result.restype = ctypes.c_int64
    lib.ember_retention_stats.argtypes = [ctypes.c_void_p, U64]
    lib.ember_retention_gaps.argtypes = [ctypes.c_void_p, I64]
    lib.ember_retention_floor.argtypes = [ctypes.c_void_p]
    lib.ember_retention_floor.restype = ctypes.c_int64
    return lib


class FixedModel:
    def __init__(self, model):
        validate_model(model)
        self.n = len(model["adjacent"])
        self.start = model["start"]
        self.deadline = model["deadline"]
        arcs = [(u, *arc) for u, row in enumerate(model["adjacent"]) for arc in row]
        self.m = len(arcs)
        self.rows = np.zeros(self.n + 1, np.uint32)
        self.from_nodes = np.array([a[0] for a in arcs], np.uint32)
        self.to = np.array([a[1] for a in arcs], np.uint32)
        self.duration = np.array([a[2] for a in arcs], np.uint32)
        self.initial_cost = np.array([a[3] for a in arcs], np.int64)
        np.cumsum([len(row) for row in model["adjacent"]], out=self.rows[1:])
        self.reverse_edges = np.argsort(self.to, kind="stable").astype(np.uint32)
        self.reverse_rows = np.zeros(self.n + 1, np.uint32)
        np.cumsum(np.bincount(self.to, minlength=self.n), out=self.reverse_rows[1:])
        self.goals = np.zeros(self.n, np.uint8)
        self.goals[model["goals"]] = 1
        if (
            self.deadline >= (1 << 31) - 1
            or np.any(self.initial_cost >= (1 << 31) - 1)
            or any(t >= (1 << 31) - 1 for row in model["adjacent"] for _, t, _ in row)
        ):
            raise ValueError("clock/cost exceeds native range")

    def updated_model(self, cost):
        return dict(
            adjacent=[
                [
                    [int(self.to[e]), int(self.duration[e]), int(cost[e])]
                    for e in range(int(self.rows[u]), int(self.rows[u + 1]))
                ]
                for u in range(self.n)
            ],
            start=self.start,
            goals=np.flatnonzero(self.goals).tolist(),
            deadline=self.deadline,
        )


class RetentionSolver:
    def __init__(
        self, model, method="prefix_certificate", *, memory_bytes=64 * 1024 * 1024
    ):
        self.handle = None
        self.model = model if isinstance(model, FixedModel) else FixedModel(model)
        self.lib = library()
        self.method = method
        self.handle = None
        m = self.model
        self.handle = self.lib.ember_retention_create(
            m.n,
            m.m,
            pointer(m.rows),
            pointer(m.to),
            pointer(m.duration),
            pointer(m.from_nodes),
            pointer(m.reverse_rows),
            pointer(m.reverse_edges),
            pointer(m.goals),
            m.start,
            m.deadline,
            pointer(m.initial_cost),
            MODES[method],
            memory_bytes,
        )
        if not self.handle:
            raise MemoryError(
                "native setup failed or exceeds declared host memory budget"
            )
        self.output = np.empty(m.n, np.uint32)

    def close(self):
        if self.handle:
            self.lib.ember_retention_destroy(self.handle)
            self.handle = None

    def __del__(self):
        self.close()

    def update(self, cost):
        if not self.handle:
            raise RuntimeError("solver is closed")
        cost = np.asarray(cost)
        if (
            cost.dtype != np.int64
            or cost.shape != (self.model.m,)
            or not cost.flags.c_contiguous
        ):
            raise ValueError("cost requires a contiguous int64 value per directed arc")
        status = self.lib.ember_retention_update(self.handle, pointer(cost))
        if status < 0:
            raise ValueError("invalid costs or failed native witness")
        return status

    def result(self):
        if not self.handle:
            raise RuntimeError("solver is closed")
        length = ctypes.c_uint32()
        value = int(
            self.lib.ember_retention_result(
                self.handle, pointer(self.output), ctypes.byref(length)
            )
        )
        route = self.output[: length.value].astype(int).tolist()
        return dict(
            route=route,
            feasible=value != INF,
            optimal=True,
            cost_q16=value if value != INF else None,
            lower_bound_q16=value if value != INF else None,
        )

    def stats(self):
        if not self.handle:
            raise RuntimeError("solver is closed")
        values = np.empty(6, np.uint64)
        self.lib.ember_retention_stats(self.handle, pointer(values))
        return {
            k: int(v)
            for k, v in zip(
                [
                    "retained_numeric_bytes",
                    "peak_numeric_bytes",
                    "builds",
                    "retentions",
                    "recomputed_states",
                    "fast_builds",
                ],
                values,
                strict=True,
            )
        }

    def gaps(self):
        if not self.handle:
            raise RuntimeError("solver is closed")
        if not self.method.endswith("certificate"):
            return None
        values = np.empty(self.model.n, np.int64)
        self.lib.ember_retention_gaps(self.handle, pointer(values))
        return [int(v) if v != INF else None for v in values]

    def alternative_floor(self):
        if not self.handle:
            raise RuntimeError("solver is closed")
        value = self.lib.ember_retention_floor(self.handle)
        return int(value) if value != INF else None
