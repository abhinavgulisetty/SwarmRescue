"""One native update/output call, matching the native recomputation interfaces.

This is an interface optimization, not a new mathematical algorithm.
"""
import ctypes
import shutil
import subprocess
import tempfile
from functools import cache
from pathlib import Path
import numpy as np
from mcu.retention import INF

SOURCES={
    "transport":("deadline_transport.c","ember_transport_update","ember_transport_result"),
    "contract":("deadline_contract.c","ember_contract_update","ember_contract_result"),
    "landmark":("deadline_landmark.c","ember_landmark_update","ember_landmark_result"),
    "dp":("deadline_transport_controls.c","ember_sparse_dp_update","ember_transport_result"),
    "dynamic":("deadline_transport.c","ember_dynamic_update","ember_dynamic_result"),
}


@cache
def library(kind):
    root=Path(__file__).resolve().parents[1]/"firmware"
    name,update,result=SOURCES[kind]
    with tempfile.TemporaryDirectory(prefix="transport-fused-") as folder:
        out=Path(folder)/"fused.so"
        subprocess.run([shutil.which("cc") or "cc","-std=c99","-O3","-Wall","-Wextra",
            "-Werror","-shared","-fPIC",str(root/name),str(root/"deadline_fused.c"),
            "-DTARGET_UPDATE="+update,"-DTARGET_RESULT="+result,"-o",str(out)],
            check=True,capture_output=True)
        lib=ctypes.CDLL(str(out))
    lib.ember_fused_update.argtypes=[ctypes.c_void_p]+[ctypes.c_uint32]*3+[ctypes.c_void_p]*5
    lib.ember_fused_update.restype=ctypes.c_int
    return lib


class FusedSolver:
    def __init__(self,base,kind):
        self.base=base;self.lib=library(kind)
        self.length=ctypes.c_uint32();self.value=ctypes.c_int64()
        self.output=base.output
        self.tail=(self.output.ctypes.data,ctypes.byref(self.length),ctypes.byref(self.value))
        initial=base.result();self.length.value=len(initial["route"])
        self.value.value=INF if initial["cost_q16"] is None else initial["cost_q16"]

    def update(self,start,deadline,edges,costs):
        if not self.base.handle:
            raise RuntimeError("solver is closed")
        edges,costs=np.asarray(edges),np.asarray(costs)
        if (edges.dtype!=np.uint32 or costs.dtype!=np.int64 or edges.ndim!=1
            or costs.shape!=edges.shape or not edges.flags.c_contiguous
            or not costs.flags.c_contiguous or not 0<=start<self.base.model.n
            or not 0<=deadline<=self.base.model.deadline):
            raise ValueError("invalid query or contiguous uint32/int64 patches")
        status=self.lib.ember_fused_update(self.base.handle,start,deadline,len(edges),
            edges.ctypes.data,costs.ctypes.data,*self.tail)
        if status<0:
            raise ValueError("invalid patch or failed native witness")
        return status

    def result(self):
        if not self.base.handle:
            raise RuntimeError("solver is closed")
        value=int(self.value.value)
        return dict(route=self.output[:self.length.value].astype(int).tolist(),
            feasible=value!=INF,optimal=True,cost_q16=value if value!=INF else None,
            lower_bound_q16=value if value!=INF else None)

    def stats(self):
        return self.base.stats()

    def close(self):
        self.base.close()
